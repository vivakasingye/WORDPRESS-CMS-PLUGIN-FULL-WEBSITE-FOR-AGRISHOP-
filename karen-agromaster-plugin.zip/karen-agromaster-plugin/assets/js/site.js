/*
 * Karen Agromaster website — v6
 * Everything here is an enhancement: menus, search, forms and "Add to quote" links all work without JavaScript.
 */
(function () {
  'use strict';

  var root = document.querySelector('.ka-site');
  if (!root) { return; }

  var $ = function (sel, from) { return (from || root).querySelector(sel); };
  var $$ = function (sel, from) { return Array.prototype.slice.call((from || root).querySelectorAll(sel)); };
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var escapeHtml = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  };

  /* ---------- Images: swap to the bundled photo if an external one fails ---------- */
  function guardImage(img) {
    if (!img.getAttribute('data-fallback')) { return; }
    var swap = function () {
      if (img.getAttribute('data-fallback-used')) { return; }
      img.setAttribute('data-fallback-used', '1');
      img.removeAttribute('srcset');
      img.src = img.getAttribute('data-fallback');
    };
    img.addEventListener('error', swap);
    if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) { swap(); }
  }
  $$('img[data-fallback]').forEach(guardImage);

  /* ---------- Header ---------- */
  var header = $('[data-header]');
  var waFloat = $('.ka-wa');
  if (header) {
    // The floating WhatsApp button waits until the first screen is scrolled past, so it never covers the hero buttons.
    var onScroll = function () {
      header.classList.toggle('is-scrolled', window.scrollY > 8);
      if (waFloat) { waFloat.classList.toggle('is-hidden', window.scrollY < Math.min(520, window.innerHeight * 0.7)); }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  $$('.ka-nav__toggle').forEach(function (btn) {
    var item = btn.closest('.ka-nav__item');
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = !item.classList.contains('is-open');
      $$('.ka-nav__item.is-open').forEach(function (other) {
        other.classList.remove('is-open');
        var t = $('.ka-nav__toggle', other); if (t) { t.setAttribute('aria-expanded', 'false'); }
      });
      item.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
    });
  });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.ka-nav__item')) {
      $$('.ka-nav__item.is-open').forEach(function (item) {
        item.classList.remove('is-open');
        var t = $('.ka-nav__toggle', item); if (t) { t.setAttribute('aria-expanded', 'false'); }
      });
    }
  });

  var searchToggle = $('[data-search-toggle]');
  var searchbar = $('#ka-searchbar');
  if (searchToggle && searchbar) {
    searchToggle.addEventListener('click', function () {
      var open = searchbar.hidden;
      searchbar.hidden = !open;
      searchToggle.setAttribute('aria-expanded', String(open));
      if (open) { var input = $('input', searchbar); if (input) { input.focus(); } }
    });
  }

  /* ---------- Drawers ---------- */
  var scrim = $('[data-scrim]');
  var openDrawer = null;
  var lastFocus = null;

  function focusables(el) {
    return $$('a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select, textarea, summary, [tabindex]:not([tabindex="-1"])', el)
      .filter(function (x) { return x.offsetParent !== null; });
  }
  function showDrawer(el) {
    if (!el) { return; }
    if (openDrawer && openDrawer !== el) { hideDrawer(true); }
    lastFocus = document.activeElement;
    openDrawer = el;
    el.classList.add('is-open');
    if (scrim) { scrim.hidden = false; }
    document.body.classList.add('ka-lock');
    var menuBtn = $('[data-menu-open]');
    if (el.id === 'ka-menu' && menuBtn) { menuBtn.setAttribute('aria-expanded', 'true'); }
    window.setTimeout(function () { var f = focusables(el); if (f[0]) { f[0].focus(); } }, 60);
  }
  function hideDrawer(keepFocus) {
    if (!openDrawer) { return; }
    openDrawer.classList.remove('is-open');
    if (openDrawer.id === 'ka-menu') {
      var menuBtn = $('[data-menu-open]'); if (menuBtn) { menuBtn.setAttribute('aria-expanded', 'false'); }
      if (window.location.hash === '#ka-menu' && window.history.replaceState) { window.history.replaceState(null, '', window.location.pathname + window.location.search); }
    }
    openDrawer = null;
    if (scrim) { scrim.hidden = true; }
    document.body.classList.remove('ka-lock');
    if (!keepFocus && lastFocus && lastFocus.focus) { lastFocus.focus(); }
  }
  var menuOpen = $('[data-menu-open]');
  if (menuOpen) { menuOpen.addEventListener('click', function (e) { e.preventDefault(); showDrawer($('#ka-menu')); }); }
  $$('[data-drawer-close]').forEach(function (b) { b.addEventListener('click', function (e) { e.preventDefault(); hideDrawer(); }); });
  if (scrim) { scrim.addEventListener('click', function () { hideDrawer(); }); }
  if (window.location.hash === '#ka-menu') { showDrawer($('#ka-menu')); }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (openDrawer) { hideDrawer(); return; }
      $$('.ka-nav__item.is-open').forEach(function (i) { i.classList.remove('is-open'); });
      if (searchbar && !searchbar.hidden) { searchbar.hidden = true; if (searchToggle) { searchToggle.setAttribute('aria-expanded', 'false'); searchToggle.focus(); } }
    }
    if (e.key === 'Tab' && openDrawer) {
      var f = focusables(openDrawer);
      if (!f.length) { return; }
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* ---------- Hero slides ---------- */
  var hero = $('[data-hero]');
  if (hero) {
    var slides = $$('[data-slide]', hero);
    var photos = $$('[data-slide-photo]', hero);
    var dots = $$('[data-slide-to]', hero);
    var pauseBtn = $('[data-slide-pause]', hero);
    var index = 0, timer = null, hovering = false;
    var autoplay = hero.getAttribute('data-autoplay') !== 'no' && !reduceMotion && slides.length > 1;
    var userPaused = !autoplay;
    var DURATION = 7000;
    hero.style.setProperty('--ka-slide-ms', DURATION + 'ms');

    var go = function (i) {
      index = (i + slides.length) % slides.length;
      slides.forEach(function (s, j) {
        var on = j === index;
        s.classList.toggle('is-active', on);
        if (on) { s.removeAttribute('aria-hidden'); } else { s.setAttribute('aria-hidden', 'true'); }
        $$('a', s).forEach(function (a) { if (on) { a.removeAttribute('tabindex'); } else { a.setAttribute('tabindex', '-1'); } });
      });
      photos.forEach(function (p, j) { p.classList.toggle('is-active', j === index); });
      dots.forEach(function (d, j) {
        d.classList.toggle('is-active', j === index);
        if (j === index) { d.setAttribute('aria-current', 'true'); } else { d.removeAttribute('aria-current'); }
        var bar = d.firstElementChild;
        if (bar && j === index) { bar.style.display = 'none'; void bar.offsetWidth; bar.style.display = ''; }
      });
    };
    var stop = function () { if (timer) { window.clearInterval(timer); timer = null; } hero.classList.remove('is-playing'); };
    var start = function () {
      stop();
      if (userPaused || hovering || document.hidden || slides.length < 2) { return; }
      hero.classList.add('is-playing');
      timer = window.setInterval(function () { go(index + 1); }, DURATION);
    };
    dots.forEach(function (d) {
      d.addEventListener('click', function () { go(Number(d.getAttribute('data-slide-to'))); start(); });
    });
    if (pauseBtn) {
      pauseBtn.setAttribute('aria-pressed', String(userPaused));
      $('.ka-sr', pauseBtn).textContent = userPaused ? 'Play slides' : 'Pause slides';
      pauseBtn.addEventListener('click', function () {
        userPaused = !userPaused;
        pauseBtn.setAttribute('aria-pressed', String(userPaused));
        $('.ka-sr', pauseBtn).textContent = userPaused ? 'Play slides' : 'Pause slides';
        hero.classList.toggle('is-paused', userPaused);
        if (userPaused) { stop(); } else { go(index + 1); start(); }
      });
    }
    hero.classList.toggle('is-paused', userPaused);
    hero.addEventListener('mouseenter', function () { hovering = true; stop(); });
    hero.addEventListener('mouseleave', function () { hovering = false; start(); });
    hero.addEventListener('focusin', function () { hovering = true; stop(); });
    hero.addEventListener('focusout', function (e) { if (!hero.contains(e.relatedTarget)) { hovering = false; start(); } });
    document.addEventListener('visibilitychange', function () { if (document.hidden) { stop(); } else { start(); } });
    start();
  }

  /* ---------- Services list on the homepage ---------- */
  var servicesBlock = $('[data-services]');
  if (servicesBlock) {
    var rows = $$('[data-service]', servicesBlock);
    var activate = function (row) {
      var id = row.getAttribute('data-service');
      rows.forEach(function (r) { r.classList.toggle('is-active', r === row); });
      $$('[data-service-photo]', servicesBlock).forEach(function (p) { p.classList.toggle('is-active', p.getAttribute('data-service-photo') === id); });
    };
    rows.forEach(function (row) {
      row.addEventListener('mouseenter', function () { activate(row); });
      row.addEventListener('focusin', function () { activate(row); });
    });
  }

  /* ---------- Quote basket ---------- */
  var catalog = {};
  try {
    JSON.parse(($('#ka-catalog') || document.getElementById('ka-catalog') || { textContent: '[]' }).textContent || '[]').forEach(function (p) { catalog[String(p.id)] = p; });
  } catch (err) { /* ignore */ }

  var KEY = 'kam-enquiry-basket-v5';   // Same key as v5, so baskets survive the upgrade.
  var QTY_KEY = 'kam-enquiry-qty-v6';
  var store = { get: function (k, d) { try { var v = JSON.parse(window.localStorage.getItem(k)); return v === null ? d : v; } catch (e) { return d; } },
                set: function (k, v) { try { window.localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* private mode */ } } };
  var basket = store.get(KEY, []);
  basket = Array.isArray(basket) ? basket.map(String).filter(function (id) { return catalog[id]; }) : [];
  var qty = store.get(QTY_KEY, {});
  if (!qty || typeof qty !== 'object') { qty = {}; }

  var save = function () { store.set(KEY, basket); store.set(QTY_KEY, qty); };
  var has = function (id) { return basket.indexOf(String(id)) !== -1; };

  var toast = $('[data-toast]');
  var toastTimer = null;
  function showToast(text, withButton) {
    if (!toast) { return; }
    toast.innerHTML = '<span>' + escapeHtml(text) + '</span>' + (withButton ? '<button type="button" data-toast-open>View basket</button>' : '');
    toast.classList.add('is-show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () { toast.classList.remove('is-show'); }, 3800);
    var b = $('[data-toast-open]', toast);
    if (b) { b.addEventListener('click', function () { toast.classList.remove('is-show'); showDrawer($('#ka-basket')); }); }
  }

  function paint() {
    var n = basket.length;
    $$('[data-basket-count]').forEach(function (el) {
      el.textContent = n; el.hidden = n === 0;
    });
    var basketBtn = $('[data-basket-open]');
    if (basketBtn) { $('.ka-sr', basketBtn).textContent = 'Quote basket, ' + n + (n === 1 ? ' product' : ' products'); }
    $$('[data-add-product]', document).forEach(function (btn) {
      var on = has(btn.getAttribute('data-add-product'));
      btn.classList.toggle('is-added', on);
      btn.setAttribute('aria-pressed', String(on));
      var label = $('span', btn);
      if (label) { label.textContent = on ? (btn.classList.contains('ka-add--detail') ? 'In your quote basket' : 'Added') : btn.getAttribute('data-label'); }
    });
    var list = $('[data-basket-list]');
    if (list) {
      list.innerHTML = basket.map(function (id) {
        var p = catalog[id];
        return '<li><img src="' + escapeHtml(p.image) + '" data-fallback="' + escapeHtml(p.fallback) + '" alt=""><div><a href="' + escapeHtml(p.url) + '">' + escapeHtml(p.name) + '</a><small>' + escapeHtml(p.category || '') + '</small></div>'
          + '<button class="ka-iconbtn" type="button" data-remove="' + escapeHtml(id) + '"><svg class="ka-icon" aria-hidden="true"><use href="#ka-i-trash-2"></use></svg><span class="ka-sr">Remove ' + escapeHtml(p.name) + '</span></button></li>';
      }).join('');
      $$('img[data-fallback]', list).forEach(guardImage);
    }
    var empty = $('[data-basket-empty]'); if (empty) { empty.hidden = n > 0; }
    var foot = $('[data-basket-foot]'); if (foot) { foot.hidden = n === 0; }
    var summary = $('[data-basket-summary]');
    if (summary) { summary.textContent = n ? n + (n === 1 ? ' product' : ' products') + ' selected' : 'No products yet'; }
    paintQuoteRows();
  }

  function toggle(id, silent) {
    id = String(id);
    if (!catalog[id]) { return; }
    var adding = !has(id);
    basket = adding ? basket.concat(id) : basket.filter(function (x) { return x !== id; });
    if (!adding) { delete qty[id]; }
    save();
    paint();
    var count = $('[data-basket-count]');
    if (count && adding) { count.classList.remove('is-bump'); void count.offsetWidth; count.classList.add('is-bump'); }
    if (!silent) { showToast(adding ? catalog[id].name + ' added to your quote basket' : catalog[id].name + ' removed', adding); }
  }

  document.addEventListener('click', function (e) {
    var add = e.target.closest('[data-add-product]');
    if (add && catalog[add.getAttribute('data-add-product')]) { e.preventDefault(); toggle(add.getAttribute('data-add-product')); return; }
    var rm = e.target.closest('[data-remove]');
    if (rm) { e.preventDefault(); toggle(rm.getAttribute('data-remove'), true); }
  });
  var basketOpen = $('[data-basket-open]');
  if (basketOpen) { basketOpen.addEventListener('click', function (e) { e.preventDefault(); showDrawer($('#ka-basket')); }); }
  var clear = $('[data-basket-clear]');
  if (clear) { clear.addEventListener('click', function () { basket = []; qty = {}; save(); paint(); showToast('Your quote basket is empty', false); }); }

  /* Quote form: one row per basket product with its own quantity box. */
  var rowsWrap = $('[data-basket-rows]');
  var fieldset = $('[data-basket-fields]');
  function paintQuoteRows() {
    if (!rowsWrap || !fieldset) { return; }
    fieldset.hidden = basket.length === 0;
    var existing = {};
    $$('.ka-basket-row', rowsWrap).forEach(function (r) { existing[r.getAttribute('data-id')] = r; });
    basket.forEach(function (id) {
      if (existing[id]) { delete existing[id]; return; }
      var p = catalog[id];
      var row = document.createElement('div');
      row.className = 'ka-basket-row';
      row.setAttribute('data-id', id);
      row.innerHTML = '<img src="' + escapeHtml(p.image) + '" data-fallback="' + escapeHtml(p.fallback) + '" alt=""><strong id="ka-q-' + escapeHtml(id) + '">' + escapeHtml(p.name) + '</strong>'
        + '<input type="text" name="items[' + escapeHtml(id) + ']" maxlength="60" placeholder="Quantity" aria-labelledby="ka-q-' + escapeHtml(id) + '" value="' + escapeHtml(qty[id] || '') + '">'
        + '<button class="ka-iconbtn" type="button" data-remove="' + escapeHtml(id) + '"><svg class="ka-icon" aria-hidden="true"><use href="#ka-i-x"></use></svg><span class="ka-sr">Remove ' + escapeHtml(p.name) + '</span></button>';
      rowsWrap.appendChild(row);
      guardImage($('img', row));
      $('input', row).addEventListener('input', function (ev) { qty[id] = ev.target.value; save(); });
    });
    Object.keys(existing).forEach(function (id) { existing[id].parentNode.removeChild(existing[id]); });
    var msg = $('textarea[name="message"]');
    if (msg) { msg.required = basket.length === 0; }
  }

  var params = new URLSearchParams(window.location.search);
  if (params.get('add') && catalog[params.get('add')]) {
    if (!has(params.get('add'))) { basket.push(String(params.get('add'))); save(); }
    var msgBox = $('textarea[name="message"]');
    if (msgBox && /^I would like a quotation for: /.test(msgBox.value)) { msgBox.value = ''; }
  }
  if ($('[data-basket-sent]')) { basket = []; qty = {}; save(); }
  paint();

  var form = $('[data-enquiry-form]');
  if (form) {
    form.addEventListener('submit', function (e) {
      var msg = $('textarea[name="message"]', form);
      if (msg && !msg.value.trim() && basket.length) { msg.value = 'Please send a quotation for the products listed above.'; }
      var btn = $('button[type="submit"]', form);
      if (btn && form.checkValidity()) { btn.disabled = true; btn.style.opacity = '.7'; }
    });
  }
  var notice = $('[data-notice]');
  if (notice) { window.setTimeout(function () { notice.focus({ preventScroll: true }); }, 100); }

  /* ---------- Shop: instant filtering, search and sorting ---------- */
  var shop = $('[data-shop]');
  var grid = $('.ka-pgrid--shop');
  if (shop && grid) {
    var cards = $$('.ka-pcard', grid);
    var original = cards.slice();
    var chips = $$('[data-chip]', shop);
    var input = $('[data-shop-search]', shop);
    var countEl = $('[data-shop-count]');
    var emptyEl = $('[data-shop-empty]');
    var sortEl = $('[data-shop-sort]');
    var cat = (chips.filter(function (c) { return c.classList.contains('is-active'); })[0] || { getAttribute: function () { return ''; } }).getAttribute('data-chip') || '';
    var hiddenCat = $('input[name="category_filter"]', shop);
    // Also honour the address (useful when a page is served from a static cache).
    var urlCat = params.get('category_filter');
    if (urlCat && chips.some(function (c) { return c.getAttribute('data-chip') === urlCat; })) { cat = urlCat; }
    if (input && !input.value && params.get('product_search')) { input.value = params.get('product_search'); }

    var apply = function (push) {
      var q = (input ? input.value : '').trim().toLowerCase();
      var shown = 0;
      cards.forEach(function (card) {
        var ok = (!cat || card.getAttribute('data-cat') === cat) && (!q || card.getAttribute('data-search').indexOf(q) !== -1);
        card.hidden = !ok;
        if (ok) { shown++; }
      });
      if (countEl) { countEl.textContent = shown + (shown === 1 ? ' product' : ' products') + (q ? ' for “' + (input ? input.value.trim() : '') + '”' : ''); }
      if (emptyEl) { emptyEl.hidden = shown > 0; }
      chips.forEach(function (c) {
        var on = c.getAttribute('data-chip') === cat;
        c.classList.toggle('is-active', on);
        if (on) { c.setAttribute('aria-current', 'true'); } else { c.removeAttribute('aria-current'); }
      });
      if (hiddenCat) { hiddenCat.value = cat; }
      if (push && window.history.replaceState) {
        try {
        var u = new URL(window.location.href);
        if (cat) { u.searchParams.set('category_filter', cat); } else { u.searchParams.delete('category_filter'); }
        if (q) { u.searchParams.set('product_search', input.value.trim()); } else { u.searchParams.delete('product_search'); }
        window.history.replaceState(null, '', u.toString());
        } catch (err) { /* sandboxed frames may refuse */ }
      }
    };
    // On a category's own address (/farm-category/...), chips keep their normal links.
    var onTaxonomyPage = /\/farm-category\//.test(window.location.pathname);
    if (!onTaxonomyPage) {
      chips.forEach(function (c) {
        c.addEventListener('click', function (e) { e.preventDefault(); cat = c.getAttribute('data-chip'); apply(true); });
      });
    }
    if (input) {
      var t = null;
      input.addEventListener('input', function () { window.clearTimeout(t); t = window.setTimeout(function () { apply(true); }, 120); });
      input.form.addEventListener('submit', function (e) { e.preventDefault(); apply(true); input.blur(); });
    }
    if (sortEl) {
      sortEl.addEventListener('change', function () {
        var list = original.slice();
        if (sortEl.value === 'az' || sortEl.value === 'za') {
          list.sort(function (a, b) { return a.getAttribute('data-title').localeCompare(b.getAttribute('data-title')); });
          if (sortEl.value === 'za') { list.reverse(); }
        }
        list.forEach(function (c) { grid.appendChild(c); });
      });
    }
    apply(false);
  }
})();
