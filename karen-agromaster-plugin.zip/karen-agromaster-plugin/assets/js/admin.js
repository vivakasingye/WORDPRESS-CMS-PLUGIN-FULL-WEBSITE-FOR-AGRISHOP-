/* Karen Agromaster dashboard helpers: colour pickers, Media Library buttons, switches. */
(function ($) {
  'use strict';
  $(function () {
    if ($.fn.wpColorPicker) { $('.kam-color').wpColorPicker(); }

    $(document).on('click', '.kam-media-pick', function (e) {
      e.preventDefault();
      if (!window.wp || !wp.media) { return; }
      var target = $('#' + $(this).data('target'));
      var frame = wp.media({ title: 'Choose an image', button: { text: 'Use this image' }, library: { type: 'image' }, multiple: false });
      frame.on('select', function () {
        var file = frame.state().get('selection').first().toJSON();
        var url = (file.sizes && file.sizes.large ? file.sizes.large.url : file.url);
        target.val(url).trigger('change');
      });
      frame.open();
    });

    $(document).on('click', '.kam-media-clear', function (e) {
      e.preventDefault();
      $('#' + $(this).data('target')).val('').trigger('change');
    });

    $(document).on('change input', '.kam-image-field input', function () {
      var preview = $('[data-preview-for="' + this.id + '"]');
      if (!preview.length) { return; }
      preview.html(this.value ? $('<img alt="">').attr('src', this.value) : '');
    });

    $(document).on('change', '.kam-switch input', function () {
      $(this).siblings('span').text(this.checked ? 'On' : 'Off');
    });
  });
})(jQuery);
