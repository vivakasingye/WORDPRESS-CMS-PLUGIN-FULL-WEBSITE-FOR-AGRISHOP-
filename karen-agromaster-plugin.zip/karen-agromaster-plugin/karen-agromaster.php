<?php
/**
 * Plugin Name:       Karen Agromaster — Complete Website
 * Plugin URI:        https://karenagromaster.com
 * Description:       The complete Karen Agromaster website as one plugin: homepage, farm shop with quote basket, services, projects, insights, FAQs, contact and quotation forms. Everything is editable from the WordPress dashboard and works with any theme.
 * Version:           6.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Karen Agromaster
 * License:           GPL-2.0-or-later
 * Text Domain:       karen-agromaster
 */

if (!defined('ABSPATH')) { exit; }

define('KAM_VERSION', '6.0.0');
define('KAM_FILE', __FILE__);
define('KAM_DIR', plugin_dir_path(__FILE__));
define('KAM_URL', plugin_dir_url(__FILE__));

require_once KAM_DIR . 'includes/catalog.php';
require_once KAM_DIR . 'includes/settings.php';
require_once KAM_DIR . 'includes/content-types.php';
require_once KAM_DIR . 'includes/setup.php';
require_once KAM_DIR . 'includes/data.php';
require_once KAM_DIR . 'includes/components.php';
require_once KAM_DIR . 'includes/frontend.php';
require_once KAM_DIR . 'includes/enquiries.php';

if (is_admin()) {
    require_once KAM_DIR . 'includes/admin-settings.php';
    require_once KAM_DIR . 'includes/recommended-plugins.php';
}

register_activation_hook(__FILE__, 'kam_activate');
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift(
        $links,
        '<a href="' . esc_url(admin_url('admin.php?page=kam-settings')) . '">Website settings</a>',
        '<a href="' . esc_url(admin_url('admin.php?page=kam-plugins')) . '">Recommended plugins</a>'
    );
    return $links;
});
