# Karen Agromaster — Complete Website (version 6.0.0)

The whole Karen Agromaster website in one WordPress plugin. It draws its own header, footer and pages, so it looks the same whichever theme is active, and everything is edited from the WordPress dashboard.

## Install or upgrade

1. **Back up first** (files and database). If you already use version 3, 4 or 5, your products, services, projects, pages, settings and enquiries are kept.
2. WordPress dashboard → **Plugins → Add New → Upload Plugin** → choose `karen-agromaster-plugin.zip` → **Install Now**.
3. If WordPress says the plugin is already installed, choose **Replace current with uploaded**. Otherwise click **Activate**.
4. Open **Karen Agromaster → Website settings** once. This finishes the upgrade and shows a setup checklist.
5. Open **Karen Agromaster → Recommended plugins** and click **Install now** on the three “Essential” plugins (WP Mail SMTP, UpdraftPlus, Wordfence). Each uses WordPress’s own installer.

On a new site the plugin creates nine pages, sets the homepage, builds the main menu and adds starter products, services and FAQs.

## Pages

| Page | Address | What it shows |
| --- | --- | --- |
| Home | `/` (page `karen-agromaster`) | Hero slides, categories, featured products, services, how ordering works, about, locations map, testimonials, latest insights |
| Farm shop | `/farm-shop/` | Instant search, category filters, sorting, quote basket |
| Product | `/farm-product/name/` | Photo, price (optional), availability, specifications, add to quote, WhatsApp |
| Farm services | `/our-farm-services/` | Every service with what’s included |
| Service | `/farm-service/name/` | Details, what’s included, request this service |
| Farm projects | `/our-farm-projects/` | Project stories (hidden message until you publish one) |
| Farm insights | `/farm-insights/` | Blog posts from **Posts** |
| About | `/about-karen-agromaster/` | Company story, what we do, locations |
| Contact | `/contact-karen-agromaster/` | Form, phones, emails, map |
| Request a quotation | `/request-farm-quotation/` | Basket products with a quantity box each |
| FAQs | `/agricultural-faq/` | Questions from **Karen Agromaster → FAQs** |

Text you type in the normal page editor appears below each page’s ready-made design.

## Where to edit things

| To change… | Go to |
| --- | --- |
| Business name, logo, colours, top bar | Karen Agromaster → Website settings → Brand & colours |
| Hero slides, homepage headings, show/hide sections | … → Homepage |
| Phones, WhatsApp, emails, opening hours, locations, social links | … → Contact details |
| Where enquiry emails go, customer copy, Google description | … → Enquiries & SEO |
| Products (photo, price, unit, availability, specifications, homepage feature) | Farm Products |
| Product categories and their photos | Farm Products → Categories |
| Services and “What’s included” | Farm Services |
| Projects (location, crop, year, photo) | Farm Projects |
| Blog articles | Posts |
| FAQs and testimonials | Karen Agromaster → FAQs / Testimonials |
| Menu | Appearance → Menus → “Karen Agromaster main menu” |
| Requests from customers | Karen Agromaster → Enquiries (also emailed; download as CSV) |

## Features

- Responsive from small phones to large screens; works without JavaScript (menus, filters and forms still function).
- Quote basket that remembers products between pages, with a quantity box per product on the quotation form.
- WhatsApp buttons everywhere once a WhatsApp number is entered.
- Enquiries saved in the dashboard even if email fails, with New/Read status, call/WhatsApp/reply buttons, dashboard widget and CSV export.
- Spam protection: hidden honeypot field, minimum fill time and per-visitor rate limit. Works with page caching.
- Search engine basics: page titles, descriptions, social sharing tags, LocalBusiness and FAQ structured data. These switch off automatically when Yoast SEO, Rank Math, AIOSEO or SEOPress is active.
- No outside requests for fonts or icons: the Archivo typeface and the icon set are bundled.
- Shortcodes for other pages: `[kam_products limit="8"]`, `[kam_products category="seedlings"]`, `[kam_enquiry_form type="quote"]`.

## Things to do before launch

- Add your **WhatsApp number** (Contact details tab).
- Install and connect **WP Mail SMTP**, then send a test enquiry.
- Replace illustrative photos with your own product, service and project photos (set the “Product photo” on each product).
- Add prices and availability where you want them shown; otherwise products show “Price on request”.
- Publish real projects and, if you have them, real customer testimonials.

## Honest notes

- This is a quotation website, not an online checkout. No money is processed.
- Photos bundled with the plugin are illustrative and do not show Karen Agromaster premises, staff or projects. See `CREDITS.md`.
- Requires WordPress 6.2+ and PHP 7.4+. Tested on WordPress 7.1.5 with PHP 8.3, with the Twenty Twenty-Five (block) and Twenty Twenty-One (classic) themes, including an upgrade from version 5.0.0.
