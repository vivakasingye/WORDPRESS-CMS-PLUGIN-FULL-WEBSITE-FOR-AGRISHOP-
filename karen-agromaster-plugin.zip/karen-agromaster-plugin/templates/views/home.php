<?php
if (!defined('ABSPATH')) { exit; }
$ks = kam_settings();
$slides = [
    [$ks['hero_title'], $ks['hero_description'], $ks['hero_photo'] ?: kam_img('hero-coffee.jpg'), kam_img('hero-coffee.jpg'), ['Browse the farm shop', kam_url('shop')]],
    [$ks['hero2_title'], $ks['hero2_description'], $ks['hero2_photo'] ?: kam_img('hero-coffee-berries.jpg'), kam_img('hero-coffee-berries.jpg'), ['See all products', kam_url('shop')]],
    [$ks['hero3_title'], $ks['hero3_description'], $ks['hero3_photo'] ?: kam_uganda_img(), kam_img('hero-coffee.jpg'), ['Explore farm services', kam_url('services')]],
];
$slides = array_values(array_filter($slides, function ($sl) { return trim($sl[0]) !== ''; }));
$locs = kam_locations();
$categories = kam_categories();
$services = kam_services();
$testimonials = kam_on('show_testimonials') ? kam_testimonials() : [];
$ka_posts = kam_on('show_insights') ? kam_latest_posts(3) : [];
?>
<section class="ka-hero" data-hero data-autoplay="<?php echo esc_attr($ks['hero_autoplay']); ?>" aria-roledescription="carousel" aria-label="Highlights">
    <div class="ka-wrap ka-hero__grid">
        <div class="ka-hero__copy">
            <div class="ka-hero__slides">
                <?php foreach ($slides as $i => $sl) : ?>
                    <div class="ka-hero__slide<?php echo $i === 0 ? ' is-active' : ''; ?>" data-slide role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr(($i + 1) . ' of ' . count($slides)); ?>"<?php echo $i ? ' aria-hidden="true"' : ''; ?>>
                        <?php if ($i === 0) : ?>
                            <h1 class="ka-hero__title"><?php echo esc_html($sl[0]); ?></h1>
                        <?php else : ?>
                            <p class="ka-hero__title" role="heading" aria-level="2"><?php echo esc_html($sl[0]); ?></p>
                        <?php endif; ?>
                        <p class="ka-hero__text"><?php echo esc_html($sl[1]); ?></p>
                        <div class="ka-hero__actions">
                            <a class="ka-btn ka-btn--gold ka-btn--lg" href="<?php echo esc_url($sl[4][1]); ?>"<?php echo $i ? ' tabindex="-1"' : ''; ?>><?php echo esc_html($sl[4][0]); ?></a>
                            <a class="ka-btn ka-btn--line ka-btn--lg" href="<?php echo esc_url(kam_url('quote')); ?>"<?php echo $i ? ' tabindex="-1"' : ''; ?>>Request a quotation</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="ka-hero__foot">
                <?php if ($locs) : ?>
                    <p class="ka-hero__places"><?php echo kam_icon('map-pin'); ?>
                        <?php
                        $names = array_column($locs, 'name');
                        $last = array_pop($names);
                        echo esc_html($names ? implode(', ', $names) . ' and ' . $last : $last);
                        ?>
                    </p>
                <?php endif; ?>
                <?php if (count($slides) > 1) : ?>
                    <div class="ka-hero__dots" role="group" aria-label="Choose a slide">
                        <?php foreach ($slides as $i => $sl) : ?>
                            <button type="button" class="ka-hero__dot<?php echo $i === 0 ? ' is-active' : ''; ?>" data-slide-to="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr('Show slide ' . ($i + 1) . ': ' . $sl[0]); ?>"<?php echo $i === 0 ? ' aria-current="true"' : ''; ?>><span></span></button>
                        <?php endforeach; ?>
                        <button type="button" class="ka-hero__pause" data-slide-pause aria-pressed="false"><span class="ka-sr">Pause slides</span><svg viewBox="0 0 24 24" aria-hidden="true"><path class="p-pause" d="M8 5v14M16 5v14"/><path class="p-play" d="M8 5l11 7-11 7z"/></svg></button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php kam_hero_art(array_map(function ($sl) { return [$sl[2], $sl[3]]; }, $slides)); ?>
    </div>
</section>

<?php if (kam_on('show_categories') && $categories) : ?>
<section class="ka-section ka-section--cats">
    <div class="ka-wrap">
        <?php kam_section_head('Shop by category', '', [kam_url('shop'), 'All products']); ?>
        <ul class="ka-cats">
            <?php foreach ($categories as $c) : ?>
                <li class="ka-cat">
                    <a href="<?php echo esc_url($c['url']); ?>">
                        <span class="ka-cat__media"><img src="<?php echo esc_url($c['image']); ?>" data-fallback="<?php echo esc_url(kam_fallback_image($c['name'])); ?>" alt="" loading="lazy" decoding="async"></span>
                        <span class="ka-cat__label"><strong><?php echo esc_html($c['name']); ?></strong><small><?php echo esc_html($c['count'] . ' ' . _n('product', 'products', $c['count'], 'karen-agromaster')); ?></small></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>
<?php endif; ?>

<?php if (kam_on('show_products') && kam_products()) : ?>
<section class="ka-section ka-section--mist">
    <div class="ka-wrap">
        <?php kam_section_head($ks['products_heading'], $ks['products_description'], [kam_url('shop'), 'Visit the farm shop']); ?>
        <?php kam_product_grid(kam_featured_products(8)); ?>
    </div>
</section>
<?php endif; ?>

<?php if (kam_on('show_services') && $services) : ?>
<section class="ka-section ka-section--forest ka-services" data-services>
    <div class="ka-wrap ka-services__grid">
        <div class="ka-services__intro">
            <h2 class="ka-h2"><?php echo esc_html($ks['services_heading']); ?></h2>
            <p class="ka-lead"><?php echo esc_html($ks['services_description']); ?></p>
            <div class="ka-services__frame" aria-hidden="true">
                <?php foreach ($services as $i => $svc) : ?>
                    <div class="ka-services__photo<?php echo $i === 0 ? ' is-active' : ''; ?>" data-service-photo="<?php echo (int) $svc['id']; ?>"><?php echo kam_image($svc, 'large', '', '(max-width: 900px) 100vw, 40vw'); ?></div>
                <?php endforeach; ?>
            </div>
            <a class="ka-btn ka-btn--gold" href="<?php echo esc_url(kam_url('services')); ?>">See all services</a>
        </div>
        <ul class="ka-services__list">
            <?php foreach ($services as $i => $svc) : ?>
                <li class="ka-srow<?php echo $i === 0 ? ' is-active' : ''; ?>" data-service="<?php echo (int) $svc['id']; ?>">
                    <a href="<?php echo esc_url($svc['url']); ?>">
                        <span class="ka-srow__icon"><?php echo kam_icon(kam_service_icon($svc['title'])); ?></span>
                        <span class="ka-srow__text">
                            <span class="ka-srow__title"><?php echo esc_html($svc['title']); ?></span>
                            <span class="ka-srow__desc"><?php echo esc_html($svc['excerpt']); ?></span>
                        </span>
                        <span class="ka-srow__go"><?php echo kam_icon('arrow-right'); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>
<?php endif; ?>

<?php if (kam_on('show_process')) : ?>
<section class="ka-section">
    <div class="ka-wrap">
        <?php kam_section_head('How ordering works', 'There is no online checkout. You tell us what you need and our team confirms the details with you.'); ?>
        <ol class="ka-steps">
            <li><span class="ka-steps__n">1</span><h3>Choose what you need</h3><p>Add products to your quote basket, or pick the farm service you are interested in.</p></li>
            <li><span class="ka-steps__n">2</span><h3>Send your request</h3><p>Tell us quantities, your farm location and when you need them.</p></li>
            <li><span class="ka-steps__n">3</span><h3>Receive your quotation</h3><p>Our team calls or emails you with prices and availability.</p></li>
            <li><span class="ka-steps__n">4</span><h3>Agree payment and collection</h3><p>Payment, collection or delivery are arranged directly with our team.</p></li>
        </ol>
        <p class="ka-steps__cta"><a class="ka-btn ka-btn--forest" href="<?php echo esc_url(kam_url('quote')); ?>">Start a quotation request</a></p>
    </div>
</section>
<?php endif; ?>

<?php if (kam_on('show_about')) : $about_photo = $ks['about_photo'] ?: kam_uganda_img(); ?>
<section class="ka-section ka-section--mist">
    <div class="ka-wrap ka-split">
        <figure class="ka-split__media">
            <?php echo kam_photo_tag($about_photo, kam_img('farm-management.jpg'), 'Coffee and banana growing together on a farm in Uganda', 'ka-split__img'); ?>
            <?php if (!$ks['about_photo']) : ?><figcaption>Coffee and banana intercropping in Uganda. Photo: Kateregga1, CC BY-SA 4.0.</figcaption><?php endif; ?>
        </figure>
        <div class="ka-split__text">
            <h2 class="ka-h2"><?php echo esc_html($ks['about_heading']); ?></h2>
            <p class="ka-lead"><?php echo esc_html($ks['about_description']); ?></p>
            <ul class="ka-ticks">
                <li><?php echo kam_icon('sprout'); ?><span><strong>Planting material</strong> Coffee, cocoa, Hass avocado, banana and eucalyptus seedlings.</span></li>
                <li><?php echo kam_icon('flask-conical'); ?><span><strong>Farm inputs</strong> Fertilisers, agricultural lime and crop protection products.</span></li>
                <li><?php echo kam_icon('tractor'); ?><span><strong>Farm development</strong> Establishment, irrigation, training, security and infrastructure.</span></li>
            </ul>
            <a class="ka-link" href="<?php echo esc_url(kam_url('about')); ?>">More about us<?php echo kam_icon('arrow-right'); ?></a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php $kam_alt = kam_on('show_about'); // Alternate white and mist backgrounds after the about section. ?>
<?php if ($testimonials) : $kam_alt = !$kam_alt; ?>
<section class="ka-section<?php echo $kam_alt ? ' ka-section--mist' : ''; ?>">
    <div class="ka-wrap">
        <?php kam_section_head('What our customers say'); ?>
        <ul class="ka-quotes">
            <?php foreach ($testimonials as $t) : ?>
                <li class="ka-quote">
                    <blockquote><p><?php echo esc_html($t['quote']); ?></p></blockquote>
                    <p class="ka-quote__who">
                        <?php if ($t['photo']) : ?><img src="<?php echo esc_url($t['photo']); ?>" alt="" width="44" height="44" loading="lazy"><?php endif; ?>
                        <span><strong><?php echo esc_html($t['name']); ?></strong><?php if ($t['role']) : ?><br><?php echo esc_html($t['role']); ?><?php endif; ?></span>
                    </p>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>
<?php endif; ?>

<?php if (kam_on('show_locations') && $locs) : $kam_alt = !$kam_alt; ?>
<section class="ka-section<?php echo $kam_alt ? ' ka-section--mist' : ''; ?>">
    <div class="ka-wrap">
        <?php kam_section_head('Where to find us', 'Visit one of our locations, or call ahead to check what is available near you.', [kam_url('contact'), 'Contact details']); ?>
        <?php kam_locations_block(); ?>
    </div>
</section>
<?php endif; ?>

<?php if ($ka_posts) : $kam_alt = !$kam_alt; ?>
<section class="ka-section<?php echo $kam_alt ? ' ka-section--mist' : ''; ?>">
    <div class="ka-wrap">
        <?php kam_section_head('Farm insights', 'Guides and news from our team.', [kam_url('insights'), 'All articles']); ?>
        <div class="ka-posts"><?php foreach ($ka_posts as $p) { kam_post_card($p); } ?></div>
    </div>
</section>
<?php endif; ?>
