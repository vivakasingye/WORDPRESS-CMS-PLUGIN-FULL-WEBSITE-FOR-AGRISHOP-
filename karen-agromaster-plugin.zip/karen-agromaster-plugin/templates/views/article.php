<?php
if (!defined('ABSPATH')) { exit; }
$post = get_queried_object();
if (!$post instanceof WP_Post) { return; }
setup_postdata($post);
$cats = get_the_category($post->ID);
$ka_more = kam_latest_posts(3, ['post__not_in' => [$post->ID]]);
?>
<article class="ka-section ka-article">
    <div class="ka-wrap ka-article__wrap">
        <?php kam_breadcrumb([['Farm insights', kam_url('insights')], [get_the_title($post), '']]); ?>
        <header class="ka-article__head">
            <p class="ka-article__meta">
                <time datetime="<?php echo esc_attr(get_the_date('c', $post)); ?>"><?php echo esc_html(get_the_date('j F Y', $post)); ?></time>
                <?php if ($cats) : ?><span><a href="<?php echo esc_url(get_category_link($cats[0])); ?>"><?php echo esc_html($cats[0]->name); ?></a></span><?php endif; ?>
            </p>
            <h1 class="ka-article__title"><?php echo esc_html(get_the_title($post)); ?></h1>
            <?php if ($post->post_excerpt) : ?><p class="ka-article__lead"><?php echo esc_html($post->post_excerpt); ?></p><?php endif; ?>
        </header>
        <?php if (has_post_thumbnail($post)) : ?>
            <figure class="ka-article__media"><?php echo get_the_post_thumbnail($post, 'large', ['class' => 'ka-article__img', 'fetchpriority' => 'high']); ?></figure>
        <?php endif; ?>
        <div class="ka-prose ka-article__body"><?php echo apply_filters('the_content', $post->post_content); ?></div>
        <p class="ka-article__back"><a class="ka-link" href="<?php echo esc_url(kam_url('insights')); ?>"><?php echo kam_icon('arrow-left'); ?>All insights</a></p>
    </div>
</article>
<?php wp_reset_postdata(); ?>
<?php if ($ka_more) : ?>
<section class="ka-section ka-section--mist">
    <div class="ka-wrap">
        <?php kam_section_head('More from our team'); ?>
        <div class="ka-posts"><?php foreach ($ka_more as $p) { kam_post_card($p); } ?></div>
    </div>
</section>
<?php endif; ?>
