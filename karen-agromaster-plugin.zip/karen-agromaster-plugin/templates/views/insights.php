<?php
if (!defined('ABSPATH')) { exit; }
$ka_paged = isset($_GET['pg']) ? max(1, absint($_GET['pg'])) : 1;
$args = ['post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 9, 'paged' => $ka_paged];
$title = 'Farm insights';
$trail = [['Farm insights', '']];
if (is_category() || is_tag()) {
    $term = get_queried_object();
    $args[$term->taxonomy === 'category' ? 'cat' : 'tag_id'] = $term->term_id;
    $title = $term->name;
    $trail = [['Farm insights', kam_url('insights')], [$term->name, '']];
}
$q = new WP_Query($args);
kam_banner($title, 'Practical guides, crop advice and news from the Karen Agromaster team.', $trail);
$base = is_category() || is_tag() ? get_term_link(get_queried_object()) : kam_url('insights');
?>
<section class="ka-section">
    <div class="ka-wrap">
        <?php if ($q->have_posts()) : ?>
            <div class="ka-posts ka-posts--page"><?php foreach ($q->posts as $ka_post) { kam_post_card($ka_post); } ?></div>
            <?php if ($q->max_num_pages > 1) : ?>
                <nav class="ka-pager" aria-label="More articles">
                    <?php if ($ka_paged > 1) : ?><a class="ka-btn ka-btn--line" href="<?php echo esc_url(add_query_arg('pg', $ka_paged - 1, $base)); ?>"><?php echo kam_icon('arrow-left'); ?>Newer articles</a><?php endif; ?>
                    <span>Page <?php echo (int) $ka_paged; ?> of <?php echo (int) $q->max_num_pages; ?></span>
                    <?php if ($ka_paged < $q->max_num_pages) : ?><a class="ka-btn ka-btn--line" href="<?php echo esc_url(add_query_arg('pg', $ka_paged + 1, $base)); ?>">Older articles<?php echo kam_icon('arrow-right'); ?></a><?php endif; ?>
                </nav>
            <?php endif; ?>
        <?php else : ?>
            <div class="ka-empty">
                <?php echo kam_icon('newspaper'); ?>
                <h2>No articles yet</h2>
                <p>Farming guides and company news will appear here as soon as our team publishes them.</p>
                <?php if (current_user_can('publish_posts')) : ?><p class="ka-empty__actions"><a class="ka-btn ka-btn--forest" href="<?php echo esc_url(admin_url('post-new.php')); ?>">Write the first article</a></p><?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php wp_reset_postdata(); ?>
