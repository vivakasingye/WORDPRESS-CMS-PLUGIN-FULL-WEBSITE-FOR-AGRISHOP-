<?php
if (!defined('ABSPATH')) { exit; }
$projects = kam_projects();
kam_banner('Farm projects', 'Farms we have planned, planted, irrigated and built for our customers.', [['Farm projects', '']]);
?>
<section class="ka-section">
    <div class="ka-wrap">
        <?php if ($projects) : ?>
            <div class="ka-projects"><?php foreach ($projects as $p) { kam_project_card($p); } ?></div>
        <?php else : ?>
            <div class="ka-empty">
                <?php echo kam_icon('image'); ?>
                <h2>Project stories are on their way</h2>
                <p>Our team is preparing photos and write-ups of recent farm projects. In the meantime, see the services we offer or tell us about your own farm plans.</p>
                <p class="ka-empty__actions"><a class="ka-btn ka-btn--forest" href="<?php echo esc_url(kam_url('services')); ?>">See our services</a> <a class="ka-btn ka-btn--line" href="<?php echo esc_url(kam_url('quote')); ?>">Plan a project with us</a></p>
            </div>
        <?php endif; ?>
    </div>
</section>
