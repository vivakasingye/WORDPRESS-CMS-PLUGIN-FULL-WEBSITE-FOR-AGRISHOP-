<?php
if (!defined('ABSPATH')) { exit; }
$faqs = kam_faqs();
kam_banner('Frequently asked questions', 'Answers about ordering, quotations, products and farm services.', [['Help and FAQs', '']]);
?>
<section class="ka-section">
    <div class="ka-wrap ka-faq">
        <div class="ka-faq__list">
            <?php foreach ($faqs as $i => $f) : ?>
                <details class="ka-qa"<?php echo $i === 0 ? ' open' : ''; ?>>
                    <summary><span><?php echo esc_html($f['q']); ?></span><span class="ka-qa__sign" aria-hidden="true"></span></summary>
                    <div class="ka-qa__a ka-prose"><?php echo $f['a']; // Escaped in kam_faqs(). ?></div>
                </details>
            <?php endforeach; ?>
        </div>
        <aside class="ka-faq__side">
            <div class="ka-sidecard ka-sidecard--forest">
                <h2 class="ka-h3">Still have a question?</h2>
                <p>Our team is happy to help with products, quantities and farm plans.</p>
                <?php kam_contact_list(true); ?>
                <a class="ka-btn ka-btn--gold ka-btn--block" href="<?php echo esc_url(kam_url('contact')); ?>">Send us a message</a>
            </div>
        </aside>
    </div>
</section>
<?php
// FAQ structured data helps Google show answers in search results.
if (!kam_seo_plugin_active()) {
    $schema = ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(function ($f) {
        return ['@type' => 'Question', 'name' => $f['q'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => wp_strip_all_tags($f['a'])]];
    }, $faqs)];
    echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
}
?>
