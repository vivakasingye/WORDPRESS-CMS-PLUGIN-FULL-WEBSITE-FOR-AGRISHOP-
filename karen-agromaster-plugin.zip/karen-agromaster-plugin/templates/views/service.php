<?php
if (!defined('ABSPATH')) { exit; }
$svc = kam_item(get_queried_object());
if (!$svc) { return; }
$others = array_values(array_filter(kam_services(), function ($x) use ($svc) { return $x['id'] !== $svc['id']; }));
$wa = kam_whatsapp_url('Hello Karen Agromaster, I would like to discuss ' . $svc['title'] . '.');
$content = trim(wp_strip_all_tags($svc['content'])) !== trim(wp_strip_all_tags($svc['excerpt'])) ? $svc['content'] : '';
kam_banner($svc['title'], $svc['excerpt'], [['Farm services', kam_url('services')], [$svc['title'], '']]);
?>
<section class="ka-section">
    <div class="ka-wrap ka-article-grid">
        <div class="ka-article-grid__main">
            <figure class="ka-wide-media"><?php echo kam_image($svc, 'large', 'ka-wide-media__img', '(max-width: 900px) 100vw, 66vw', true); ?></figure>
            <?php if ($content) : ?><div class="ka-prose"><?php echo apply_filters('the_content', $content); ?></div><?php endif; ?>
            <?php if (!empty($svc['includes'])) : ?>
                <h2 class="ka-h3">What’s included</h2>
                <ul class="ka-checks ka-checks--grid"><?php foreach ($svc['includes'] as $inc) : ?><li><?php echo kam_icon('check'); ?><?php echo esc_html($inc); ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
        </div>
        <aside class="ka-article-grid__side">
            <div class="ka-sidecard">
                <h2 class="ka-h3">Discuss your farm</h2>
                <p>Tell us your location, crop and farm size. We will explain the scope and send a quotation.</p>
                <a class="ka-btn ka-btn--gold ka-btn--block" href="<?php echo esc_url(add_query_arg('service', $svc['id'], kam_url('quote'))); ?>">Request this service</a>
                <?php if ($wa) : ?><a class="ka-btn ka-btn--line ka-btn--block" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener"><?php echo kam_icon('brand-whatsapp'); ?>WhatsApp</a><?php endif; ?>
                <?php kam_contact_list(true); ?>
            </div>
            <?php if ($others) : ?>
                <nav class="ka-sidenav" aria-label="Other services">
                    <h2 class="ka-sidenav__title">Other services</h2>
                    <ul><?php foreach ($others as $o) : ?><li><a href="<?php echo esc_url($o['url']); ?>"><?php echo kam_icon(kam_service_icon($o['title'])); ?><span><?php echo esc_html($o['title']); ?></span></a></li><?php endforeach; ?></ul>
                </nav>
            <?php endif; ?>
        </aside>
    </div>
</section>
