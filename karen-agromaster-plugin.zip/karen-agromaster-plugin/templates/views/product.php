<?php
if (!defined('ABSPATH')) { exit; }
$p = kam_item(get_queried_object());
if (!$p) { return; }
$wa = kam_whatsapp_url('Hello Karen Agromaster, I would like a quotation for ' . $p['title'] . '. Quantity: ');
$related = array_values(array_filter(kam_products(), function ($x) use ($p) { return $x['id'] !== $p['id']; }));
usort($related, function ($a, $b) use ($p) { return (int) ($b['category_slug'] === $p['category_slug']) - (int) ($a['category_slug'] === $p['category_slug']); });
$content = trim(wp_strip_all_tags($p['content'])) !== trim(wp_strip_all_tags($p['excerpt'])) ? $p['content'] : '';
?>
<section class="ka-section ka-section--detail">
    <div class="ka-wrap">
        <?php kam_breadcrumb(array_filter([['Farm shop', kam_url('shop')], $p['category'] ? [$p['category'], $p['category_url']] : null, [$p['title'], '']])); ?>
        <div class="ka-detail">
            <div class="ka-detail__media">
                <?php echo kam_image($p, 'large', 'ka-detail__img', '(max-width: 900px) 100vw, 50vw', true); ?>
                <?php if ($p['badge']) : ?><span class="ka-tag ka-tag--lg"><?php echo esc_html($p['badge']); ?></span><?php endif; ?>
            </div>
            <div class="ka-detail__info">
                <?php if ($p['category']) : ?><a class="ka-detail__cat" href="<?php echo esc_url($p['category_url']); ?>"><?php echo esc_html($p['category']); ?></a><?php endif; ?>
                <h1 class="ka-detail__title"><?php echo esc_html($p['title']); ?></h1>
                <p class="ka-detail__lead"><?php echo esc_html($p['excerpt']); ?></p>
                <div class="ka-detail__price">
                    <?php echo kam_price_html($p); ?>
                    <?php if ($p['availability']) : ?><span class="ka-stock ka-stock--<?php echo esc_attr($p['availability']); ?>"><?php echo esc_html(kam_availability_label($p['availability'])); ?></span><?php endif; ?>
                </div>
                <div class="ka-detail__actions">
                    <?php echo kam_add_button($p, 'detail'); ?>
                    <?php if ($wa) : ?>
                        <a class="ka-btn ka-btn--line ka-btn--lg" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener"><?php echo kam_icon('brand-whatsapp'); ?>Ask on WhatsApp</a>
                    <?php elseif (kam_get('primary_phone')) : ?>
                        <a class="ka-btn ka-btn--line ka-btn--lg" href="<?php echo esc_attr(kam_phone_href(kam_get('primary_phone'))); ?>"><?php echo kam_icon('phone'); ?>Call to order</a>
                    <?php endif; ?>
                </div>
                <?php if ($p['specs']) : ?>
                    <dl class="ka-specs">
                        <?php foreach ($p['specs'] as $sp) : ?><div><dt><?php echo esc_html($sp[0] ?: 'Note'); ?></dt><dd><?php echo esc_html($sp[1]); ?></dd></div><?php endforeach; ?>
                    </dl>
                <?php endif; ?>
                <ul class="ka-assure">
                    <li><?php echo kam_icon('file-text'); ?>Prices and availability are confirmed in your quotation.</li>
                    <li><?php echo kam_icon('headset'); ?>Ask our team which variety or product suits your farm.</li>
                    <?php $names = array_column(kam_locations(), 'name'); if ($names) : $last = array_pop($names); ?>
                    <li><?php echo kam_icon('map-pin'); ?>We are in <?php echo esc_html($names ? implode(', ', $names) . ' and ' . $last : $last); ?>. Ask about collection or delivery.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <?php if ($content) : ?>
            <div class="ka-detail__more">
                <h2 class="ka-h3">About this product</h2>
                <div class="ka-prose"><?php echo apply_filters('the_content', $content); ?></div>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php if ($related) : ?>
<section class="ka-section ka-section--mist">
    <div class="ka-wrap">
        <?php kam_section_head('You may also need', '', [kam_url('shop'), 'Back to the shop']); ?>
        <?php kam_product_grid(array_slice($related, 0, 4)); ?>
    </div>
</section>
<?php endif; ?>
