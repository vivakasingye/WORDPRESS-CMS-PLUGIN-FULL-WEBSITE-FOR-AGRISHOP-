<?php
if (!defined('ABSPATH')) { exit; }
$products = kam_products();
$categories = kam_categories();
$search = isset($_GET['product_search']) && is_scalar($_GET['product_search']) ? sanitize_text_field(wp_unslash($_GET['product_search'])) : '';
$filter = isset($_GET['category_filter']) && is_scalar($_GET['category_filter']) ? sanitize_title(wp_unslash($_GET['category_filter'])) : '';
if (is_tax('kam_category')) { $filter = get_queried_object()->slug; }
$current_cat = null;
foreach ($categories as $c) { if ($c['slug'] === $filter) { $current_cat = $c; } }
if (!$current_cat) { $filter = ''; }
$visible = array_values(array_filter($products, function ($p) use ($search, $filter) {
    return (!$filter || $p['category_slug'] === $filter) && ($search === '' || stripos($p['title'] . ' ' . $p['excerpt'] . ' ' . $p['category'] . ' ' . $p['badge'], $search) !== false);
}));
$title = $current_cat ? $current_cat['name'] : 'Farm shop';
$intro = $current_cat && $current_cat['description'] ? $current_cat['description'] : 'Planting material, crop nutrition, crop protection, commodities and fuel. Add products to your quote basket and we will confirm prices and availability.';
$trail = $current_cat ? [['Farm shop', kam_url('shop')], [$current_cat['name'], '']] : [['Farm shop', '']];
kam_banner($title, $intro, $trail);
?>
<section class="ka-section ka-section--shop">
    <div class="ka-wrap">
        <div class="ka-toolbar" data-shop>
            <form class="ka-toolbar__search" role="search" action="<?php echo esc_url(kam_url('shop')); ?>" method="get">
                <label class="ka-sr" for="ka-shop-search">Search products</label>
                <?php echo kam_icon('search'); ?>
                <input id="ka-shop-search" type="search" name="product_search" value="<?php echo esc_attr($search); ?>" placeholder="Search products" data-shop-search autocomplete="off">
                <?php if ($filter) : ?><input type="hidden" name="category_filter" value="<?php echo esc_attr($filter); ?>"><?php endif; ?>
                <button class="ka-btn ka-btn--forest ka-toolbar__go" type="submit">Search</button>
            </form>
            <div class="ka-chips" role="group" aria-label="Filter by category">
                <a class="ka-chip<?php echo !$filter ? ' is-active' : ''; ?>" href="<?php echo esc_url(kam_url('shop')); ?>" data-chip=""<?php echo !$filter ? ' aria-current="true"' : ''; ?>>All <small><?php echo count($products); ?></small></a>
                <?php foreach ($categories as $c) : ?>
                    <a class="ka-chip<?php echo $filter === $c['slug'] ? ' is-active' : ''; ?>" href="<?php echo esc_url($c['url']); ?>" data-chip="<?php echo esc_attr($c['slug']); ?>"<?php echo $filter === $c['slug'] ? ' aria-current="true"' : ''; ?>><?php echo esc_html($c['name']); ?> <small><?php echo (int) $c['count']; ?></small></a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="ka-shopbar">
            <p class="ka-shopbar__count" data-shop-count aria-live="polite"><?php echo esc_html(count($visible) . ' ' . _n('product', 'products', count($visible), 'karen-agromaster')); ?><?php echo $search !== '' ? esc_html(' for “' . $search . '”') : ''; ?></p>
            <label class="ka-sort"><span>Sort</span>
                <select data-shop-sort>
                    <option value="">Recommended</option>
                    <option value="az">Name A–Z</option>
                    <option value="za">Name Z–A</option>
                </select>
            </label>
        </div>
        <?php if ($products) { kam_product_grid($products, 'ka-pgrid--shop', array_column($visible, 'id')); } ?>
        <div class="ka-empty" data-shop-empty<?php echo $visible ? ' hidden' : ''; ?>>
            <?php echo kam_icon('search'); ?>
            <h2>No products match your search</h2>
            <p>Try a different word, or ask us directly. We may be able to source what you need.</p>
            <p class="ka-empty__actions"><a class="ka-btn ka-btn--forest" href="<?php echo esc_url(kam_url('shop')); ?>">Show all products</a> <a class="ka-btn ka-btn--line" href="<?php echo esc_url(kam_url('quote')); ?>">Ask for a product</a></p>
        </div>
    </div>
</section>
