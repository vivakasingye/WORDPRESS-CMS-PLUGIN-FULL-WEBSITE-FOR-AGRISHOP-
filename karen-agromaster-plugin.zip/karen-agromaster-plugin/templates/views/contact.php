<?php
/** Contact page and Request a Quotation page share this layout. */
if (!defined('ABSPATH')) { exit; }
$ks = kam_settings();
$is_quote = kam_view() === 'quote';
if ($is_quote) {
    kam_banner('Request a quotation', 'Tell us the products or services you need, quantities and your location. Our team will reply with prices and availability.', [['Request a quotation', '']]);
} else {
    kam_banner('Contact us', $ks['contact_description'], [['Contact us', '']]);
}
?>
<section class="ka-section">
    <div class="ka-wrap ka-contact">
        <div class="ka-formcard" id="ka-form">
            <h2 class="ka-h3"><?php echo esc_html($is_quote ? 'Your quotation request' : $ks['contact_heading']); ?></h2>
            <p class="ka-formcard__intro">Fields marked <span class="ka-req">*</span> are required.</p>
            <?php kam_status_notice(); ?>
            <?php kam_enquiry_form($is_quote ? 'quote' : 'contact'); ?>
        </div>
        <aside class="ka-contact__side">
            <div class="ka-sidecard ka-sidecard--forest">
                <h2 class="ka-h3">Prefer to talk?</h2>
                <p>Call or message us and we will help you choose the right products for your farm.</p>
                <?php kam_contact_list(); ?>
            </div>
            <?php if ($is_quote) : ?>
                <div class="ka-sidecard">
                    <h2 class="ka-h3">What happens next</h2>
                    <ol class="ka-mini-steps">
                        <li>We check prices and availability for your list.</li>
                        <li>We call or email you with a quotation.</li>
                        <li>You confirm and we arrange payment and collection or delivery.</li>
                    </ol>
                </div>
            <?php endif; ?>
        </aside>
    </div>
</section>
<?php if (kam_locations()) : ?>
<section class="ka-section ka-section--mist">
    <div class="ka-wrap">
        <?php kam_section_head('Our locations'); ?>
        <?php kam_locations_block(); ?>
    </div>
</section>
<?php endif; ?>
