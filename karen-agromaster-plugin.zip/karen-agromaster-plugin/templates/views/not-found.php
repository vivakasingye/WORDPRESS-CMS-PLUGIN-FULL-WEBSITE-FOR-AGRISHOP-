<?php
if (!defined('ABSPATH')) { exit; }
?>
<section class="ka-section ka-404">
    <div class="ka-wrap ka-404__inner">
        <p class="ka-404__code">404</p>
        <h1 class="ka-h2">We could not find that page</h1>
        <p class="ka-lead">The link may be old or mistyped. Search our products or go back to the homepage.</p>
        <form class="ka-toolbar__search ka-404__search" role="search" action="<?php echo esc_url(kam_url('shop')); ?>" method="get">
            <label class="ka-sr" for="ka-404-search">Search products</label>
            <?php echo kam_icon('search'); ?>
            <input id="ka-404-search" type="search" name="product_search" placeholder="Search products">
            <button class="ka-btn ka-btn--forest ka-toolbar__go" type="submit">Search</button>
        </form>
        <p class="ka-empty__actions"><a class="ka-btn ka-btn--gold" href="<?php echo esc_url(kam_url('home')); ?>">Go to the homepage</a> <a class="ka-btn ka-btn--line" href="<?php echo esc_url(kam_url('contact')); ?>">Contact us</a></p>
    </div>
</section>
