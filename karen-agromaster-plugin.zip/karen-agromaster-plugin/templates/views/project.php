<?php
if (!defined('ABSPATH')) { exit; }
$p = kam_item(get_queried_object());
if (!$p) { return; }
$meta = array_filter(['Location' => $p['location'], 'Crop or work' => $p['crop'], 'Year' => $p['year']]);
kam_banner($p['title'], $p['excerpt'], [['Farm projects', kam_url('projects')], [$p['title'], '']]);
?>
<section class="ka-section">
    <div class="ka-wrap ka-article-grid">
        <div class="ka-article-grid__main">
            <figure class="ka-wide-media"><?php echo kam_image($p, 'large', 'ka-wide-media__img', '(max-width: 900px) 100vw, 66vw', true); ?></figure>
            <div class="ka-prose"><?php echo apply_filters('the_content', $p['content']); ?></div>
        </div>
        <aside class="ka-article-grid__side">
            <?php if ($meta) : ?>
                <dl class="ka-specs ka-specs--card"><?php foreach ($meta as $k => $v) : ?><div><dt><?php echo esc_html($k); ?></dt><dd><?php echo esc_html($v); ?></dd></div><?php endforeach; ?></dl>
            <?php endif; ?>
            <div class="ka-sidecard">
                <h2 class="ka-h3">Planning something similar?</h2>
                <p>Tell us about your land and crop. Our team will visit, plan and quote.</p>
                <a class="ka-btn ka-btn--gold ka-btn--block" href="<?php echo esc_url(kam_url('quote')); ?>">Request a quotation</a>
                <a class="ka-link" href="<?php echo esc_url(kam_url('projects')); ?>"><?php echo kam_icon('arrow-left'); ?>All projects</a>
            </div>
        </aside>
    </div>
</section>
