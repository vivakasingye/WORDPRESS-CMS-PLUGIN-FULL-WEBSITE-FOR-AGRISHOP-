<?php
if (!defined('ABSPATH')) { exit; }
$services = kam_services();
kam_banner('Farm services', kam_get('services_description'), [['Farm services', '']]);
?>
<section class="ka-section">
    <div class="ka-wrap">
        <?php if (!$services) : ?>
            <div class="ka-empty"><?php echo kam_icon('tractor'); ?><h2>Services are being updated</h2><p>Call us or send a request to discuss farm establishment, irrigation, training, security or infrastructure.</p><p class="ka-empty__actions"><a class="ka-btn ka-btn--forest" href="<?php echo esc_url(kam_url('quote')); ?>">Send a request</a></p></div>
        <?php endif; ?>
        <div class="ka-svc-list">
        <?php foreach ($services as $i => $svc) : ?>
            <article class="ka-svc<?php echo $i % 2 ? ' ka-svc--flip' : ''; ?>">
                <a class="ka-svc__media" href="<?php echo esc_url($svc['url']); ?>" tabindex="-1" aria-hidden="true"><?php echo kam_image($svc, 'large', 'ka-svc__img', '(max-width: 900px) 100vw, 50vw', $i === 0); ?></a>
                <div class="ka-svc__body">
                    <span class="ka-svc__icon"><?php echo kam_icon(kam_service_icon($svc['title'])); ?></span>
                    <h2 class="ka-svc__title"><a href="<?php echo esc_url($svc['url']); ?>"><?php echo esc_html($svc['title']); ?></a></h2>
                    <p><?php echo esc_html($svc['excerpt']); ?></p>
                    <?php if (!empty($svc['includes'])) : ?>
                        <ul class="ka-checks"><?php foreach (array_slice($svc['includes'], 0, 4) as $inc) : ?><li><?php echo kam_icon('check'); ?><?php echo esc_html($inc); ?></li><?php endforeach; ?></ul>
                    <?php endif; ?>
                    <div class="ka-svc__actions">
                        <a class="ka-btn ka-btn--forest" href="<?php echo esc_url(add_query_arg('service', $svc['id'], kam_url('quote'))); ?>">Request this service</a>
                        <a class="ka-link" href="<?php echo esc_url($svc['url']); ?>">Read more<?php echo kam_icon('arrow-right'); ?></a>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
        </div>
    </div>
</section>
