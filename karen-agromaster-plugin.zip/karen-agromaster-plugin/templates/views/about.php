<?php
if (!defined('ABSPATH')) { exit; }
$ks = kam_settings();
$about_photo = $ks['about_photo'] ?: kam_uganda_img();
$services = kam_services();
kam_banner('About ' . $ks['business_name'], $ks['tagline'], [['About us', '']]);
?>
<section class="ka-section">
    <div class="ka-wrap ka-split">
        <div class="ka-split__text">
            <h2 class="ka-h2"><?php echo esc_html($ks['about_heading']); ?></h2>
            <p class="ka-lead"><?php echo esc_html($ks['about_description']); ?></p>
            <p>We focus on coffee, cocoa, banana, Hass avocado and forestry planting material, together with the inputs, people and infrastructure needed to run a farm well.</p>
            <p class="ka-split__actions"><a class="ka-btn ka-btn--forest" href="<?php echo esc_url(kam_url('contact')); ?>">Speak with our team</a></p>
        </div>
        <figure class="ka-split__media">
            <?php echo kam_photo_tag($about_photo, kam_img('farm-management.jpg'), 'Coffee and banana growing together on a farm in Uganda', 'ka-split__img', true); ?>
            <?php if (!$ks['about_photo']) : ?><figcaption>Coffee and banana intercropping in Uganda. Photo: Kateregga1, CC BY-SA 4.0.</figcaption><?php endif; ?>
        </figure>
    </div>
</section>

<section class="ka-section ka-section--mist">
    <div class="ka-wrap">
        <?php kam_section_head('What we do'); ?>
        <ul class="ka-pillars">
            <li>
                <span class="ka-pillars__icon"><?php echo kam_icon('sprout'); ?></span>
                <h3>Planting material</h3>
                <p>Coffee, cocoa, Hass avocado, banana and eucalyptus seedlings and suckers for new gardens and estate expansion.</p>
                <a class="ka-link ka-link--sm" href="<?php echo esc_url(kam_url('shop')); ?>">Browse seedlings<?php echo kam_icon('arrow-right'); ?></a>
            </li>
            <li>
                <span class="ka-pillars__icon"><?php echo kam_icon('flask-conical'); ?></span>
                <h3>Farm inputs and commodities</h3>
                <p>Organic and inorganic fertilisers, agricultural lime, crop protection, coffee and cocoa products, and fuel briquettes.</p>
                <a class="ka-link ka-link--sm" href="<?php echo esc_url(kam_url('shop')); ?>">Visit the shop<?php echo kam_icon('arrow-right'); ?></a>
            </li>
            <li>
                <span class="ka-pillars__icon"><?php echo kam_icon('tractor'); ?></span>
                <h3>Farm development</h3>
                <p><?php echo esc_html($services ? implode(', ', array_map(function ($x) { return $x['title']; }, array_slice($services, 0, 5))) . '.' : 'Farm establishment, irrigation, training, security and infrastructure.'); ?></p>
                <a class="ka-link ka-link--sm" href="<?php echo esc_url(kam_url('services')); ?>">See our services<?php echo kam_icon('arrow-right'); ?></a>
            </li>
        </ul>
    </div>
</section>

<?php if (kam_locations()) : ?>
<section class="ka-section">
    <div class="ka-wrap">
        <?php kam_section_head('Our locations', 'Visit us, or call ahead to check what is available near you.'); ?>
        <?php kam_locations_block(); ?>
    </div>
</section>
<?php endif; ?>
