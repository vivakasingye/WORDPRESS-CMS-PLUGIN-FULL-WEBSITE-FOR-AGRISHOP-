<?php
/**
 * Full page document for every Karen Agromaster view. The active theme's
 * header and footer are not used, so the design looks the same with any theme.
 */
if (!defined('ABSPATH')) { exit; }
$kam_view = kam_view();
$ks = kam_settings();
$logo = kam_logo();
$nav = kam_nav_items();
$wa = kam_whatsapp_url('Hello Karen Agromaster, I would like to ask about ');
$no_cta = in_array($kam_view, ['contact', 'quote', '404'], true);
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
// Print exactly one <title>, whatever the theme does. SEO plugins still set its text through wp_get_document_title().
remove_action('wp_head', '_wp_render_title_tag', 1);
remove_action('wp_head', '_block_template_render_title_tag', 1);
// Block themes also add their own viewport tag and font declarations; this page has its own.
remove_action('wp_head', '_block_template_viewport_meta_tag', 0);
remove_action('wp_head', 'wp_print_font_faces', 50);
remove_action('wp_head', 'wp_print_font_faces_from_style_variations', 50);
?>
<title><?php echo esc_html(wp_get_document_title()); ?></title>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php if (function_exists('wp_body_open')) { wp_body_open(); } ?>
<div class="ka-site" style="<?php echo esc_attr(kam_css_vars()); ?>" data-quote-url="<?php echo esc_url(kam_url('quote')); ?>">
<?php readfile(KAM_DIR . 'assets/img/icons.svg'); ?>
<a class="ka-skip" href="#ka-main">Skip to content</a>

<div class="ka-topbar">
    <div class="ka-wrap ka-topbar__inner">
        <p class="ka-topbar__msg"><?php echo kam_icon('sprout'); ?><span><?php echo esc_html($ks['announcement']); ?></span></p>
        <ul class="ka-topbar__links">
            <?php if ($ks['primary_phone']) : ?><li><a href="<?php echo esc_attr(kam_phone_href($ks['primary_phone'])); ?>"><?php echo kam_icon('phone'); ?><?php echo esc_html(kam_phone_display($ks['primary_phone'])); ?></a></li><?php endif; ?>
            <?php if ($wa) : ?><li><a href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener"><?php echo kam_icon('brand-whatsapp'); ?>WhatsApp</a></li><?php endif; ?>
            <?php if ($ks['email']) : ?><li class="ka-topbar__email"><a href="mailto:<?php echo esc_attr($ks['email']); ?>"><?php echo kam_icon('mail'); ?><?php echo esc_html($ks['email']); ?></a></li><?php endif; ?>
        </ul>
    </div>
</div>

<header class="ka-header" data-header>
    <div class="ka-wrap ka-header__inner">
        <a class="ka-brand<?php echo $logo['custom'] ? ' ka-brand--custom' : ''; ?>" href="<?php echo esc_url(kam_url('home')); ?>" aria-label="<?php echo esc_attr($ks['business_name'] . ' home'); ?>">
            <img class="ka-brand__mark" src="<?php echo esc_url($logo['src']); ?>" alt="" width="<?php echo $logo['custom'] ? 180 : 52; ?>" height="<?php echo $logo['custom'] ? 52 : 45; ?>">
            <?php if (!$logo['custom']) : $words = preg_split('/\s+/', trim($ks['business_name']), 2); ?>
                <span class="ka-brand__name"><span><?php echo esc_html($words[0]); ?></span><?php if (!empty($words[1])) : ?><span><?php echo esc_html($words[1]); ?></span><?php endif; ?></span>
            <?php endif; ?>
        </a>

        <nav class="ka-nav" aria-label="Main">
            <ul class="ka-nav__list">
            <?php foreach ($nav as $i => $item) : $has = !empty($item['children']); ?>
                <li class="ka-nav__item<?php echo $has ? ' has-sub' : ''; ?><?php echo $item['current'] ? ' is-current' : ''; ?>">
                    <a class="ka-nav__link" href="<?php echo esc_url($item['url']); ?>"<?php echo $item['current'] ? ' aria-current="page"' : ''; ?><?php echo $item['target'] ? ' target="' . esc_attr($item['target']) . '"' : ''; ?>><?php echo esc_html($item['label']); ?></a>
                    <?php if ($has) : ?>
                        <button class="ka-nav__toggle" type="button" aria-expanded="false" aria-controls="ka-sub-<?php echo (int) $i; ?>"><span class="ka-sr"><?php echo esc_html('Show ' . $item['label'] . ' menu'); ?></span><?php echo kam_icon('chevron-down'); ?></button>
                        <div class="ka-sub" id="ka-sub-<?php echo (int) $i; ?>">
                            <ul>
                            <?php foreach ($item['children'] as $c) : ?>
                                <li><a href="<?php echo esc_url($c['url']); ?>" class="<?php echo !empty($c['all']) ? 'ka-sub__all' : ''; ?>"<?php echo $c['target'] ? ' target="' . esc_attr($c['target']) . '"' : ''; ?>>
                                    <?php if (!empty($c['icon'])) { echo kam_icon($c['icon']); } ?>
                                    <span><?php echo esc_html($c['label']); ?></span>
                                    <?php if (isset($c['count'])) : ?><small><?php echo (int) $c['count']; ?></small><?php endif; ?>
                                    <?php if (!empty($c['all'])) { echo kam_icon('arrow-right'); } ?>
                                </a></li>
                            <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
            </ul>
        </nav>

        <div class="ka-header__actions">
            <button class="ka-iconbtn" type="button" data-search-toggle aria-expanded="false" aria-controls="ka-searchbar"><?php echo kam_icon('search'); ?><span class="ka-sr">Search products</span></button>
            <a class="ka-iconbtn ka-basket-btn" href="<?php echo esc_url(kam_url('quote')); ?>" data-basket-open aria-controls="ka-basket"><?php echo kam_icon('shopping-basket'); ?><span class="ka-count" data-basket-count hidden>0</span><span class="ka-sr">Quote basket</span></a>
            <a class="ka-btn ka-btn--gold ka-header__cta" href="<?php echo esc_url(kam_url('quote')); ?>">Get a quote</a>
            <a class="ka-iconbtn ka-menu-btn" href="#ka-menu" data-menu-open aria-controls="ka-menu" aria-expanded="false"><?php echo kam_icon('menu'); ?><span class="ka-sr">Menu</span></a>
        </div>
    </div>
    <div class="ka-searchbar" id="ka-searchbar" hidden>
        <form class="ka-wrap ka-searchbar__form" role="search" action="<?php echo esc_url(kam_url('shop')); ?>" method="get">
            <label class="ka-sr" for="ka-header-search">Search products</label>
            <?php echo kam_icon('search'); ?>
            <input id="ka-header-search" type="search" name="product_search" placeholder="Search seedlings, coffee, fertilisers…" autocomplete="off">
            <button class="ka-btn ka-btn--forest" type="submit">Search</button>
        </form>
    </div>
</header>

<div class="ka-drawer ka-drawer--menu" id="ka-menu" role="dialog" aria-modal="true" aria-label="Menu" data-drawer="menu">
    <div class="ka-drawer__head">
        <span class="ka-drawer__title">Menu</span>
        <a class="ka-iconbtn" href="#" data-drawer-close><?php echo kam_icon('x'); ?><span class="ka-sr">Close menu</span></a>
    </div>
    <form class="ka-drawer__search" role="search" action="<?php echo esc_url(kam_url('shop')); ?>" method="get">
        <label class="ka-sr" for="ka-menu-search">Search products</label>
        <?php echo kam_icon('search'); ?><input id="ka-menu-search" type="search" name="product_search" placeholder="Search products">
    </form>
    <ul class="ka-mnav">
    <?php foreach ($nav as $item) : ?>
        <li>
        <?php if (!empty($item['children'])) : ?>
            <details<?php echo $item['current'] ? ' open' : ''; ?>>
                <summary><?php echo esc_html($item['label']); ?><?php echo kam_icon('chevron-down'); ?></summary>
                <ul>
                    <?php if ($item['key'] && empty($item['children'][count($item['children']) - 1]['all'])) : ?><li><a href="<?php echo esc_url($item['url']); ?>">All <?php echo esc_html(strtolower($item['label'])); ?></a></li><?php endif; ?>
                    <?php foreach ($item['children'] as $c) : ?><li><a href="<?php echo esc_url($c['url']); ?>"><?php echo esc_html($c['label']); ?></a></li><?php endforeach; ?>
                </ul>
            </details>
        <?php else : ?>
            <a href="<?php echo esc_url($item['url']); ?>"<?php echo $item['current'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html($item['label']); ?></a>
        <?php endif; ?>
        </li>
    <?php endforeach; ?>
        <li><a href="<?php echo esc_url(kam_url('faq')); ?>">Help and FAQs</a></li>
    </ul>
    <div class="ka-drawer__foot">
        <a class="ka-btn ka-btn--gold ka-btn--block" href="<?php echo esc_url(kam_url('quote')); ?>">Request a quotation</a>
        <?php if ($ks['primary_phone']) : ?><a class="ka-btn ka-btn--line ka-btn--block" href="<?php echo esc_attr(kam_phone_href($ks['primary_phone'])); ?>"><?php echo kam_icon('phone'); ?>Call <?php echo esc_html(kam_phone_display($ks['primary_phone'])); ?></a><?php endif; ?>
    </div>
</div>

<main id="ka-main" class="ka-main" tabindex="-1">
<?php
$view_file = KAM_DIR . 'templates/views/' . ($kam_view === '404' ? 'not-found' : $kam_view) . '.php';
if (in_array($kam_view, ['contact', 'quote'], true)) { $view_file = KAM_DIR . 'templates/views/contact.php'; }
if (is_readable($view_file)) { include $view_file; }

// Text added in the WordPress page editor appears below the built-in design.
if (is_page()) {
    $extra = get_post_field('post_content', get_queried_object_id());
    if (is_string($extra) && trim($extra) !== '' && strpos($extra, '[karen_agromaster]') === false) {
        echo '<section class="ka-section ka-section--tight"><div class="ka-wrap ka-prose ka-prose--page">' . apply_filters('the_content', $extra) . '</div></section>';
    }
}
?>
</main>

<?php if (!$no_cta) : ?>
<section class="ka-cta">
    <div class="ka-wrap ka-cta__inner">
        <div class="ka-cta__text">
            <h2 class="ka-cta__title"><?php echo esc_html($ks['cta_heading']); ?></h2>
            <p><?php echo esc_html($ks['cta_description']); ?></p>
        </div>
        <div class="ka-cta__actions">
            <a class="ka-btn ka-btn--forest ka-btn--lg" href="<?php echo esc_url(kam_url('quote')); ?>">Request a quotation</a>
            <?php if ($wa) : ?>
                <a class="ka-btn ka-btn--line-dark ka-btn--lg" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener"><?php echo kam_icon('brand-whatsapp'); ?>WhatsApp us</a>
            <?php elseif ($ks['primary_phone']) : ?>
                <a class="ka-btn ka-btn--line-dark ka-btn--lg" href="<?php echo esc_attr(kam_phone_href($ks['primary_phone'])); ?>"><?php echo kam_icon('phone'); ?>Call <?php echo esc_html(kam_phone_display($ks['primary_phone'])); ?></a>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<footer class="ka-footer">
    <div class="ka-wrap ka-footer__grid">
        <div class="ka-footer__brand">
            <a class="ka-brand ka-brand--light" href="<?php echo esc_url(kam_url('home')); ?>">
                <span class="ka-brand__badge"><img src="<?php echo esc_url($logo['src']); ?>" alt="" width="40" height="36" loading="lazy"></span>
                <span class="ka-brand__name"><?php $words = preg_split('/\s+/', trim($ks['business_name']), 2); ?><span><?php echo esc_html($words[0]); ?></span><?php if (!empty($words[1])) : ?><span><?php echo esc_html($words[1]); ?></span><?php endif; ?></span>
            </a>
            <p><?php echo esc_html($ks['tagline']); ?></p>
            <?php $socials = kam_socials(); if ($socials) : ?>
                <ul class="ka-social">
                <?php foreach ($socials as $so) : ?><li><a href="<?php echo esc_url($so['url']); ?>" target="_blank" rel="noopener"><?php echo kam_icon($so['icon']); ?><span class="ka-sr"><?php echo esc_html($so['label']); ?></span></a></li><?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <div>
            <h2 class="ka-footer__title">Shop</h2>
            <ul class="ka-footer__links">
                <?php foreach (kam_categories() as $c) : ?><li><a href="<?php echo esc_url($c['url']); ?>"><?php echo esc_html($c['name']); ?></a></li><?php endforeach; ?>
                <li><a href="<?php echo esc_url(kam_url('shop')); ?>">All products</a></li>
            </ul>
        </div>
        <div>
            <h2 class="ka-footer__title">Company</h2>
            <ul class="ka-footer__links">
                <?php foreach (['about' => 'About us', 'services' => 'Farm services', 'projects' => 'Projects', 'insights' => 'Farm insights', 'faq' => 'Help and FAQs', 'contact' => 'Contact us'] as $k => $label) : ?>
                    <li><a href="<?php echo esc_url(kam_url($k)); ?>"><?php echo esc_html($label); ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div>
            <h2 class="ka-footer__title">Talk to us</h2>
            <?php kam_contact_list(true); ?>
            <ul class="ka-footer__places">
                <?php foreach (kam_locations() as $l) : ?><li><?php echo kam_icon('map-pin'); ?><span><strong><?php echo esc_html($l['name']); ?></strong> <?php echo esc_html($l['address']); ?></span></li><?php endforeach; ?>
            </ul>
        </div>
    </div>
    <div class="ka-wrap ka-footer__bottom">
        <p>© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html($ks['business_name']); ?>. All rights reserved.</p>
        <?php if (!$ks['hero3_photo'] || !$ks['about_photo']) : ?>
        <p class="ka-footer__credit">Uganda coffee and banana farm photo by Kateregga1, <a href="https://commons.wikimedia.org/wiki/File:Coffee_and_banana_plantation_in_Uganda.jpg" target="_blank" rel="noopener">CC BY-SA 4.0</a>. Other photos are illustrative.</p>
        <?php endif; ?>
    </div>
</footer>

<?php if ($wa && !in_array($kam_view, ['product', 'service', 'contact', 'quote', 'faq'], true)) : ?>
<a class="ka-wa" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener"><?php echo kam_icon('brand-whatsapp'); ?><span class="ka-sr">Chat with us on WhatsApp</span></a>
<?php endif; ?>

<div class="ka-scrim" data-scrim hidden></div>
<div class="ka-drawer ka-drawer--basket" id="ka-basket" role="dialog" aria-modal="true" aria-labelledby="ka-basket-title" data-drawer="basket">
    <div class="ka-drawer__head">
        <div>
            <h2 class="ka-drawer__title" id="ka-basket-title">Quote basket</h2>
            <p class="ka-drawer__sub" data-basket-summary>No products yet</p>
        </div>
        <button class="ka-iconbtn" type="button" data-drawer-close><?php echo kam_icon('x'); ?><span class="ka-sr">Close basket</span></button>
    </div>
    <ul class="ka-basket" data-basket-list></ul>
    <div class="ka-basket-empty" data-basket-empty>
        <?php echo kam_icon('shopping-basket'); ?>
        <p>Add products from the shop and send them to us in one quotation request.</p>
        <a class="ka-btn ka-btn--forest" href="<?php echo esc_url(kam_url('shop')); ?>">Browse the farm shop</a>
    </div>
    <div class="ka-drawer__foot" data-basket-foot hidden>
        <a class="ka-btn ka-btn--gold ka-btn--block ka-btn--lg" href="<?php echo esc_url(kam_url('quote')); ?>">Request a quotation</a>
        <button class="ka-textbtn" type="button" data-basket-clear>Empty basket</button>
        <p class="ka-drawer__note">You will add quantities on the next page. No payment is taken online.</p>
    </div>
</div>
<div class="ka-toast" role="status" aria-live="polite" data-toast></div>
<script type="application/json" id="ka-catalog"><?php echo wp_json_encode(kam_basket_catalog()); ?></script>
</div>
<?php wp_footer(); ?>
</body>
</html>
