# Credits and licences

## Photographs

- **Coffee and banana plantation in Uganda** — Kateregga1, Wikimedia Commons, CC BY-SA 4.0. https://commons.wikimedia.org/wiki/File:Coffee_and_banana_plantation_in_Uganda.jpg — used as hero slide 3 and the About photo until you upload your own. A credit is shown in the footer while it is in use. It is not a Karen Agromaster project.
- **Bundled photos in `assets/img`** (seedlings, coffee, cocoa, fertilisers, agrochemicals, briquettes, irrigation, training, security, infrastructure, farm management) — illustrative concept images carried over from earlier versions, cropped and compressed. They do not show Karen Agromaster staff, premises, stock or projects. Replace them with your own photos before launch.
- **Starter product and service photos** load from Pexels (https://www.pexels.com/license/). If a Pexels image cannot load, the matching bundled photo is shown instead.

## Logo artwork

The A-leaf mark and the sun-and-fields mark in `assets/img/brand` are proposed brand designs from earlier versions. No trademark search has been carried out.

## Software and data

- **Archivo** typeface — The Archivo Project Authors (Omnibus-Type), SIL Open Font License 1.1 (`assets/fonts/OFL-Archivo.txt`).
- **Lucide** icons — ISC licence, https://lucide.dev
- **Simple Icons** brand icons — CC0 1.0, https://simpleicons.org
- **Uganda outline** — Natural Earth (public domain) via the world-atlas package (ISC).
