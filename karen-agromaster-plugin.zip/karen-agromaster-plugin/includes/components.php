<?php
/**
 * Reusable pieces of markup used by the page templates.
 */
if (!defined('ABSPATH')) { exit; }

function kam_icon($name, $class = '') {
    return '<svg class="ka-icon' . ($class ? ' ' . esc_attr($class) : '') . '" aria-hidden="true" focusable="false"><use href="#ka-i-' . esc_attr($name) . '"></use></svg>';
}

/** Product/service/project image: Media Library image with srcset when available, otherwise URL with a bundled fallback. */
function kam_image($item, $size = 'medium_large', $class = '', $sizes = '(max-width: 640px) 50vw, 25vw', $eager = false) {
    $attrs = ['class' => $class, 'alt' => $item['title'], 'decoding' => 'async', 'sizes' => $sizes];
    if (!$eager) { $attrs['loading'] = 'lazy'; } else { $attrs['fetchpriority'] = 'high'; }
    if (!empty($item['thumb_id'])) {
        $html = wp_get_attachment_image($item['thumb_id'], $size, false, $attrs);
        if ($html) { return $html; }
    }
    $src = $item['photo'] ?: $item['fallback'];
    return '<img src="' . esc_url($src) . '" data-fallback="' . esc_url($item['fallback']) . '" alt="' . esc_attr($item['title']) . '" class="' . esc_attr($class) . '"' . ($eager ? ' fetchpriority="high"' : ' loading="lazy"') . ' decoding="async" width="800" height="600">';
}

function kam_photo_tag($url, $fallback, $alt = '', $class = '', $eager = false) {
    return '<img src="' . esc_url($url ?: $fallback) . '" data-fallback="' . esc_url($fallback) . '" alt="' . esc_attr($alt) . '" class="' . esc_attr($class) . '"' . ($eager ? ' fetchpriority="high"' : ' loading="lazy"') . ' decoding="async">';
}

function kam_section_head($title, $intro = '', $link = null, $tag = 'h2') {
    echo '<div class="ka-head"><div class="ka-head__text"><' . $tag . ' class="ka-h2">' . esc_html($title) . '</' . $tag . '>';
    if ($intro) { echo '<p class="ka-lead">' . esc_html($intro) . '</p>'; }
    echo '</div>';
    if ($link) { echo '<a class="ka-link" href="' . esc_url($link[0]) . '">' . esc_html($link[1]) . kam_icon('arrow-right') . '</a>'; }
    echo '</div>';
}

function kam_price_html($p) {
    if (!empty($p['price'])) {
        return '<span class="ka-price"><strong>' . esc_html($p['price']) . '</strong>' . ($p['unit'] ? ' <small>' . esc_html($p['unit']) . '</small>' : '') . '</span>';
    }
    return '<span class="ka-price ka-price--ask">Price on request</span>';
}

function kam_add_button($p, $variant = 'card') {
    $href = add_query_arg('add', (int) $p['id'], kam_url('quote'));
    $label = $variant === 'card' ? 'Add to quote' : 'Add to quote basket';
    return '<a class="ka-add ka-add--' . esc_attr($variant) . '" href="' . esc_url($href) . '" data-add-product="' . (int) $p['id'] . '" data-label="' . esc_attr($label) . '" aria-label="' . esc_attr('Add ' . $p['title'] . ' to quote basket') . '" role="button" aria-pressed="false">' . kam_icon('plus', 'ka-add__plus') . kam_icon('check', 'ka-add__check') . '<span>' . esc_html($label) . '</span></a>';
}

function kam_product_card($p, $hidden = false) {
    $search = strtolower($p['title'] . ' ' . $p['excerpt'] . ' ' . $p['category'] . ' ' . $p['badge']);
    ?>
    <article class="ka-pcard"<?php echo $hidden ? ' hidden' : ''; ?> data-cat="<?php echo esc_attr($p['category_slug']); ?>" data-search="<?php echo esc_attr($search); ?>" data-title="<?php echo esc_attr(strtolower($p['title'])); ?>">
        <a class="ka-pcard__media" href="<?php echo esc_url($p['url']); ?>" tabindex="-1" aria-hidden="true">
            <?php echo kam_image($p, 'medium_large', 'ka-pcard__img'); ?>
            <?php if ($p['badge']) : ?><span class="ka-tag"><?php echo esc_html($p['badge']); ?></span><?php endif; ?>
        </a>
        <div class="ka-pcard__body">
            <?php if ($p['category']) : ?><p class="ka-pcard__cat"><?php echo esc_html($p['category']); ?></p><?php endif; ?>
            <h3 class="ka-pcard__title"><a href="<?php echo esc_url($p['url']); ?>"><?php echo esc_html($p['title']); ?></a></h3>
            <p class="ka-pcard__text"><?php echo esc_html($p['excerpt']); ?></p>
            <div class="ka-pcard__foot">
                <div class="ka-pcard__meta"><?php echo kam_price_html($p); ?>
                <?php if (!empty($p['availability'])) : ?><span class="ka-stock ka-stock--<?php echo esc_attr($p['availability']); ?>"><?php echo esc_html(kam_availability_label($p['availability'])); ?></span><?php endif; ?></div>
                <?php echo kam_add_button($p); ?>
            </div>
        </div>
    </article>
    <?php
}

function kam_product_grid($products, $class = '', $visible_ids = null) {
    echo '<div class="ka-pgrid ' . esc_attr($class) . '" data-product-grid>';
    foreach ($products as $p) { kam_product_card($p, is_array($visible_ids) && !in_array($p['id'], $visible_ids, true)); }
    echo '</div>';
}

function kam_service_icon($title) {
    $t = strtolower($title);
    foreach (['irrigation' => 'droplets', 'water' => 'droplets', 'training' => 'graduation-cap', 'skill' => 'graduation-cap', 'security' => 'shield-check', 'infrastructure' => 'warehouse', 'housing' => 'warehouse', 'establishment' => 'tractor', 'management' => 'tractor'] as $k => $icon) {
        if (strpos($t, $k) !== false) { return $icon; }
    }
    return 'sprout';
}

function kam_post_card($post) {
    $thumb = get_the_post_thumbnail($post, 'medium_large', ['class' => 'ka-post__img', 'loading' => 'lazy', 'alt' => '']);
    ?>
    <article class="ka-post">
        <a class="ka-post__media" href="<?php echo esc_url(get_permalink($post)); ?>" tabindex="-1" aria-hidden="true">
            <?php echo $thumb ?: kam_photo_tag(kam_fallback_image(get_the_title($post)), kam_img('hero-coffee.jpg'), '', 'ka-post__img'); ?>
        </a>
        <div class="ka-post__body">
            <p class="ka-post__date"><time datetime="<?php echo esc_attr(get_the_date('c', $post)); ?>"><?php echo esc_html(get_the_date('j F Y', $post)); ?></time></p>
            <h3 class="ka-post__title"><a href="<?php echo esc_url(get_permalink($post)); ?>"><?php echo esc_html(get_the_title($post)); ?></a></h3>
            <p class="ka-post__text"><?php echo esc_html(wp_trim_words($post->post_excerpt ?: kam_plain($post->post_content), 24)); ?></p>
        </div>
    </article>
    <?php
}

function kam_project_card($p) {
    ?>
    <article class="ka-proj">
        <a class="ka-proj__media" href="<?php echo esc_url($p['url']); ?>" tabindex="-1" aria-hidden="true"><?php echo kam_image($p, 'large', 'ka-proj__img', '(max-width: 800px) 100vw, 50vw'); ?></a>
        <div class="ka-proj__body">
            <?php $meta = array_filter([$p['location'], $p['crop'], $p['year']]); if ($meta) : ?>
                <ul class="ka-proj__meta"><?php foreach ($meta as $m) : ?><li><?php echo esc_html($m); ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
            <h3 class="ka-proj__title"><a href="<?php echo esc_url($p['url']); ?>"><?php echo esc_html($p['title']); ?></a></h3>
            <p><?php echo esc_html($p['excerpt']); ?></p>
        </div>
    </article>
    <?php
}

function kam_breadcrumb($trail) {
    echo '<nav class="ka-crumbs" aria-label="Breadcrumb"><ol><li><a href="' . esc_url(kam_url('home')) . '">Home</a></li>';
    foreach ($trail as $i => $t) {
        $last = $i === count($trail) - 1;
        echo '<li>' . kam_icon('chevron-right') . ($last || empty($t[1]) ? '<span' . ($last ? ' aria-current="page"' : '') . '>' . esc_html($t[0]) . '</span>' : '<a href="' . esc_url($t[1]) . '">' . esc_html($t[0]) . '</a>') . '</li>';
    }
    echo '</ol></nav>';
}

/** Inner-page banner. The field rows from the logo sit in the corner. */
function kam_banner($title, $intro, $trail, $extra = '') {
    ?>
    <section class="ka-banner">
        <div class="ka-wrap ka-banner__inner">
            <?php kam_breadcrumb($trail); ?>
            <h1 class="ka-banner__title"><?php echo esc_html($title); ?></h1>
            <?php if ($intro) : ?><p class="ka-banner__intro"><?php echo esc_html($intro); ?></p><?php endif; ?>
            <?php echo $extra; // Pre-escaped markup from templates. ?>
        </div>
        <?php echo kam_fields_svg('ka-banner__fields'); ?>
    </section>
    <?php
}

/** The striped field rows from the Karen Agromaster logo. */
function kam_fields_svg($class) {
    return '<svg class="' . esc_attr($class) . '" viewBox="0 0 400 160" preserveAspectRatio="none" aria-hidden="true" focusable="false">'
        . '<path class="f-forest" d="M0 160 C 90 92 230 54 400 46 L400 160Z"/>'
        . '<path class="f-leaf" d="M58 160 C 140 108 260 78 400 72 L400 92 C 268 98 162 124 98 160Z"/>'
        . '<path class="f-leaf" d="M172 160 C 236 132 312 116 400 112 L400 130 C 320 134 262 146 222 160Z"/>'
        . '</svg>';
}

/** Hero artwork: photo disc, logo crescent, rising sun and field rows. */
function kam_hero_art($photos) {
    ?>
    <div class="ka-art" aria-hidden="true">
        <svg class="ka-art__sun" viewBox="0 0 200 200" focusable="false">
            <g class="ka-art__rays"><?php for ($i = 0; $i < 12; $i++) : $a = deg2rad($i * 30 + 15); ?><line x1="<?php echo round(100 + cos($a) * 62, 1); ?>" y1="<?php echo round(100 + sin($a) * 62, 1); ?>" x2="<?php echo round(100 + cos($a) * 88, 1); ?>" y2="<?php echo round(100 + sin($a) * 88, 1); ?>"/><?php endfor; ?></g>
            <circle cx="100" cy="100" r="48"/>
        </svg>
        <svg class="ka-art__ring" viewBox="0 0 120 120" focusable="false">
            <defs><mask id="ka-crescent"><rect width="120" height="120" fill="#fff"/><circle cx="63.5" cy="57.5" r="54.2" fill="#000"/></mask></defs>
            <circle cx="60" cy="60" r="58" mask="url(#ka-crescent)"/>
        </svg>
        <div class="ka-art__disc">
            <?php foreach ($photos as $i => $ph) : ?>
                <img class="ka-art__photo<?php echo $i === 0 ? ' is-active' : ''; ?>" data-slide-photo src="<?php echo esc_url($ph[0]); ?>" data-fallback="<?php echo esc_url($ph[1]); ?>" alt="" <?php echo $i === 0 ? 'fetchpriority="high"' : 'loading="lazy"'; ?> decoding="async">
            <?php endforeach; ?>
            <svg class="ka-art__fields" viewBox="0 0 100 100" preserveAspectRatio="none" focusable="false">
                <path class="f-forest" d="M0 70 C 26 63 58 60 100 63 L100 100 L0 100Z"/>
                <path class="f-white" d="M0 76 C 30 68 62 66 100 69 L100 73.5 C 62 71 32 73 0 81Z"/>
                <path class="f-leaf" d="M0 81 C 32 73 62 71 100 73.5 L100 81 C 64 79 34 82 0 90Z"/>
                <path class="f-white" d="M0 92 C 34 84 64 83 100 85 L100 88.5 C 66 87 36 89 0 96Z"/>
                <path class="f-leaf" d="M0 96 C 36 89 66 88 100 88.5 L100 94 C 68 93 40 96 0 100Z"/>
            </svg>
        </div>
    </div>
    <?php
}

function kam_uganda_map() {
    $file = KAM_DIR . 'assets/img/uganda.json';
    $data = is_readable($file) ? json_decode((string) file_get_contents($file), true) : null;
    if (!$data) { return ''; }
    $locs = [];
    foreach (kam_locations() as $l) { $locs[$l['key']] = $l; }
    $label_side = ['Kampala' => ['end', 16, 20], 'Mubende' => ['end', 18, 5], 'Nakaseke' => ['start', 12, -8]];
    ob_start();
    ?>
    <figure class="ka-map">
        <svg viewBox="<?php echo esc_attr($data['viewBox']); ?>" role="img" aria-labelledby="ka-map-title" focusable="false">
            <title id="ka-map-title">Map of Uganda showing Karen Agromaster locations in <?php echo esc_html(implode(', ', array_keys($locs))); ?></title>
            <path class="ka-map__land" d="<?php echo esc_attr($data['d']); ?>"/>
            <?php foreach ($data['pins'] as $name => $xy) : if (!isset($locs[$name])) { continue; } $s = $label_side[$name]; ?>
                <g class="ka-map__pin">
                    <circle class="ka-map__halo" cx="<?php echo esc_attr($xy[0]); ?>" cy="<?php echo esc_attr($xy[1]); ?>" r="13"/>
                    <circle class="ka-map__dot" cx="<?php echo esc_attr($xy[0]); ?>" cy="<?php echo esc_attr($xy[1]); ?>" r="6.5"/>
                    <text x="<?php echo esc_attr($xy[0] + ($s[0] === 'end' ? -$s[1] : $s[1])); ?>" y="<?php echo esc_attr($xy[1] + $s[2]); ?>" text-anchor="<?php echo esc_attr($s[0]); ?>"><?php echo esc_html($name); ?></text>
                </g>
            <?php endforeach; ?>
        </svg>
    </figure>
    <?php
    return ob_get_clean();
}

function kam_status_notice() {
    $status = isset($_GET['kam_status']) && is_scalar($_GET['kam_status']) ? sanitize_key(wp_unslash($_GET['kam_status'])) : '';
    if (!$status) { return; }
    $messages = [
        'received' => ['ok', 'Thank you. Your request has been sent to our team and we will contact you soon.'],
        'saved'    => ['ok', 'Thank you. Your request has been saved and our team will contact you. For anything urgent, please call us.'],
        'invalid'  => ['error', 'Please add your name, a phone number and a short message, then send again.'],
        'limited'  => ['error', 'Your last request was sent a moment ago. Please wait a minute before sending another.'],
        'failed'   => ['error', 'Your request could not be saved. Please try again or call us.'],
    ];
    if (!isset($messages[$status])) { return; }
    $m = $messages[$status];
    echo '<div class="ka-notice ka-notice--' . esc_attr($m[0]) . '" role="' . ($m[0] === 'ok' ? 'status' : 'alert') . '" tabindex="-1" data-notice>' . kam_icon($m[0] === 'ok' ? 'circle-check' : 'circle-alert') . '<p>' . esc_html($m[1]) . '</p></div>';
    if ($status === 'received' || $status === 'saved') { echo '<span data-basket-sent hidden></span>'; }
}

/** Contact and quotation form. Works without JavaScript; the quote basket adds item rows when JavaScript runs. */
function kam_enquiry_form($context = 'contact') {
    $services = kam_services();
    $selected_service = isset($_GET['service']) ? absint($_GET['service']) : 0;
    $prefill = '';
    if (!empty($_GET['add'])) {
        $p = get_post(absint($_GET['add']));
        if ($p && $p->post_type === 'kam_product' && $p->post_status === 'publish') { $prefill = 'I would like a quotation for: ' . $p->post_title . "\nQuantity: "; }
    }
    $ts = (string) time();
    ?>
    <form class="ka-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" data-enquiry-form>
        <input type="hidden" name="action" value="kam_enquiry">
        <input type="hidden" name="kam_context" value="<?php echo esc_attr($context); ?>">
        <input type="hidden" name="kam_ts" value="<?php echo esc_attr($ts . '.' . substr(wp_hash($ts), 0, 12)); ?>">
        <?php wp_nonce_field('kam_enquiry', 'kam_nonce'); ?>
        <div class="ka-hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>

        <?php if ($context === 'quote') : ?>
        <fieldset class="ka-basket-fields" data-basket-fields hidden>
            <legend>Products in your quote basket</legend>
            <p class="ka-field__hint">Add a quantity for each product, for example “500 seedlings” or “10 bags”.</p>
            <div class="ka-basket-fields__list" data-basket-rows></div>
        </fieldset>
        <?php endif; ?>

        <div class="ka-form__grid">
            <p class="ka-field"><label for="ka-f-name">Full name <span class="ka-req" aria-hidden="true">*</span></label><input id="ka-f-name" type="text" name="full_name" required maxlength="100" autocomplete="name"></p>
            <p class="ka-field"><label for="ka-f-phone">Phone or WhatsApp <span class="ka-req" aria-hidden="true">*</span></label><input id="ka-f-phone" type="tel" name="phone" required maxlength="30" autocomplete="tel" inputmode="tel" placeholder="07XX XXX XXX"></p>
            <p class="ka-field"><label for="ka-f-email">Email <span class="ka-opt">optional</span></label><input id="ka-f-email" type="email" name="email" maxlength="160" autocomplete="email"></p>
            <p class="ka-field"><label for="ka-f-loc">Farm location or district <span class="ka-opt">optional</span></label><input id="ka-f-loc" type="text" name="location" maxlength="120" placeholder="e.g. Mubende"></p>
        </div>
        <p class="ka-field"><label for="ka-f-interest">What do you need?</label>
            <select id="ka-f-interest" name="interest">
                <option value="Farm products"<?php selected($context === 'quote' && !$selected_service); ?>>Farm products</option>
                <?php foreach ($services as $svc) : ?><option value="<?php echo esc_attr($svc['title']); ?>"<?php selected($selected_service, $svc['id']); ?>><?php echo esc_html($svc['title']); ?></option><?php endforeach; ?>
                <option value="General enquiry"<?php selected($context !== 'quote' && !$selected_service); ?>>General enquiry</option>
            </select>
        </p>
        <p class="ka-field"><label for="ka-f-msg">Message <span class="ka-req" aria-hidden="true">*</span></label><textarea id="ka-f-msg" name="message" rows="6" required maxlength="5000" placeholder="<?php echo esc_attr($context === 'quote' ? 'Products or services, quantities, and when you need them' : 'How can we help?'); ?>"><?php echo esc_textarea($prefill); ?></textarea></p>
        <p class="ka-check"><input id="ka-f-consent" type="checkbox" name="consent" value="1" required><label for="ka-f-consent">I agree to be contacted about this request.</label></p>
        <div class="ka-form__actions">
            <button class="ka-btn ka-btn--gold ka-btn--lg" type="submit"><?php echo $context === 'quote' ? 'Send quotation request' : 'Send message'; ?><?php echo kam_icon('send'); ?></button>
            <p class="ka-form__note">No payment is taken online. Our team confirms prices and availability with you.</p>
        </div>
    </form>
    <?php
}

function kam_contact_list($compact = false) {
    $s = kam_settings();
    $wa = kam_whatsapp_url('Hello Karen Agromaster, ');
    echo '<ul class="ka-contacts' . ($compact ? ' ka-contacts--compact' : '') . '">';
    foreach (array_filter([$s['primary_phone'], $s['secondary_phone']]) as $i => $ph) {
        echo '<li>' . kam_icon('phone') . '<div><span class="ka-contacts__label">' . ($i ? 'Other line' : 'Call us') . '</span><a href="' . esc_attr(kam_phone_href($ph)) . '">' . esc_html(kam_phone_display($ph)) . '</a></div></li>';
    }
    if ($wa) {
        echo '<li>' . kam_icon('brand-whatsapp') . '<div><span class="ka-contacts__label">WhatsApp</span><a href="' . esc_url($wa) . '" target="_blank" rel="noopener">Chat with us</a></div></li>';
    }
    if ($s['email']) {
        echo '<li>' . kam_icon('mail') . '<div><span class="ka-contacts__label">Email</span><a href="mailto:' . esc_attr($s['email']) . '">' . esc_html($s['email']) . '</a></div></li>';
    }
    if (!$compact) {
        $mgmt = array_filter(['CEO' => $s['ceo_email'], 'CFO' => $s['cfo_email']]);
        foreach ($mgmt as $role => $mail) {
            echo '<li>' . kam_icon('users') . '<div><span class="ka-contacts__label">' . esc_html($role) . '</span><a href="mailto:' . esc_attr($mail) . '">' . esc_html($mail) . '</a></div></li>';
        }
    }
    if ($s['opening_hours']) {
        echo '<li>' . kam_icon('clock') . '<div><span class="ka-contacts__label">Opening hours</span><span>' . esc_html($s['opening_hours']) . '</span></div></li>';
    }
    echo '</ul>';
}

function kam_locations_block() {
    $locs = kam_locations();
    if (!$locs) { return; }
    ?>
    <div class="ka-locs">
        <?php echo kam_uganda_map(); ?>
        <ul class="ka-locs__list">
            <?php foreach ($locs as $l) : ?>
                <li class="ka-loc">
                    <span class="ka-loc__pin"><?php echo kam_icon('map-pin'); ?></span>
                    <div>
                        <h3 class="ka-loc__name"><?php echo esc_html($l['name']); ?></h3>
                        <p class="ka-loc__addr"><?php echo esc_html($l['address']); ?></p>
                        <a class="ka-link ka-link--sm" href="<?php echo esc_url(kam_map_link($l['address'])); ?>" target="_blank" rel="noopener">Get directions<?php echo kam_icon('arrow-up-right'); ?></a>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
}
