<?php
/**
 * Karen Agromaster → Recommended plugins: one-click install and activate
 * using WordPress's own installer (plugins come from wordpress.org).
 */
if (!defined('ABSPATH')) { exit; }

function kam_recommended_plugins() {
    return [
        ['wp-mail-smtp', 'WP Mail SMTP', 'Essential', 'Makes sure enquiry and quotation emails actually reach your inbox. After activating, connect it to your email account (for example Gmail or your hosting email).'],
        ['updraftplus', 'UpdraftPlus Backups', 'Essential', 'Automatic backups of your website and products. Connect it to Google Drive or Dropbox so a copy is kept off your server.'],
        ['wordfence', 'Wordfence Security', 'Essential', 'Firewall and login protection against hackers and spam bots.'],
        ['wordpress-seo', 'Yoast SEO', 'Recommended', 'Helps your pages appear on Google with good titles and descriptions. The website’s built-in tags switch off automatically when Yoast is active.'],
        ['litespeed-cache', 'LiteSpeed Cache', 'Recommended', 'Makes pages load faster. Choose this if your hosting uses a LiteSpeed server (most cPanel hosts in Uganda do); otherwise choose WP Super Cache.'],
        ['wp-super-cache', 'WP Super Cache', 'Optional', 'Page caching for hosts that do not use LiteSpeed. Install only one caching plugin.'],
        ['google-site-kit', 'Site Kit by Google', 'Optional', 'See visitors from Google Analytics and Search Console inside WordPress.'],
        ['wp-smushit', 'Smush', 'Optional', 'Compresses the photos you upload so pages load faster on mobile data.'],
    ];
}

add_action('admin_menu', function () {
    add_submenu_page('kam-settings', 'Recommended plugins', 'Recommended plugins', 'install_plugins', 'kam-plugins', 'kam_plugins_page');
}, 20);

function kam_plugin_file($slug) {
    if (!function_exists('get_plugins')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    foreach (array_keys(get_plugins()) as $file) {
        if (strpos($file, $slug . '/') === 0) { return $file; }
    }
    return '';
}

function kam_plugins_page() {
    if (!current_user_can('install_plugins')) { wp_die('You do not have permission to install plugins.'); }
    $can_install = !defined('DISALLOW_FILE_MODS') || !DISALLOW_FILE_MODS;
    ?>
    <div class="wrap kam-admin">
        <div class="kam-admin__top">
            <div>
                <h1>Recommended plugins</h1>
                <p>Your website design is fully contained in the Karen Agromaster plugin and needs no other plugins. These free plugins keep it safe, fast and visible on Google. Each button uses WordPress’s own installer.</p>
            </div>
        </div>
        <?php if (!$can_install) : ?><div class="notice notice-warning inline"><p>Your hosting has turned off plugin installation from the dashboard. Ask your host to install these for you.</p></div><?php endif; ?>
        <div class="kam-plugin-grid">
        <?php foreach (kam_recommended_plugins() as $p) :
            [$slug, $name, $level, $why] = $p;
            $file = kam_plugin_file($slug);
            $active = $file && is_plugin_active($file);
            ?>
            <div class="kam-card kam-plugin">
                <span class="kam-pill <?php echo $level === 'Essential' ? 'kam-pill--new' : ''; ?>"><?php echo esc_html($level); ?></span>
                <h2><?php echo esc_html($name); ?></h2>
                <p><?php echo esc_html($why); ?></p>
                <div class="kam-plugin__action">
                <?php if ($active) : ?>
                    <span class="kam-plugin__ok"><span class="dashicons dashicons-yes-alt"></span> Active</span>
                <?php elseif ($file) : ?>
                    <a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(self_admin_url('plugins.php?action=activate&plugin=' . rawurlencode($file)), 'activate-plugin_' . $file)); ?>">Activate</a>
                <?php elseif ($can_install) : ?>
                    <a class="button button-primary" href="<?php echo esc_url(wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=' . $slug), 'install-plugin_' . $slug)); ?>">Install now</a>
                <?php endif; ?>
                    <a class="button-link" href="<?php echo esc_url('https://wordpress.org/plugins/' . $slug . '/'); ?>" target="_blank" rel="noopener">Details</a>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
        <p class="description">After installing, WordPress shows an “Activate plugin” link. Come back to this page to install the next one.</p>
    </div>
    <?php
}
