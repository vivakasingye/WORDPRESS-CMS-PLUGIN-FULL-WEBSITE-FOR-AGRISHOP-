<?php
/**
 * Read content from WordPress into simple arrays for the templates.
 */
if (!defined('ABSPATH')) { exit; }

/** Page key => URL of the WordPress page that shows it. */
function kam_url($key) {
    $ids = (array) get_option('kam_mp_page_ids', []);
    if (!empty($ids[$key]) && get_post_status((int) $ids[$key]) === 'publish') {
        return get_permalink((int) $ids[$key]);
    }
    $defs = kam_page_definitions();
    return home_url('/' . ($defs[$key][1] ?? '') . '/');
}
/** v5 name, kept for compatibility. */
function kam_mp_url($key) { return kam_url($key); }

function kam_page_id($key) {
    $ids = (array) get_option('kam_mp_page_ids', []);
    return (int) ($ids[$key] ?? 0);
}

function kam_availability_label($key) {
    $labels = ['available' => 'Available', 'seasonal' => 'Seasonal', 'order' => 'On order', 'out' => 'Out of stock'];
    return $labels[$key] ?? '';
}

/** Normalise a product, service or project post into the fields templates need. */
function kam_item($post) {
    $post = get_post($post);
    if (!$post) { return null; }
    $id = (int) $post->ID;
    $title = get_the_title($post);
    $excerpt = trim((string) $post->post_excerpt) !== '' ? $post->post_excerpt : wp_trim_words(kam_plain($post->post_content), 26);
    $item = [
        'id'       => $id,
        'type'     => $post->post_type,
        'title'    => $title,
        'url'      => get_permalink($post),
        'excerpt'  => $excerpt,
        'content'  => $post->post_content,
        'thumb_id' => (int) get_post_thumbnail_id($post),
        'photo'    => (string) get_post_meta($id, '_kam_photo', true),
        'badge'    => preg_replace('/^\d+\s*\/\s*/', '', (string) get_post_meta($id, '_kam_badge', true)),
        'category' => '',
        'category_slug' => '',
        'category_url'  => '',
    ];
    if ($post->post_type === 'kam_product') {
        $terms = get_the_terms($id, 'kam_category');
        if ($terms && !is_wp_error($terms)) {
            $item['category'] = $terms[0]->name;
            $item['category_slug'] = $terms[0]->slug;
            $item['category_url'] = kam_category_url($terms[0]->slug);
        }
        $item['price'] = (string) get_post_meta($id, '_kam_price', true);
        $item['unit'] = (string) get_post_meta($id, '_kam_unit', true);
        $item['availability'] = (string) get_post_meta($id, '_kam_availability', true);
        $item['specs'] = kam_lines_to_pairs((string) get_post_meta($id, '_kam_specs', true));
        $item['featured'] = (bool) get_post_meta($id, '_kam_featured', true);
    }
    if ($post->post_type === 'kam_service') {
        $item['includes'] = kam_lines((string) get_post_meta($id, '_kam_includes', true));
    }
    if ($post->post_type === 'kam_project') {
        $item['location'] = (string) get_post_meta($id, '_kam_location', true);
        $item['crop'] = (string) get_post_meta($id, '_kam_crop', true);
        $item['year'] = (string) get_post_meta($id, '_kam_year', true);
    }
    $item['fallback'] = kam_fallback_image($title . ' ' . $item['category']);
    $item['image_url'] = $item['thumb_id'] ? (string) wp_get_attachment_image_url($item['thumb_id'], 'medium_large') : ($item['photo'] ?: $item['fallback']);
    return $item;
}

function kam_lines($text) {
    return array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $text))));
}

function kam_lines_to_pairs($text) {
    $out = [];
    foreach (kam_lines($text) as $line) {
        $parts = explode(':', $line, 2);
        $out[] = count($parts) === 2 ? [trim($parts[0]), trim($parts[1])] : ['', $line];
    }
    return $out;
}

function kam_query_items($type, $args = []) {
    static $cache = [];
    $key = $type . md5(wp_json_encode($args));
    if (isset($cache[$key])) { return $cache[$key]; }
    $posts = get_posts(array_merge([
        'post_type' => $type, 'post_status' => 'publish', 'numberposts' => -1,
        'orderby' => ['menu_order' => 'ASC', 'title' => 'ASC'], 'suppress_filters' => false,
    ], $args));
    return $cache[$key] = array_values(array_filter(array_map('kam_item', $posts)));
}

function kam_products() { return kam_query_items('kam_product'); }
function kam_services() { return kam_query_items('kam_service'); }
function kam_projects() { return kam_query_items('kam_project', ['orderby' => ['menu_order' => 'ASC', 'date' => 'DESC']]); }

function kam_featured_products($limit = 8) {
    $all = kam_products();
    $featured = array_values(array_filter($all, function ($p) { return !empty($p['featured']); }));
    return array_slice($featured ?: $all, 0, $limit);
}

function kam_category_url($slug) {
    return add_query_arg('category_filter', $slug, kam_url('shop'));
}

/** Product categories that have products, with a photo for each. */
function kam_categories() {
    static $cats = null;
    if ($cats !== null) { return $cats; }
    $cats = [];
    $products = kam_products();
    $terms = get_terms(['taxonomy' => 'kam_category', 'hide_empty' => false]);
    if (is_wp_error($terms)) { $terms = []; }
    // Categories follow the order of their first product, so reordering products reorders categories too.
    $order = [];
    foreach ($products as $i => $p) { if ($p['category_slug'] !== '' && !isset($order[$p['category_slug']])) { $order[$p['category_slug']] = $i; } }
    usort($terms, function ($a, $b) use ($order) { return ($order[$a->slug] ?? 9999) <=> ($order[$b->slug] ?? 9999); });
    foreach ($terms as $t) {
        $count = 0; $first = null;
        foreach ($products as $p) {
            if ($p['category_slug'] === $t->slug) { $count++; if (!$first) { $first = $p; } }
        }
        if (!$count) { continue; }
        $photo = (string) get_term_meta($t->term_id, 'kam_cat_photo', true);
        $cats[] = [
            'name' => $t->name, 'slug' => $t->slug, 'count' => $count, 'url' => kam_category_url($t->slug),
            'description' => $t->description,
            'image' => $photo ?: kam_fallback_image($t->name . ' ' . $first['title']),
        ];
    }
    return $cats;
}

function kam_faqs() {
    $posts = get_posts(['post_type' => 'kam_faq', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => ['menu_order' => 'ASC', 'date' => 'ASC']]);
    if (!$posts) {
        return array_map(function ($f) { return ['q' => $f[0], 'a' => wpautop(esc_html($f[1]))]; }, kam_seed_faqs());
    }
    return array_map(function ($p) { return ['q' => get_the_title($p), 'a' => wpautop(wp_kses_post($p->post_content))]; }, $posts);
}

function kam_testimonials() {
    $posts = get_posts(['post_type' => 'kam_testimonial', 'post_status' => 'publish', 'numberposts' => 12, 'orderby' => ['menu_order' => 'ASC', 'date' => 'DESC']]);
    return array_map(function ($p) {
        return [
            'name' => get_the_title($p),
            'role' => (string) get_post_meta($p->ID, '_kam_role', true),
            'quote' => wp_strip_all_tags($p->post_content),
            'photo' => get_the_post_thumbnail_url($p, 'thumbnail'),
        ];
    }, $posts);
}

function kam_latest_posts($count = 3, $args = []) {
    return get_posts(array_merge(['post_type' => 'post', 'post_status' => 'publish', 'numberposts' => $count, 'orderby' => 'date', 'order' => 'DESC'], $args));
}

/** Small product list for the quote basket script. */
function kam_basket_catalog() {
    $out = [];
    foreach (kam_products() as $p) {
        $out[] = [
            'id' => (string) $p['id'], 'name' => html_entity_decode($p['title'], ENT_QUOTES, 'UTF-8'), 'category' => html_entity_decode($p['category'], ENT_QUOTES, 'UTF-8'), 'url' => $p['url'],
            'image' => $p['thumb_id'] ? (string) wp_get_attachment_image_url($p['thumb_id'], 'thumbnail') : ($p['photo'] ?: $p['fallback']),
            'fallback' => $p['fallback'],
        ];
    }
    return $out;
}
