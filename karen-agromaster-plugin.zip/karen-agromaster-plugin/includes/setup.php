<?php
/**
 * Activation, starter content, page creation and upgrades from v3–v5.
 * Existing products, services, projects, pages, settings and enquiries are always kept.
 */
if (!defined('ABSPATH')) { exit; }

/** Page key => [title for new installs, slug]. Slugs match v5 so links and SEO are preserved. */
function kam_page_definitions() {
    return [
        'home'     => ['Home', 'karen-agromaster'],
        'shop'     => ['Farm Shop', 'farm-shop'],
        'about'    => ['About Us', 'about-karen-agromaster'],
        'services' => ['Farm Services', 'our-farm-services'],
        'projects' => ['Farm Projects', 'our-farm-projects'],
        'insights' => ['Farm Insights', 'farm-insights'],
        'contact'  => ['Contact Us', 'contact-karen-agromaster'],
        'quote'    => ['Request a Quotation', 'request-farm-quotation'],
        'faq'      => ['Frequently Asked Questions', 'agricultural-faq'],
    ];
}

function kam_activate() {
    kam_register_types();
    if (!get_option('kam_settings')) { add_option('kam_settings', kam_defaults()); }
    kam_seed_content();
    kam_setup_pages();
    kam_run_upgrades();
    flush_rewrite_rules(false);
}

function kam_seed_content() {
    foreach (['Seedlings', 'Coffee & Cocoa', 'Farm Inputs', 'Energy'] as $category) {
        if (!term_exists($category, 'kam_category')) { wp_insert_term($category, 'kam_category'); }
    }
    if (!get_option('kam_seeded_v1')) {
        foreach (kam_seed_catalog() as $index => $item) {
            $id = wp_insert_post([
                'post_type' => 'kam_product', 'post_status' => 'publish', 'post_title' => $item[0],
                'post_excerpt' => $item[2], 'post_content' => $item[2], 'menu_order' => $index,
            ]);
            if (!is_wp_error($id) && $id) {
                wp_set_object_terms($id, $item[1], 'kam_category');
                update_post_meta($id, '_kam_photo', kam_photo_url($item[3]));
                update_post_meta($id, '_kam_badge', $item[4]);
                if ($index < 8) { update_post_meta($id, '_kam_featured', '1'); }
            }
        }
        foreach (kam_seed_services() as $index => $item) {
            $id = wp_insert_post([
                'post_type' => 'kam_service', 'post_status' => 'publish', 'post_title' => $item[0],
                'post_excerpt' => $item[1], 'post_content' => $item[1], 'menu_order' => $index,
            ]);
            if (!is_wp_error($id) && $id) {
                update_post_meta($id, '_kam_photo', kam_photo_url($item[2]));
                update_post_meta($id, '_kam_badge', $item[3]);
                update_post_meta($id, '_kam_includes', $item[4]);
            }
        }
        update_option('kam_seeded_v1', 1);
    }
    if (!get_option('kam_seeded_faq')) {
        $existing = get_posts(['post_type' => 'kam_faq', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids']);
        if (!$existing) {
            foreach (kam_seed_faqs() as $index => $f) {
                wp_insert_post(['post_type' => 'kam_faq', 'post_status' => 'publish', 'post_title' => $f[0], 'post_content' => $f[1], 'menu_order' => $index]);
            }
        }
        update_option('kam_seeded_faq', 1);
    }
}

function kam_setup_pages() {
    $ids = (array) get_option('kam_mp_page_ids', []);
    foreach (kam_page_definitions() as $key => $spec) {
        $page = !empty($ids[$key]) ? get_post((int) $ids[$key]) : null;
        if (!$page || $page->post_type !== 'page' || $page->post_status === 'trash') {
            $page = get_page_by_path($spec[1], OBJECT, 'page');
        }
        if ($page && $page->post_status !== 'trash') {
            $id = (int) $page->ID;
            if ($key === 'home' && trim((string) $page->post_content) === '[karen_agromaster]') {
                wp_update_post(['ID' => $id, 'post_content' => '']);
            }
        } else {
            $id = wp_insert_post([
                'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $spec[0],
                'post_name' => $spec[1], 'post_content' => '',
            ]);
        }
        if (is_wp_error($id) || !$id) { continue; }
        $ids[$key] = (int) $id;
        update_post_meta((int) $id, '_kam_mp_page_type', $key);
    }
    update_option('kam_mp_page_ids', $ids);

    $home_id  = (int) ($ids['home'] ?? 0);
    $front_id = (int) get_option('page_on_front');
    $old_id   = (int) get_option('kam_page_id');
    if ($home_id && (!$front_id || $front_id === $old_id || get_option('show_on_front') !== 'page')) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_id);
    }
    if ($home_id) { update_option('kam_page_id', $home_id); }
    kam_ensure_menu($ids);
}

/** Create a starter menu once, so the header can be edited under Appearance → Menus. */
function kam_ensure_menu($ids) {
    if (get_option('kam_menu_created')) { return; }
    $locations = get_theme_mod('nav_menu_locations', []);
    if (!empty($locations['kam_primary']) && wp_get_nav_menu_object($locations['kam_primary'])) {
        update_option('kam_menu_created', 1);
        return;
    }
    $name = 'Karen Agromaster main menu';
    $menu = wp_get_nav_menu_object($name);
    $menu_id = $menu ? (int) $menu->term_id : wp_create_nav_menu($name);
    if (is_wp_error($menu_id) || !$menu_id) { return; }
    if (!$menu) {
        $labels = ['home' => 'Home', 'shop' => 'Shop', 'services' => 'Services', 'projects' => 'Projects', 'insights' => 'Insights', 'about' => 'About', 'contact' => 'Contact'];
        foreach ($labels as $key => $label) {
            if (empty($ids[$key])) { continue; }
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => (int) $ids[$key],
                'menu-item-type' => 'post_type', 'menu-item-status' => 'publish',
            ]);
        }
    }
    $locations['kam_primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
    update_option('kam_menu_created', 1);
}

/** One-off data changes between versions. */
function kam_run_upgrades() {
    $done = get_option('kam_mp_schema_version');
    if ($done === KAM_VERSION) { return; }

    $saved = get_option('kam_settings');
    if (is_array($saved)) {
        // Sites still on the v5 default palette move to the v6 brand palette; custom colours are kept.
        $legacy = kam_legacy_colors();
        $defaults = kam_defaults();
        $same = true;
        foreach ($legacy as $k => $v) {
            if (isset($saved[$k]) && strcasecmp($saved[$k], $v) !== 0) { $same = false; }
        }
        if ($same) {
            foreach ($legacy as $k => $v) { $saved[$k] = $defaults[$k]; }
        }
        if (!empty($saved['logo_url']) && empty($saved['logo_style'])) { $saved['logo_style'] = 'custom'; }
        update_option('kam_settings', $saved);
    }

    // Give v5 services an editable "What's included" list if they have none.
    $seed = [];
    foreach (kam_seed_services() as $s) { $seed[$s[0]] = $s[4]; }
    foreach (get_posts(['post_type' => 'kam_service', 'numberposts' => -1, 'post_status' => 'any']) as $svc) {
        if (!get_post_meta($svc->ID, '_kam_includes', true) && isset($seed[$svc->post_title])) {
            update_post_meta($svc->ID, '_kam_includes', $seed[$svc->post_title]);
        }
        $badge = (string) get_post_meta($svc->ID, '_kam_badge', true);
        if (preg_match('/^\d+\s*\/\s*/', $badge)) { update_post_meta($svc->ID, '_kam_badge', preg_replace('/^\d+\s*\/\s*/', '', $badge)); }
    }

    update_option('kam_mp_schema_version', KAM_VERSION);
}

/** Upgrades also run when the plugin ZIP is replaced without re-activation. */
add_action('admin_init', function () {
    if (get_option('kam_mp_schema_version') === KAM_VERSION || !current_user_can('manage_options')) { return; }
    kam_seed_content();
    kam_setup_pages();
    kam_run_upgrades();
    flush_rewrite_rules(false);
});
