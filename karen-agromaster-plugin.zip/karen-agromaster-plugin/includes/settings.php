<?php
/**
 * Settings: defaults, getters and small helpers shared by admin and front end.
 */
if (!defined('ABSPATH')) { exit; }

/** Colours shipped with v5. If a site still uses exactly these, the v6 upgrade moves it to the new brand palette. */
function kam_legacy_colors() {
    return ['accent_color' => '#087B53', 'forest_color' => '#083D2B', 'gold_color' => '#CFA66B'];
}

function kam_defaults() {
    return [
        // Brand.
        'business_name'      => 'Karen Agromaster',
        'logo_style'         => 'mark',
        'logo_url'           => '',
        'tagline'            => 'Farm inputs, crop solutions and professional agricultural services for Uganda.',
        'announcement'       => 'Seedlings, farm inputs and farm services for growers across Uganda',
        'forest_color'       => '#0B4D32',
        'accent_color'       => '#6FB23F',
        'gold_color'         => '#F0A92E',

        // Homepage hero (three rotating slides).
        'hero_title'         => 'Shop smart for productive farms in Uganda.',
        'hero_description'   => 'From the right planting materials to end-to-end farm development, Karen Agromaster brings your agricultural ambition to life.',
        'hero_photo'         => '',
        'hero2_title'        => 'Agricultural products, ready for your next season.',
        'hero2_description'  => 'Explore coffee and cocoa products, healthy seedlings, crop protection and fertilisers for every stage of your farm.',
        'hero2_photo'        => '',
        'hero3_title'        => 'From farm inputs to full farm development.',
        'hero3_description'  => 'Professional establishment and management for coffee, cocoa, banana and Hass avocado farms across Uganda.',
        'hero3_photo'        => '',
        'hero_autoplay'      => 'yes',

        // Homepage sections.
        'products_heading'      => 'Agricultural products for every growing stage.',
        'products_description'  => 'Browse planting material, crop nutrition, crop protection, commodities and fuel products. Request a quotation for current availability.',
        'services_heading'      => 'Expertise that takes your farm further.',
        'services_description'  => 'Our teams plan, plant and look after farms, train workers, and install the water, security and buildings a working farm depends on.',
        'about_heading'         => 'Built for the business of farming.',
        'about_description'     => 'Karen Agromaster brings together agricultural inputs, plantation development and on-the-ground services to help growers and investors move from ideas to productive farms.',
        'about_photo'           => '',
        'cta_heading'           => 'Planning a new farm or restocking for the season?',
        'cta_description'       => 'Tell us what you need and where your farm is. Our team will come back with prices, availability and next steps.',
        'contact_heading'       => 'Tell us what you are planning.',
        'contact_description'   => 'Share the products, quantities or farm services you need. Our team can discuss the next steps with you.',
        'show_categories'       => 'yes',
        'show_products'         => 'yes',
        'show_services'         => 'yes',
        'show_process'          => 'yes',
        'show_about'            => 'yes',
        'show_locations'        => 'yes',
        'show_testimonials'     => 'yes',
        'show_insights'         => 'yes',

        // Contact.
        'email'              => 'info@karenagromaster.com',
        'ceo_email'          => 'remmy@karenagromaster.com',
        'cfo_email'          => 'julian@karenagromaster.com',
        'primary_phone'      => '0706701277',
        'secondary_phone'    => '0702782328',
        'whatsapp'           => '',
        'opening_hours'      => '',
        'location_kampala'   => 'Moonlight Plaza Container Village, Kampala',
        'location_mubende'   => 'Kattabalanga, Mubende District',
        'location_nakaseke'  => 'Kiwoko, Nakaseke District',
        'social_facebook'    => '',
        'social_instagram'   => '',
        'social_linkedin'    => '',
        'social_x'           => '',
        'social_youtube'     => '',
        'social_tiktok'      => '',

        // Enquiries.
        'notify_email'       => '',
        'auto_reply'         => 'no',

        // Search engines.
        'meta_description'   => '',

        // Kept for backwards compatibility with v3–v5 settings.
        'standalone_mode'    => 'yes',
    ];
}

function kam_settings($fresh = false) {
    static $cache = null;
    if ($fresh || $cache === null) {
        $cache = wp_parse_args((array) get_option('kam_settings', []), kam_defaults());
    }
    return $cache;
}

function kam_get($key, $fallback = '') {
    $s = kam_settings();
    return isset($s[$key]) && $s[$key] !== '' ? $s[$key] : $fallback;
}

function kam_on($key) {
    return kam_get($key, 'yes') === 'yes';
}

/* ---------- Colour helpers ---------- */

function kam_hex_rgb($hex) {
    $hex = ltrim((string) $hex, '#');
    if (strlen($hex) === 3) { $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2]; }
    if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) { return [0, 0, 0]; }
    return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
}

function kam_rgb_hex($rgb) {
    return sprintf('#%02x%02x%02x', max(0, min(255, (int) round($rgb[0]))), max(0, min(255, (int) round($rgb[1]))), max(0, min(255, (int) round($rgb[2]))));
}

/** Mix colour $a into $b. $amount is the share of $a (0–1). */
function kam_mix($a, $b, $amount) {
    $x = kam_hex_rgb($a); $y = kam_hex_rgb($b);
    return kam_rgb_hex([
        $x[0] * $amount + $y[0] * (1 - $amount),
        $x[1] * $amount + $y[1] * (1 - $amount),
        $x[2] * $amount + $y[2] * (1 - $amount),
    ]);
}

function kam_luminance($hex) {
    $c = array_map(function ($v) {
        $v /= 255;
        return $v <= 0.03928 ? $v / 12.92 : pow(($v + 0.055) / 1.055, 2.4);
    }, kam_hex_rgb($hex));
    return 0.2126 * $c[0] + 0.7152 * $c[1] + 0.0722 * $c[2];
}

function kam_contrast($a, $b) {
    $l1 = kam_luminance($a); $l2 = kam_luminance($b);
    return (max($l1, $l2) + 0.05) / (min($l1, $l2) + 0.05);
}

/** Readable text colour on top of a background colour: dark brand ink or white. */
function kam_text_on($bg, $dark) {
    return kam_contrast($bg, $dark) >= kam_contrast($bg, '#ffffff') ? $dark : '#ffffff';
}

/** All colour tokens are computed here so older mobile browsers never need color-mix(). */
function kam_css_vars() {
    $s = kam_settings();
    $forest = sanitize_hex_color($s['forest_color']) ?: '#0B4D32';
    $leaf   = sanitize_hex_color($s['accent_color']) ?: '#6FB23F';
    $gold   = sanitize_hex_color($s['gold_color']) ?: '#F0A92E';
    $ink    = kam_mix($forest, '#07110b', 0.42);
    $vars = [
        '--ka-forest'      => $forest,
        '--ka-forest-deep' => kam_mix($forest, '#020805', 0.62),
        '--ka-forest-soft' => kam_mix($forest, '#ffffff', 0.86),
        '--ka-leaf'        => $leaf,
        '--ka-leaf-soft'   => kam_mix($leaf, '#ffffff', 0.22),
        '--ka-gold'        => $gold,
        '--ka-gold-deep'   => kam_mix($gold, '#3b2400', 0.82),
        '--ka-gold-soft'   => kam_mix($gold, '#ffffff', 0.2),
        '--ka-ink'         => $ink,
        '--ka-muted'       => kam_mix($ink, '#ffffff', 0.72),
        '--ka-line'        => kam_mix($forest, '#ffffff', 0.14),
        '--ka-mist'        => kam_mix($leaf, '#ffffff', 0.09),
        '--ka-mist-2'      => kam_mix($leaf, '#ffffff', 0.17),
        '--ka-on-forest'   => kam_text_on($forest, $ink),
        '--ka-on-gold'     => kam_text_on($gold, kam_mix($forest, '#000000', 0.8)),
        '--ka-on-leaf'     => kam_text_on($leaf, kam_mix($forest, '#000000', 0.8)),
    ];
    $out = '';
    foreach ($vars as $k => $v) { $out .= $k . ':' . $v . ';'; }
    return $out;
}

/* ---------- Text helpers ---------- */

/** Plain text from post HTML, keeping a space where block tags meet (so "<p>A</p><p>B</p>" becomes "A B"). */
function kam_plain($html) {
    $html = preg_replace('#<(/?)(p|h[1-6]|li|ul|ol|div|br|blockquote|figure|figcaption|tr|td|th|section)\b[^>]*>#i', ' ', strip_shortcodes((string) $html));
    return trim(preg_replace('/\s+/u', ' ', html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES, 'UTF-8')));
}

/* ---------- Links and media helpers ---------- */

function kam_img($name) {
    return KAM_URL . 'assets/img/' . ltrim($name, '/');
}

/** Uganda farm photograph used on v5 (Wikimedia Commons, Kateregga1, CC BY-SA 4.0). */
function kam_uganda_img() {
    return 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Coffee_and_banana_plantation_in_Uganda.jpg/1280px-Coffee_and_banana_plantation_in_Uganda.jpg';
}

/** Pick the bundled photograph that best matches a product, service or category name. */
function kam_fallback_image($text) {
    $t = strtolower((string) $text);
    $map = [
        'briquettes.jpg'      => ['briquette', 'energy', 'fuel', 'charcoal'],
        'agrochemicals.jpg'   => ['pesticide', 'fungicide', 'herbicide', 'chemical', 'weed', 'protection', 'spray'],
        'fertilisers.jpg'     => ['fertili', 'npk', 'urea', 'mop', 'lime', 'soil', 'input', 'manure', 'compost'],
        'seedlings.jpg'       => ['seedling', 'sucker', 'avocado', 'eucalyptus', 'nursery', 'planting'],
        'cocoa.jpg'           => ['cocoa', 'chocolate', 'cacao'],
        'coffee.jpg'          => ['coffee', 'bean', 'commodit'],
        'irrigation.jpg'      => ['irrigation', 'water', 'drip'],
        'farm-training.jpg'   => ['training', 'skills', 'labour', 'labor', 'workshop'],
        'farm-security.jpg'   => ['security', 'cctv', 'fence', 'fencing'],
        'infrastructure.jpg'  => ['infrastructure', 'housing', 'road', 'building', 'store'],
        'farm-management.jpg' => ['establishment', 'management', 'plantation', 'farm', 'project'],
    ];
    foreach ($map as $file => $words) {
        foreach ($words as $w) {
            if (strpos($t, $w) !== false) { return kam_img($file); }
        }
    }
    return kam_img('seedlings.jpg');
}

function kam_logo() {
    $s = kam_settings();
    if ($s['logo_style'] === 'custom' && $s['logo_url']) {
        return ['src' => $s['logo_url'], 'custom' => true];
    }
    // v5 stored an optional logo URL without a style; respect it.
    if ($s['logo_url'] && $s['logo_style'] !== 'sun' && $s['logo_style'] !== 'mark') {
        return ['src' => $s['logo_url'], 'custom' => true];
    }
    return ['src' => kam_img($s['logo_style'] === 'sun' ? 'mark-sun.png' : 'mark-a.png'), 'custom' => false];
}

/** Ugandan local numbers (07…) become +2567… for tel: links. */
function kam_phone_href($phone) {
    $p = preg_replace('/\D+/', '', (string) $phone);
    if ($p === '') { return ''; }
    if (strlen($p) === 10 && $p[0] === '0') { $p = '256' . substr($p, 1); }
    return 'tel:+' . $p;
}

/** Display a 10-digit local number as 0706 701 277. */
function kam_phone_display($phone) {
    $p = preg_replace('/\D+/', '', (string) $phone);
    if (strlen($p) === 10 && $p[0] === '0') { return substr($p, 0, 4) . ' ' . substr($p, 4, 3) . ' ' . substr($p, 7); }
    return trim((string) $phone);
}

function kam_whatsapp_url($text = '') {
    $n = preg_replace('/\D+/', '', (string) kam_get('whatsapp'));
    if ($n === '') { return ''; }
    if (strlen($n) === 10 && $n[0] === '0') { $n = '256' . substr($n, 1); }
    return 'https://wa.me/' . $n . ($text !== '' ? '?text=' . rawurlencode($text) : '');
}

function kam_locations() {
    $s = kam_settings();
    return array_values(array_filter([
        ['key' => 'Kampala',  'name' => 'Kampala',  'address' => $s['location_kampala']],
        ['key' => 'Mubende',  'name' => 'Mubende',  'address' => $s['location_mubende']],
        ['key' => 'Nakaseke', 'name' => 'Nakaseke', 'address' => $s['location_nakaseke']],
    ], function ($l) { return trim($l['address']) !== ''; }));
}

function kam_map_link($address) {
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($address . ', Uganda');
}

function kam_socials() {
    $s = kam_settings();
    $out = [];
    foreach (['facebook' => 'Facebook', 'instagram' => 'Instagram', 'linkedin' => 'LinkedIn', 'x' => 'X', 'youtube' => 'YouTube', 'tiktok' => 'TikTok'] as $k => $label) {
        if (!empty($s['social_' . $k])) { $out[] = ['icon' => 'brand-' . $k, 'label' => $label, 'url' => $s['social_' . $k]]; }
    }
    return $out;
}
