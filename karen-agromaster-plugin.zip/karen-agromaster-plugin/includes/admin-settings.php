<?php
/**
 * Karen Agromaster → Website settings.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', function () {
    $count = kam_new_enquiry_count();
    $bubble = $count ? ' <span class="awaiting-mod count-' . $count . '"><span class="pending-count">' . $count . '</span></span>' : '';
    add_menu_page('Karen Agromaster', 'Karen Agromaster' . $bubble, 'manage_options', 'kam-settings', 'kam_admin_page', 'dashicons-palmtree', 25);
    add_submenu_page('kam-settings', 'Website settings', 'Website settings', 'manage_options', 'kam-settings', 'kam_admin_page');
}, 9);

add_action('admin_menu', function () {
    global $submenu;
    if (empty($submenu['kam-settings'])) { return; }
    $count = kam_new_enquiry_count();
    foreach ($submenu['kam-settings'] as &$item) {
        if ($item[2] === 'edit.php?post_type=kam_enquiry' && $count) {
            $item[0] .= ' <span class="awaiting-mod"><span class="pending-count">' . $count . '</span></span>';
        }
    }
}, 99);

add_action('admin_enqueue_scripts', function ($hook) {
    $screen = get_current_screen();
    $ours = strpos((string) $hook, 'kam-') !== false || ($screen && (in_array($screen->post_type, ['kam_product', 'kam_service', 'kam_project', 'kam_enquiry', 'kam_faq', 'kam_testimonial'], true) || $screen->taxonomy === 'kam_category' || $screen->id === 'dashboard'));
    if (!$ours) { return; }
    wp_enqueue_style('kam-admin', KAM_URL . 'assets/css/admin.css', ['wp-color-picker'], KAM_VERSION);
    wp_enqueue_script('kam-admin', KAM_URL . 'assets/js/admin.js', ['jquery', 'wp-color-picker'], KAM_VERSION, true);
    if (strpos((string) $hook, 'kam-settings') !== false || ($screen && ($screen->base === 'post' || $screen->taxonomy === 'kam_category'))) { wp_enqueue_media(); }
});

add_action('admin_init', function () {
    register_setting('kam_settings_group', 'kam_settings', ['sanitize_callback' => 'kam_sanitize_settings']);
});

function kam_settings_tabs() {
    $hero = [];
    foreach (['' => 1, '2' => 2, '3' => 3] as $p => $n) {
        $hero['hero' . $p . '_title'] = ['Slide ' . $n . ' headline', 'text'];
        $hero[($p === '' ? 'hero' : 'hero' . $p) . '_description'] = ['Slide ' . $n . ' text', 'textarea'];
        $hero['hero' . $p . '_photo'] = ['Slide ' . $n . ' photo', 'image', 'Square or landscape photo at least 900 px wide. Leave empty to use the included photo.'];
    }
    return [
        'brand' => ['Brand & colours', [
            'Identity' => [
                'business_name' => ['Business name', 'text'],
                'tagline' => ['Tagline', 'text', 'Used in the footer and as the homepage description for search engines.'],
                'announcement' => ['Top bar message', 'text'],
                'logo_style' => ['Logo', 'select', '', ['mark' => 'A-leaf mark with name', 'sun' => 'Sun and fields mark with name', 'custom' => 'Upload my own logo']],
                'logo_url' => ['Your own logo', 'image', 'Used when “Upload my own logo” is selected. A wide logo about 300 × 90 px works best.'],
            ],
            'Colours' => [
                'forest_color' => ['Main green', 'color', 'Header text, dark sections and buttons.'],
                'accent_color' => ['Leaf green', 'color', 'Field stripes and highlights.'],
                'gold_color' => ['Sun gold', 'color', 'Main call-to-action buttons. Button text switches between dark and white automatically.'],
            ],
        ]],
        'home' => ['Homepage', [
            'Hero slides' => $hero + ['hero_autoplay' => ['Rotate slides automatically', 'checkbox']],
            'Sections' => [
                'show_categories' => ['Show “Shop by category”', 'checkbox'],
                'show_products' => ['Show products', 'checkbox', 'Products ticked “Show on homepage” appear here. If none are ticked, the first eight are shown.'],
                'products_heading' => ['Products heading', 'text'],
                'products_description' => ['Products introduction', 'textarea'],
                'show_services' => ['Show services', 'checkbox'],
                'services_heading' => ['Services heading', 'text'],
                'services_description' => ['Services introduction', 'textarea'],
                'show_process' => ['Show “How ordering works”', 'checkbox'],
                'show_about' => ['Show about section', 'checkbox'],
                'about_heading' => ['About heading', 'text'],
                'about_description' => ['About text', 'textarea'],
                'about_photo' => ['About photo', 'image', 'Leave empty to use the Uganda coffee and banana farm photo.'],
                'show_locations' => ['Show locations map', 'checkbox'],
                'show_testimonials' => ['Show testimonials', 'checkbox', 'Appears only after you add testimonials under Karen Agromaster → Testimonials.'],
                'show_insights' => ['Show latest insights', 'checkbox', 'Appears only after you publish blog posts.'],
                'cta_heading' => ['Bottom banner heading', 'text', 'Shown above the footer on every page except Contact and Quotation.'],
                'cta_description' => ['Bottom banner text', 'textarea'],
            ],
        ]],
        'contact' => ['Contact details', [
            'Phone and email' => [
                'primary_phone' => ['Main phone', 'tel'],
                'secondary_phone' => ['Second phone', 'tel'],
                'whatsapp' => ['WhatsApp number', 'tel', 'Adds WhatsApp buttons across the site. Example: 0706701277 or 256706701277.'],
                'email' => ['General email', 'email'],
                'ceo_email' => ['CEO email', 'email'],
                'cfo_email' => ['CFO email', 'email'],
                'opening_hours' => ['Opening hours', 'text', 'Example: Mon–Sat, 8:00am–6:00pm. Leave empty to hide.'],
            ],
            'Locations' => [
                'location_kampala' => ['Kampala address', 'text', 'Leave empty to hide this location.'],
                'location_mubende' => ['Mubende address', 'text'],
                'location_nakaseke' => ['Nakaseke address', 'text'],
            ],
            'Contact page' => [
                'contact_heading' => ['Contact heading', 'text'],
                'contact_description' => ['Contact introduction', 'textarea'],
            ],
            'Social media (leave empty to hide)' => [
                'social_facebook' => ['Facebook', 'url'], 'social_instagram' => ['Instagram', 'url'], 'social_linkedin' => ['LinkedIn', 'url'],
                'social_x' => ['X (Twitter)', 'url'], 'social_youtube' => ['YouTube', 'url'], 'social_tiktok' => ['TikTok', 'url'],
            ],
        ]],
        'forms' => ['Enquiries & SEO', [
            'Enquiry emails' => [
                'notify_email' => ['Send new enquiries to', 'email', 'Leave empty to use the general email.'],
                'auto_reply' => ['Email customers a copy of their request', 'checkbox', 'Only when they enter an email address. Needs working email (see Recommended plugins → WP Mail SMTP).'],
            ],
            'Search engines' => [
                'meta_description' => ['Homepage description', 'textarea', 'About 150 characters. Ignored when an SEO plugin such as Yoast is active.'],
            ],
        ]],
    ];
}

function kam_sanitize_settings($input) {
    $output = kam_settings(true);
    if (!is_array($input)) { return $output; }
    $types = [];
    foreach (kam_settings_tabs() as $tab) { foreach ($tab[1] as $fields) { foreach ($fields as $k => $f) { $types[$k] = $f; } } }
    foreach ($input as $key => $value) {
        if (!array_key_exists($key, kam_defaults())) { continue; }
        $f = $types[$key] ?? ['', 'text'];
        $value = is_scalar($value) ? (string) $value : '';
        switch ($f[1]) {
            case 'color':    $output[$key] = sanitize_hex_color($value) ?: kam_defaults()[$key]; break;
            case 'image':
            case 'url':      $output[$key] = esc_url_raw($value); break;
            case 'email':    $output[$key] = sanitize_email($value); break;
            case 'tel':      $output[$key] = preg_replace('/[^+0-9 ]/', '', $value); break;
            case 'textarea': $output[$key] = sanitize_textarea_field($value); break;
            case 'checkbox': $output[$key] = $value === 'yes' ? 'yes' : 'no'; break;
            case 'select':   $output[$key] = array_key_exists($value, $f[3]) ? $value : kam_defaults()[$key]; break;
            default:         $output[$key] = sanitize_text_field($value);
        }
    }
    return $output;
}

function kam_admin_field($key, $f, $value) {
    $id = 'kam-' . $key;
    $name = 'kam_settings[' . $key . ']';
    $type = $f[1];
    echo '<tr><th scope="row">' . ($type === 'checkbox' ? esc_html($f[0]) : '<label for="' . esc_attr($id) . '">' . esc_html($f[0]) . '</label>') . '</th><td>';
    switch ($type) {
        case 'textarea':
            echo '<textarea class="large-text" rows="3" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">' . esc_textarea($value) . '</textarea>'; break;
        case 'color':
            echo '<input class="kam-color" type="text" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" data-default-color="' . esc_attr(kam_defaults()[$key]) . '">'; break;
        case 'checkbox':
            echo '<input type="hidden" name="' . esc_attr($name) . '" value="no"><label class="kam-switch"><input type="checkbox" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="yes" ' . checked($value, 'yes', false) . '><span>' . esc_html($value === 'yes' ? 'On' : 'Off') . '</span></label>'; break;
        case 'select':
            echo '<select id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">';
            foreach ($f[3] as $opt => $label) { echo '<option value="' . esc_attr($opt) . '" ' . selected($value, $opt, false) . '>' . esc_html($label) . '</option>'; }
            echo '</select>'; break;
        case 'image':
            echo '<div class="kam-image-field"><input class="regular-text" type="url" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '" placeholder="https://"> <button type="button" class="button kam-media-pick" data-target="' . esc_attr($id) . '">Choose image</button> <button type="button" class="button-link kam-media-clear" data-target="' . esc_attr($id) . '">Remove</button></div>';
            echo '<div class="kam-image-preview" data-preview-for="' . esc_attr($id) . '">' . ($value ? '<img src="' . esc_url($value) . '" alt="">' : '') . '</div>'; break;
        default:
            $html_type = in_array($type, ['email', 'url', 'tel'], true) ? $type : 'text';
            echo '<input class="regular-text" type="' . esc_attr($html_type) . '" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">';
    }
    if (!empty($f[2])) { echo '<p class="description">' . esc_html($f[2]) . '</p>'; }
    echo '</td></tr>';
}

function kam_setup_checklist() {
    $s = kam_settings();
    $plugins = function_exists('get_plugins') ? get_plugins() : [];
    $smtp = false;
    foreach (array_keys($plugins) as $file) { if (strpos($file, 'smtp') !== false && is_plugin_active($file)) { $smtp = true; } }
    $home_front = (int) get_option('page_on_front') === kam_page_id('home') && get_option('show_on_front') === 'page';
    $tasks = [
        [$home_front, 'Website homepage is set', 'Settings → Reading → A static page → ' . get_the_title(kam_page_id('home')), admin_url('options-reading.php')],
        [(bool) $s['whatsapp'], 'Add your WhatsApp number', 'Shows WhatsApp buttons for customers.', admin_url('admin.php?page=kam-settings&tab=contact')],
        [$smtp, 'Make sure enquiry emails arrive', 'Install WP Mail SMTP and connect your email account.', admin_url('admin.php?page=kam-plugins')],
        [(bool) count(array_filter(kam_products(), function ($p) { return $p['thumb_id']; })), 'Add your own product photos', 'Open a product and set its Product photo.', admin_url('edit.php?post_type=kam_product')],
        [(bool) wp_count_posts('kam_project')->publish, 'Publish your first farm project', 'Show real work you have delivered.', admin_url('post-new.php?post_type=kam_project')],
    ];
    $done = count(array_filter(array_column($tasks, 0)));
    echo '<div class="kam-card kam-checklist"><h2>Setup checklist <span>' . (int) $done . ' of ' . count($tasks) . ' done</span></h2><ul>';
    foreach ($tasks as $t) {
        echo '<li class="' . ($t[0] ? 'is-done' : '') . '"><span class="dashicons ' . ($t[0] ? 'dashicons-yes-alt' : 'dashicons-marker') . '"></span><div><strong>' . esc_html($t[1]) . '</strong><br><span>' . esc_html($t[2]) . '</span></div>' . ($t[0] ? '' : '<a class="button" href="' . esc_url($t[3]) . '">Open</a>') . '</li>';
    }
    echo '</ul></div>';
}

function kam_admin_page() {
    if (!current_user_can('manage_options')) { return; }
    $tabs = kam_settings_tabs();
    $tab = isset($_GET['tab']) && isset($tabs[sanitize_key($_GET['tab'])]) ? sanitize_key($_GET['tab']) : 'brand';
    $s = kam_settings(true);
    ?>
    <div class="wrap kam-admin">
        <div class="kam-admin__top">
            <div>
                <h1><?php echo esc_html($s['business_name']); ?> website</h1>
                <p>Edit the text, photos, colours and contact details shown on your website. Products, services, projects and blog posts are edited in their own menus.</p>
            </div>
            <a class="button button-primary button-hero" href="<?php echo esc_url(kam_url('home')); ?>" target="_blank" rel="noopener">View website</a>
        </div>

        <?php settings_errors(); ?>
        <div class="kam-shortcuts">
            <?php
            $links = [
                ['dashicons-carrot', 'Products', admin_url('edit.php?post_type=kam_product'), wp_count_posts('kam_product')->publish],
                ['dashicons-category', 'Categories', admin_url('edit-tags.php?taxonomy=kam_category&post_type=kam_product'), wp_count_terms(['taxonomy' => 'kam_category'])],
                ['dashicons-admin-tools', 'Services', admin_url('edit.php?post_type=kam_service'), wp_count_posts('kam_service')->publish],
                ['dashicons-images-alt2', 'Projects', admin_url('edit.php?post_type=kam_project'), wp_count_posts('kam_project')->publish],
                ['dashicons-admin-post', 'Insights (blog)', admin_url('edit.php'), wp_count_posts('post')->publish],
                ['dashicons-editor-help', 'FAQs', admin_url('edit.php?post_type=kam_faq'), wp_count_posts('kam_faq')->publish],
                ['dashicons-format-quote', 'Testimonials', admin_url('edit.php?post_type=kam_testimonial'), wp_count_posts('kam_testimonial')->publish],
                ['dashicons-email-alt', 'Enquiries', admin_url('edit.php?post_type=kam_enquiry'), kam_new_enquiry_count() . ' new'],
                ['dashicons-menu', 'Menu', admin_url('nav-menus.php'), ''],
            ];
            foreach ($links as $l) {
                echo '<a class="kam-shortcut" href="' . esc_url($l[2]) . '"><span class="dashicons ' . esc_attr($l[0]) . '"></span><strong>' . esc_html($l[1]) . '</strong><span>' . esc_html(is_wp_error($l[3]) ? '' : (string) $l[3]) . '</span></a>';
            }
            ?>
        </div>

        <div class="kam-admin__cols">
            <div class="kam-admin__main">
                <nav class="nav-tab-wrapper">
                    <?php foreach ($tabs as $key => $t) : ?>
                        <a class="nav-tab <?php echo $key === $tab ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=kam-settings&tab=' . $key)); ?>"><?php echo esc_html($t[0]); ?></a>
                    <?php endforeach; ?>
                </nav>
                <form method="post" action="options.php" class="kam-card">
                    <?php settings_fields('kam_settings_group'); ?>
                    <?php foreach ($tabs[$tab][1] as $group => $fields) : ?>
                        <h2 class="kam-group"><?php echo esc_html($group); ?></h2>
                        <table class="form-table" role="presentation"><tbody>
                        <?php foreach ($fields as $key => $f) { kam_admin_field($key, $f, $s[$key] ?? ''); } ?>
                        </tbody></table>
                    <?php endforeach; ?>
                    <?php submit_button('Save changes'); ?>
                </form>
            </div>
            <aside class="kam-admin__side">
                <?php kam_setup_checklist(); ?>
                <div class="kam-card">
                    <h2>Your website pages</h2>
                    <ul class="kam-pages">
                    <?php foreach (kam_page_definitions() as $key => $d) : $pid = kam_page_id($key); if (!$pid) { continue; } ?>
                        <li><a href="<?php echo esc_url(get_permalink($pid)); ?>" target="_blank" rel="noopener"><?php echo esc_html(get_the_title($pid)); ?></a> <a class="kam-pages__edit" href="<?php echo esc_url(get_edit_post_link($pid)); ?>">Add text</a></li>
                    <?php endforeach; ?>
                    </ul>
                    <p class="description">Each page has a ready-made design. Anything you write in the page editor appears below it.</p>
                </div>
                <div class="kam-card">
                    <h2>Shortcodes</h2>
                    <p class="description">Use these inside any other page or post.</p>
                    <p><code>[kam_products limit="8"]</code><br><code>[kam_products category="seedlings"]</code><br><code>[kam_enquiry_form type="quote"]</code></p>
                </div>
            </aside>
        </div>
    </div>
    <?php
}

add_action('admin_notices', function () {
    $screen = get_current_screen();
    if (!$screen || $screen->id !== 'plugins' || !current_user_can('manage_options') || get_option('kam_v6_notice_dismissed')) { return; }
    echo '<div class="notice notice-success is-dismissible"><p><strong>Karen Agromaster website 6.0 is ready.</strong> Your products, services, pages and enquiries were kept. '
        . '<a href="' . esc_url(admin_url('admin.php?page=kam-settings')) . '">Open website settings</a> or <a href="' . esc_url(admin_url('admin.php?page=kam-plugins')) . '">install the recommended plugins</a>.</p></div>';
});
add_action('admin_init', function () {
    if (isset($_GET['page']) && $_GET['page'] === 'kam-settings' && current_user_can('manage_options')) { update_option('kam_v6_notice_dismissed', 1, false); }
});
