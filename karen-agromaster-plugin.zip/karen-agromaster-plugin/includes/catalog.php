<?php
/**
 * Starter content created on first activation. Everything here can be edited
 * or deleted in the dashboard afterwards; it is never re-created.
 */
if (!defined('ABSPATH')) { exit; }

/** [title, category, description, pexels photo id, badge] */
function kam_seed_catalog() {
    return [
        ['Coffee Seedlings', 'Seedlings', 'Planting material for new coffee gardens and estate expansion.', 7125447, 'Planting material'],
        ['Hass Avocado Seedlings', 'Seedlings', 'Planting material for commercial Hass avocado orchard establishment.', 11669612, 'Popular crop'],
        ['Cocoa Seedlings', 'Seedlings', 'Young cocoa plants for smallholder and commercial cocoa plantations.', 32209937, 'Planting material'],
        ['Banana Suckers', 'Seedlings', 'Banana planting material for productive gardens and farm development.', 2168838, 'Planting material'],
        ['Eucalyptus Seedlings', 'Seedlings', 'Tree seedlings for responsible woodlot and forestry projects.', 30421727, 'Forestry'],
        ['Green Coffee Beans', 'Coffee & Cocoa', 'Unroasted green coffee for trading, processing and buyers.', 37540269, 'Commodity'],
        ['FAQ Coffee', 'Coffee & Cocoa', 'Fair Average Quality coffee offered for bulk sourcing enquiries.', 7125447, 'Commodity'],
        ['Cocoa Beans', 'Coffee & Cocoa', 'Cocoa beans for trading, processing and value-chain buyers.', 14681543, 'Commodity'],
        ['Cocoa Powder & Chocolate', 'Coffee & Cocoa', 'Cocoa-based products for retail, food service and trading enquiries.', 4791267, 'Value added'],
        ['Organic Fertilisers', 'Farm Inputs', 'Organic soil nutrition and soil improvement options.', 32938358, 'Soil health'],
        ['NPK, MOP & Urea', 'Farm Inputs', 'Crop nutrition solutions including key inorganic fertiliser types.', 30839537, 'Crop nutrition'],
        ['Agricultural Lime', 'Farm Inputs', 'Soil improvement input available by enquiry and suitability.', 31321715, 'Soil care'],
        ['Pesticides & Fungicides', 'Farm Inputs', 'Crop protection categories for appropriate, label-compliant application.', 12387342, 'Crop protection'],
        ['Herbicides', 'Farm Inputs', 'Weed management products supplied with responsible handling guidance.', 27147663, 'Weed control'],
        ['Fuel Briquettes', 'Energy', 'Briquettes for household, institutional and business fuel needs.', 34547259, 'Alternative fuel'],
    ];
}

/** [title, description, pexels photo id, badge, what's included] */
function kam_seed_services() {
    return [
        ['Farm Establishment & Management', 'Develop coffee, cocoa, banana and Hass avocado projects with planning, planting and farm-operation support.', 40452966, 'Farm development', "Site visit and farm planning\nLand preparation and planting\nSupply of seedlings and inputs\nOngoing farm management"],
        ['Farm Labour Skills Training', 'Practical field training for planting, pruning, crop care, nursery work and safe input handling.', 32209937, 'Skills development', "Planting and spacing\nPruning and crop care\nNursery management\nSafe handling of farm inputs"],
        ['Irrigation System Installation', 'Farm-specific irrigation planning and installation to support water-efficient agricultural operations.', 31231189, 'Water solutions', "Water source assessment\nSystem design for your crops\nInstallation and testing\nOperator hand-over"],
        ['Farm Security Systems', 'Security setup and infrastructure planning to help protect farm operations and assets.', 30421727, 'Asset protection', "Security assessment\nCamera and lighting setup\nFencing and access planning"],
        ['Farm Infrastructure Development', 'Support for farm housing, access roads and operational infrastructure development.', 15876349, 'Infrastructure', "Farm housing and stores\nAccess roads\nOperational buildings"],
    ];
}

/** [question, answer] — the same answers v5 showed, now editable under Karen Agromaster → FAQs. */
function kam_seed_faqs() {
    return [
        ['Can I buy products directly online?', 'This website collects quotation requests. Prices, specifications, delivery arrangements and payment terms are confirmed directly by the Karen Agromaster team.'],
        ['How do I request a quotation?', 'Add products to your quote basket from the shop, then open the quotation page and tell us quantities and your location. You can also describe what you need on the Request a Quotation page.'],
        ['Do you supply seedlings for commercial farms?', 'Karen Agromaster lists coffee, cocoa, Hass avocado, banana and eucalyptus planting materials. Please ask about current varieties, quantities and availability.'],
        ['Which locations do you serve?', 'We have locations in Kampala, Kattabalanga in Mubende District and Kiwoko in Nakaseke District. Please confirm delivery coverage for your area with our team.'],
        ['Do you provide farm establishment services?', 'Yes. Our services include farm establishment and management, irrigation installation, farm labour training, farm security and infrastructure development.'],
        ['Do you sell pesticides and fertilisers?', 'Yes, we list crop protection products and organic and inorganic fertilisers. Product selection and use should follow the label and applicable requirements; our team can advise.'],
    ];
}

function kam_photo_url($id, $width = 1000) {
    return 'https://images.pexels.com/photos/' . absint($id) . '/pexels-photo-' . absint($id) . '.jpeg?auto=compress&cs=tinysrgb&w=' . absint($width);
}
