<?php
/**
 * Front end: decides which pages the plugin draws, loads assets, and adds
 * titles, meta tags and structured data.
 */
if (!defined('ABSPATH')) { exit; }

/** Which plugin view the current request is, or '' when the theme should handle it. */
function kam_view() {
    static $kind = null;
    if ($kind !== null) { return $kind; }
    $kind = '';
    if (is_admin() || is_feed() || (defined('REST_REQUEST') && REST_REQUEST)) { return $kind; }
    $ids = (array) get_option('kam_mp_page_ids', []);
    if (is_page()) {
        $qid = (int) get_queried_object_id();
        foreach ($ids as $key => $pid) {
            if ($qid && (int) $pid === $qid) { return $kind = $key; }
        }
        return $kind;
    }
    if (is_front_page() && !empty($ids['home']) && (int) get_option('page_on_front') === (int) $ids['home']) { return $kind = 'home'; }
    if (is_tax('kam_category')) { return $kind = 'shop'; }
    if (is_singular('kam_product')) { return $kind = 'product'; }
    if (is_singular('kam_service')) { return $kind = 'service'; }
    if (is_singular('kam_project')) { return $kind = 'project'; }
    if (is_singular('post')) { return $kind = 'article'; }
    if (is_category() || is_tag()) { return $kind = 'insights'; }
    if (is_404()) { return $kind = '404'; }
    return $kind;
}
/** v5 name, kept for compatibility. */
function kam_mp_page_type() { return kam_view(); }

add_filter('template_include', function ($template) {
    return kam_view() ? KAM_DIR . 'templates/shell.php' : $template;
}, 220);

add_action('wp_enqueue_scripts', function () {
    wp_register_style('kam-site', KAM_URL . 'assets/css/site.css', [], KAM_VERSION);
    wp_register_script('kam-site', KAM_URL . 'assets/js/site.js', [], KAM_VERSION, true);
    if (!kam_view()) { return; }
    wp_enqueue_style('kam-site');
    wp_enqueue_script('kam-site');
}, 20);

/** The plugin draws its own header and footer, so the active theme's own CSS and JS are left out of these pages. */
add_action('wp_enqueue_scripts', function () {
    if (!kam_view()) { return; }
    $theme_urls = array_unique([get_stylesheet_directory_uri(), get_template_directory_uri()]);
    foreach ([wp_styles(), wp_scripts()] as $deps) {
        foreach ((array) $deps->queue as $handle) {
            $src = isset($deps->registered[$handle]) ? (string) $deps->registered[$handle]->src : '';
            foreach ($theme_urls as $url) {
                if ($src && strpos($src, $url) === 0) {
                    $deps instanceof WP_Styles ? wp_dequeue_style($handle) : wp_dequeue_script($handle);
                }
            }
        }
    }
}, 999);

add_filter('body_class', function ($classes) {
    if ($v = kam_view()) { $classes[] = 'ka-body'; $classes[] = 'ka-view-' . sanitize_html_class($v); }
    return $classes;
});

add_filter('document_title_parts', function ($parts) {
    $v = kam_view();
    if (!$v) { return $parts; }
    $name = kam_get('business_name', get_bloginfo('name'));
    $titles = ['shop' => 'Farm shop', 'about' => 'About us', 'services' => 'Farm services', 'projects' => 'Farm projects', 'insights' => 'Farm insights', 'contact' => 'Contact us', 'quote' => 'Request a quotation', 'faq' => 'Frequently asked questions'];
    if ($v === 'home') { return ['title' => $name, 'tagline' => kam_get('tagline')]; }
    if (isset($titles[$v]) && is_page()) { $parts['title'] = $titles[$v]; }
    if ($v === 'shop' && is_tax('kam_category')) { $parts['title'] = single_term_title('', false); }
    $parts['site'] = $name;
    return $parts;
}, 20);

function kam_seo_plugin_active() {
    return defined('WPSEO_VERSION') || defined('RANK_MATH_VERSION') || defined('AIOSEO_VERSION') || defined('SEOPRESS_VERSION') || class_exists('The_SEO_Framework\\Load');
}

function kam_meta_description() {
    $v = kam_view();
    $obj = get_queried_object();
    if (in_array($v, ['product', 'service', 'project', 'article'], true) && $obj instanceof WP_Post) {
        $item = $obj->post_excerpt ?: kam_plain($obj->post_content);
        return wp_trim_words($item, 28, '…');
    }
    $map = [
        'home' => kam_get('meta_description', kam_get('tagline')),
        'shop' => 'Browse seedlings, coffee and cocoa, fertilisers, crop protection and fuel briquettes from Karen Agromaster, and request a quotation.',
        'services' => 'Farm establishment and management, labour training, irrigation, farm security and infrastructure across Uganda.',
        'about' => kam_get('about_description'),
        'contact' => 'Contact Karen Agromaster in Kampala, Mubende and Nakaseke by phone, email or the enquiry form.',
        'quote' => 'Request a quotation for farm products and services from Karen Agromaster.',
        'faq' => 'Answers about ordering, quotations, seedlings, farm inputs and services from Karen Agromaster.',
        'projects' => 'Farm projects delivered by Karen Agromaster.',
        'insights' => 'Farming guides, company news and agricultural insights from Karen Agromaster.',
    ];
    return $map[$v] ?? kam_get('tagline');
}

add_action('wp_head', function () {
    $v = kam_view();
    if (!$v) { return; }
    $s = kam_settings();
    echo '<meta name="theme-color" content="' . esc_attr($s['forest_color']) . '">' . "\n";
    echo '<link rel="preload" href="' . esc_url(KAM_URL . 'assets/fonts/archivo-latin-wdth-normal.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
    if (!has_site_icon()) { echo '<link rel="icon" href="' . esc_url(kam_img('favicon.png')) . '" type="image/png">' . "\n"; }
    if (kam_seo_plugin_active()) { return; }
    $desc = kam_meta_description();
    $title = wp_get_document_title();
    $url = is_singular() || is_page() ? get_permalink() : home_url(add_query_arg([]));
    $img = is_singular() && has_post_thumbnail() ? get_the_post_thumbnail_url(null, 'large') : kam_img('hero-coffee.jpg');
    if ($desc) { echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n"; }
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr($s['business_name']) . '">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
    if ($desc) { echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n"; }
    echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:image" content="' . esc_url($img) . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    if ($v === 'home') {
        $org = [
            '@context' => 'https://schema.org', '@type' => 'LocalBusiness', 'name' => $s['business_name'],
            'description' => $s['tagline'], 'url' => home_url('/'), 'image' => kam_img('hero-coffee.jpg'), 'logo' => kam_logo()['src'],
            'email' => $s['email'], 'telephone' => $s['primary_phone'] ? str_replace('tel:', '', kam_phone_href($s['primary_phone'])) : null,
            'address' => array_map(function ($l) { return ['@type' => 'PostalAddress', 'streetAddress' => $l['address'], 'addressLocality' => $l['name'], 'addressCountry' => 'UG']; }, kam_locations()),
            'sameAs' => array_values(array_map(function ($x) { return $x['url']; }, kam_socials())),
        ];
        echo '<script type="application/ld+json">' . wp_json_encode(array_filter($org)) . '</script>' . "\n";
    }
}, 2);

/* ---------- Navigation ---------- */

/** Menu tree from Appearance → Menus, or a built-in menu. Shop and Services get automatic dropdowns. */
function kam_nav_items() {
    $ids = (array) get_option('kam_mp_page_ids', []);
    $view = kam_view();
    $current_id = (int) get_queried_object_id();
    $items = [];
    $locations = get_nav_menu_locations();
    $menu_items = !empty($locations['kam_primary']) ? wp_get_nav_menu_items($locations['kam_primary']) : false;

    if ($menu_items) {
        $legacy = ['home' => 'home', 'products' => 'shop', 'categories' => 'shop', 'shop' => 'shop', 'about' => 'about', 'process' => 'about', 'services' => 'services', 'projects' => 'projects', 'updates' => 'insights', 'insights' => 'insights', 'locations' => 'contact', 'contact' => 'contact', 'quote' => 'quote', 'faq' => 'faq'];
        $by_parent = [];
        foreach ($menu_items as $m) {
            $url = (string) $m->url;
            if (strpos($url, '#') !== false) {
                $frag = substr($url, strpos($url, '#') + 1);
                $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
                $home_path = trim((string) wp_parse_url(kam_url('home'), PHP_URL_PATH), '/');
                if (isset($legacy[$frag]) && ($url[0] === '#' || $path === $home_path || $path === '')) { $url = kam_url($legacy[$frag]); }
            }
            $key = '';
            if ($m->object === 'page') { $key = (string) array_search((int) $m->object_id, array_map('intval', $ids), true); }
            $by_parent[(int) $m->menu_item_parent][] = [
                'id' => (int) $m->ID, 'label' => $m->title, 'url' => $url, 'key' => $key, 'target' => $m->target,
                'current' => ($m->object_id && (int) $m->object_id === $current_id) || ($key && $key === $view),
            ];
        }
        foreach ($by_parent[0] ?? [] as $top) {
            $top['children'] = array_map(function ($c) { return ['label' => $c['label'], 'url' => $c['url'], 'target' => $c['target']]; }, $by_parent[$top['id']] ?? []);
            $items[] = $top;
        }
    } else {
        foreach (['home' => 'Home', 'shop' => 'Shop', 'services' => 'Services', 'projects' => 'Projects', 'insights' => 'Insights', 'about' => 'About', 'contact' => 'Contact'] as $key => $label) {
            $items[] = ['label' => $label, 'url' => kam_url($key), 'key' => $key, 'target' => '', 'current' => $view === $key, 'children' => []];
        }
    }

    foreach ($items as &$it) {
        if ($it['key'] === 'shop' && $view === 'product') { $it['current'] = true; }
        if ($it['key'] === 'services' && $view === 'service') { $it['current'] = true; }
        if ($it['key'] === 'projects' && $view === 'project') { $it['current'] = true; }
        if ($it['key'] === 'insights' && $view === 'article') { $it['current'] = true; }
        if (!empty($it['children'])) { continue; }
        if ($it['key'] === 'shop') {
            foreach (kam_categories() as $c) { $it['children'][] = ['label' => $c['name'], 'url' => $c['url'], 'target' => '', 'count' => $c['count']]; }
            if ($it['children']) { $it['children'][] = ['label' => 'All products', 'url' => kam_url('shop'), 'target' => '', 'all' => true]; }
        }
        if ($it['key'] === 'services') {
            foreach (kam_services() as $svc) { $it['children'][] = ['label' => $svc['title'], 'url' => $svc['url'], 'target' => '', 'icon' => kam_service_icon($svc['title'])]; }
        }
    }
    unset($it);
    return $items;
}

/* ---------- Shortcodes for use inside other pages ---------- */

function kam_shortcode_wrap($html) {
    wp_enqueue_style('kam-site');
    wp_enqueue_script('kam-site');
    add_action('wp_footer', 'kam_print_shortcode_support', 5);
    return '<div class="ka-site ka-embed" style="' . esc_attr(kam_css_vars()) . '" data-quote-url="' . esc_url(kam_url('quote')) . '">' . $html . '</div>';
}

function kam_print_shortcode_support() {
    static $done = false;
    if ($done || kam_view()) { return; }
    $done = true;
    readfile(KAM_DIR . 'assets/img/icons.svg');
    echo '<script type="application/json" id="ka-catalog">' . wp_json_encode(kam_basket_catalog()) . '</script>';
}

add_shortcode('kam_products', function ($atts) {
    $a = shortcode_atts(['category' => '', 'limit' => 8, 'featured' => 'no'], $atts);
    $items = $a['featured'] === 'yes' ? kam_featured_products((int) $a['limit']) : kam_products();
    if ($a['category']) { $items = array_values(array_filter($items, function ($p) use ($a) { return $p['category_slug'] === sanitize_title($a['category']); })); }
    ob_start();
    kam_product_grid(array_slice($items, 0, max(1, (int) $a['limit'])));
    return kam_shortcode_wrap(ob_get_clean());
});

add_shortcode('kam_enquiry_form', function ($atts) {
    $a = shortcode_atts(['type' => 'contact'], $atts);
    ob_start();
    kam_status_notice();
    kam_enquiry_form($a['type'] === 'quote' ? 'quote' : 'contact');
    return kam_shortcode_wrap('<div class="ka-formcard">' . ob_get_clean() . '</div>');
});

/** v3–v4 one-page shortcode: now shows the featured products with a link to the full shop. */
add_shortcode('karen_agromaster', function () {
    ob_start();
    kam_product_grid(kam_featured_products(8));
    echo '<p class="ka-embed__more"><a class="ka-btn ka-btn--forest" href="' . esc_url(kam_url('shop')) . '">Visit the farm shop</a></p>';
    return kam_shortcode_wrap(ob_get_clean());
});

/** WordPress's emoji script is not needed on these pages; skipping it saves mobile data. */
add_action('wp', function () {
    if (!kam_view()) { return; }
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('wp_enqueue_scripts', 'wp_enqueue_emoji_styles');
});
