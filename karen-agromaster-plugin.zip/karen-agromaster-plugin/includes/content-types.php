<?php
/**
 * Content the team edits in the dashboard: products, categories, services,
 * projects, FAQs, testimonials and (read-only) website enquiries.
 */
if (!defined('ABSPATH')) { exit; }

function kam_register_types() {
    register_post_type('kam_product', [
        'labels' => [
            'name' => 'Farm Products', 'singular_name' => 'Farm Product', 'add_new' => 'Add product',
            'add_new_item' => 'Add farm product', 'edit_item' => 'Edit farm product', 'all_items' => 'All products',
            'search_items' => 'Search products', 'not_found' => 'No products yet', 'featured_image' => 'Product photo',
            'set_featured_image' => 'Set product photo', 'menu_name' => 'Farm Products',
        ],
        'public' => true, 'show_in_rest' => true, 'has_archive' => false, 'menu_icon' => 'dashicons-carrot', 'menu_position' => 26,
        'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'page-attributes'], 'rewrite' => ['slug' => 'farm-product'],
    ]);
    register_taxonomy('kam_category', 'kam_product', [
        'labels' => ['name' => 'Product Categories', 'singular_name' => 'Product Category', 'menu_name' => 'Categories', 'add_new_item' => 'Add category'],
        'hierarchical' => true, 'show_in_rest' => true, 'show_admin_column' => true, 'rewrite' => ['slug' => 'farm-category'],
    ]);
    register_post_type('kam_service', [
        'labels' => [
            'name' => 'Farm Services', 'singular_name' => 'Farm Service', 'add_new' => 'Add service', 'add_new_item' => 'Add farm service',
            'edit_item' => 'Edit farm service', 'all_items' => 'All services', 'featured_image' => 'Service photo', 'set_featured_image' => 'Set service photo',
        ],
        'public' => true, 'show_in_rest' => true, 'has_archive' => false, 'menu_icon' => 'dashicons-admin-tools', 'menu_position' => 27,
        'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'page-attributes'], 'rewrite' => ['slug' => 'farm-service'],
    ]);
    register_post_type('kam_project', [
        'labels' => [
            'name' => 'Farm Projects', 'singular_name' => 'Farm Project', 'add_new' => 'Add project', 'add_new_item' => 'Add farm project',
            'edit_item' => 'Edit farm project', 'all_items' => 'All projects', 'featured_image' => 'Project photo', 'set_featured_image' => 'Set project photo',
        ],
        'public' => true, 'show_in_rest' => true, 'has_archive' => false, 'menu_icon' => 'dashicons-images-alt2', 'menu_position' => 28,
        'supports' => ['title', 'editor', 'excerpt', 'thumbnail', 'page-attributes'], 'rewrite' => ['slug' => 'farm-project'],
    ]);
    register_post_type('kam_faq', [
        'labels' => [
            'name' => 'FAQs', 'singular_name' => 'FAQ', 'add_new' => 'Add question', 'add_new_item' => 'Add question',
            'edit_item' => 'Edit question', 'all_items' => 'FAQs', 'not_found' => 'No questions yet',
        ],
        'public' => false, 'show_ui' => true, 'show_in_menu' => 'kam-settings', 'show_in_rest' => true,
        'supports' => ['title', 'editor', 'page-attributes'],
    ]);
    register_post_type('kam_testimonial', [
        'labels' => [
            'name' => 'Testimonials', 'singular_name' => 'Testimonial', 'add_new' => 'Add testimonial', 'add_new_item' => 'Add testimonial',
            'edit_item' => 'Edit testimonial', 'all_items' => 'Testimonials', 'not_found' => 'No testimonials yet',
        ],
        'public' => false, 'show_ui' => true, 'show_in_menu' => 'kam-settings', 'show_in_rest' => true,
        'supports' => ['title', 'editor', 'thumbnail', 'page-attributes'],
    ]);
    register_post_type('kam_enquiry', [
        'labels' => ['name' => 'Website Enquiries', 'singular_name' => 'Website Enquiry', 'all_items' => 'Enquiries', 'edit_item' => 'Enquiry', 'not_found' => 'No enquiries yet'],
        'public' => false, 'show_ui' => true, 'show_in_menu' => 'kam-settings',
        'supports' => ['title'], 'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
    ]);
    register_nav_menus(['kam_primary' => 'Karen Agromaster: Primary navigation']);
}
add_action('init', 'kam_register_types');

add_filter('enter_title_here', function ($text, $post) {
    $map = ['kam_product' => 'Product name', 'kam_service' => 'Service name', 'kam_project' => 'Project name', 'kam_faq' => 'Question', 'kam_testimonial' => 'Customer name'];
    return $map[$post->post_type] ?? $text;
}, 10, 2);

/* ---------- Meta boxes ---------- */

function kam_meta_fields() {
    return [
        'kam_product' => [
            '_kam_price'        => ['Price', 'text', 'Leave empty to show “Price on request”. Example: UGX 2,500'],
            '_kam_unit'         => ['Unit', 'text', 'Example: per seedling, per 50 kg bag'],
            '_kam_availability' => ['Availability', 'select', '', ['' => 'Not shown', 'available' => 'Available', 'seasonal' => 'Seasonal', 'order' => 'On order', 'out' => 'Out of stock']],
            '_kam_badge'        => ['Short label', 'text', 'Shown on the product card. Example: Planting material'],
            '_kam_specs'        => ['Specifications', 'textarea', 'One per line as “Label: value”. Example: Variety: Robusta'],
            '_kam_featured'     => ['Show on homepage', 'checkbox', 'Feature this product in the homepage product section'],
            '_kam_photo'        => ['Photo URL', 'image', 'Used only when no product photo (featured image) is set'],
        ],
        'kam_service' => [
            '_kam_badge'    => ['Short label', 'text', 'Example: Water solutions'],
            '_kam_includes' => ['What’s included', 'textarea', 'One item per line'],
            '_kam_photo'    => ['Photo URL', 'image', 'Used only when no service photo (featured image) is set'],
        ],
        'kam_project' => [
            '_kam_location' => ['Location', 'text', 'Example: Mubende District'],
            '_kam_crop'     => ['Crop or work type', 'text', 'Example: Coffee establishment, 20 acres'],
            '_kam_year'     => ['Year', 'text', 'Example: 2025'],
            '_kam_photo'    => ['Photo URL', 'image', 'Used only when no project photo (featured image) is set'],
        ],
        'kam_testimonial' => [
            '_kam_role' => ['Farm, business or location', 'text', 'Example: Coffee farmer, Mubende'],
        ],
    ];
}

add_action('add_meta_boxes', function () {
    $titles = ['kam_product' => 'Product details', 'kam_service' => 'Service details', 'kam_project' => 'Project details', 'kam_testimonial' => 'About this customer'];
    foreach ($titles as $type => $title) {
        add_meta_box('kam-details', $title, 'kam_render_meta_box', $type, 'normal', 'high');
    }
});

function kam_render_meta_box($post) {
    $fields = kam_meta_fields()[$post->post_type] ?? [];
    wp_nonce_field('kam_save_metadata', 'kam_meta_nonce');
    echo '<div class="kam-meta">';
    foreach ($fields as $key => $f) {
        $id = 'kam' . $key;
        $value = get_post_meta($post->ID, $key, true);
        echo '<div class="kam-meta__row kam-meta__row--' . esc_attr($f[1]) . '">';
        if ($f[1] === 'checkbox') {
            echo '<label><input type="checkbox" name="kam_meta[' . esc_attr($key) . ']" value="1" ' . checked($value, '1', false) . '> <strong>' . esc_html($f[0]) . '</strong></label>';
            echo '<p class="description">' . esc_html($f[2]) . '</p></div>';
            continue;
        }
        echo '<label for="' . esc_attr($id) . '"><strong>' . esc_html($f[0]) . '</strong></label>';
        if ($f[1] === 'textarea') {
            echo '<textarea class="widefat" rows="4" id="' . esc_attr($id) . '" name="kam_meta[' . esc_attr($key) . ']">' . esc_textarea($value) . '</textarea>';
        } elseif ($f[1] === 'select') {
            echo '<select id="' . esc_attr($id) . '" name="kam_meta[' . esc_attr($key) . ']">';
            foreach ($f[3] as $opt => $label) { echo '<option value="' . esc_attr($opt) . '" ' . selected($value, $opt, false) . '>' . esc_html($label) . '</option>'; }
            echo '</select>';
        } elseif ($f[1] === 'image') {
            echo '<div class="kam-image-field"><input class="widefat" type="url" id="' . esc_attr($id) . '" name="kam_meta[' . esc_attr($key) . ']" value="' . esc_attr($value) . '" placeholder="https://">';
            echo '<button type="button" class="button kam-media-pick" data-target="' . esc_attr($id) . '">Choose from Media Library</button></div>';
        } else {
            echo '<input class="widefat" type="text" id="' . esc_attr($id) . '" name="kam_meta[' . esc_attr($key) . ']" value="' . esc_attr($value) . '">';
        }
        if ($f[2]) { echo '<p class="description">' . esc_html($f[2]) . '</p>'; }
        echo '</div>';
    }
    echo '</div>';
}

add_action('save_post', function ($post_id, $post) {
    if (!isset($_POST['kam_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['kam_meta_nonce'])), 'kam_save_metadata')) { return; }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id)) { return; }
    if (!current_user_can('edit_post', $post_id)) { return; }
    $fields = kam_meta_fields()[$post->post_type] ?? [];
    $input = isset($_POST['kam_meta']) && is_array($_POST['kam_meta']) ? wp_unslash($_POST['kam_meta']) : [];
    foreach ($fields as $key => $f) {
        $raw = $input[$key] ?? '';
        if ($f[1] === 'checkbox') { $val = $raw ? '1' : ''; }
        elseif ($f[1] === 'image') { $val = esc_url_raw((string) $raw); }
        elseif ($f[1] === 'textarea') { $val = sanitize_textarea_field((string) $raw); }
        elseif ($f[1] === 'select') { $val = array_key_exists((string) $raw, $f[3]) ? (string) $raw : ''; }
        else { $val = sanitize_text_field((string) $raw); }
        if ($val === '') { delete_post_meta($post_id, $key); } else { update_post_meta($post_id, $key, $val); }
    }
}, 10, 2);

/* ---------- Category photo (term meta) ---------- */

add_action('kam_category_add_form_fields', function () {
    echo '<div class="form-field"><label for="kam_cat_photo">Category photo URL</label><div class="kam-image-field"><input type="url" id="kam_cat_photo" name="kam_cat_photo" value=""><button type="button" class="button kam-media-pick" data-target="kam_cat_photo">Choose from Media Library</button></div><p>Shown on the homepage category tiles. Leave empty to use a matching photo automatically.</p></div>';
    wp_nonce_field('kam_cat_meta', 'kam_cat_nonce');
});
add_action('kam_category_edit_form_fields', function ($term) {
    $v = get_term_meta($term->term_id, 'kam_cat_photo', true);
    echo '<tr class="form-field"><th scope="row"><label for="kam_cat_photo">Category photo URL</label></th><td><div class="kam-image-field"><input type="url" id="kam_cat_photo" name="kam_cat_photo" value="' . esc_attr($v) . '"><button type="button" class="button kam-media-pick" data-target="kam_cat_photo">Choose from Media Library</button></div><p class="description">Shown on the homepage category tiles.</p>';
    wp_nonce_field('kam_cat_meta', 'kam_cat_nonce');
    echo '</td></tr>';
});
$kam_save_term = function ($term_id) {
    if (!isset($_POST['kam_cat_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['kam_cat_nonce'])), 'kam_cat_meta')) { return; }
    if (!current_user_can('manage_categories')) { return; }
    $v = isset($_POST['kam_cat_photo']) ? esc_url_raw(wp_unslash($_POST['kam_cat_photo'])) : '';
    if ($v) { update_term_meta($term_id, 'kam_cat_photo', $v); } else { delete_term_meta($term_id, 'kam_cat_photo'); }
};
add_action('created_kam_category', $kam_save_term);
add_action('edited_kam_category', $kam_save_term);

/* ---------- Admin list columns ---------- */

add_filter('manage_kam_product_posts_columns', function ($cols) {
    $new = [];
    foreach ($cols as $k => $v) {
        if ($k === 'title') { $new['kam_thumb'] = '<span class="screen-reader-text">Photo</span>'; }
        $new[$k] = $v;
        if ($k === 'title') { $new['kam_price'] = 'Price'; $new['kam_availability'] = 'Availability'; $new['kam_featured'] = 'Homepage'; }
    }
    return $new;
});
add_action('manage_kam_product_posts_custom_column', function ($col, $id) {
    if ($col === 'kam_thumb') {
        $src = get_the_post_thumbnail_url($id, 'thumbnail') ?: get_post_meta($id, '_kam_photo', true) ?: kam_fallback_image(get_the_title($id));
        echo '<img src="' . esc_url($src) . '" alt="" width="48" height="48" style="object-fit:cover;border-radius:8px" onerror="this.style.visibility=\'hidden\'">';
    }
    if ($col === 'kam_price') {
        $p = get_post_meta($id, '_kam_price', true);
        echo $p ? esc_html($p . ' ' . get_post_meta($id, '_kam_unit', true)) : '<span style="color:#787c82">On request</span>';
    }
    if ($col === 'kam_availability') {
        $labels = ['available' => 'Available', 'seasonal' => 'Seasonal', 'order' => 'On order', 'out' => 'Out of stock'];
        $a = get_post_meta($id, '_kam_availability', true);
        echo esc_html($labels[$a] ?? '—');
    }
    if ($col === 'kam_featured') {
        echo get_post_meta($id, '_kam_featured', true) ? '<span class="dashicons dashicons-star-filled" style="color:#dba617" title="Featured on homepage"></span>' : '';
    }
}, 10, 2);

foreach (['kam_service', 'kam_project'] as $kam_type) {
    add_filter("manage_{$kam_type}_posts_columns", function ($cols) {
        $new = [];
        foreach ($cols as $k => $v) {
            if ($k === 'title') { $new['kam_thumb'] = '<span class="screen-reader-text">Photo</span>'; }
            $new[$k] = $v;
        }
        return $new;
    });
    add_action("manage_{$kam_type}_posts_custom_column", function ($col, $id) {
        if ($col !== 'kam_thumb') { return; }
        $src = get_the_post_thumbnail_url($id, 'thumbnail') ?: get_post_meta($id, '_kam_photo', true) ?: kam_fallback_image(get_the_title($id));
        echo '<img src="' . esc_url($src) . '" alt="" width="48" height="48" style="object-fit:cover;border-radius:8px" onerror="this.style.visibility=\'hidden\'">';
    }, 10, 2);
}

/* Products, services and the rest use the classic edit screen, so price, photo and details sit right under the title. */
add_filter('use_block_editor_for_post_type', function ($use, $type) {
    return in_array($type, ['kam_product', 'kam_service', 'kam_project', 'kam_faq', 'kam_testimonial', 'kam_enquiry'], true) ? false : $use;
}, 10, 2);

add_filter('display_post_states', function ($states, $post) {
    if ($post->post_type === 'kam_enquiry') { unset($states['private']); }
    return $states;
}, 10, 2);
