<?php
/**
 * Contact and quotation requests: saving, email notification and the
 * Enquiries screen in the dashboard.
 */
if (!defined('ABSPATH')) { exit; }

function kam_enquiry_handler() {
    $context = isset($_POST['kam_context']) && $_POST['kam_context'] === 'quote' ? 'quote' : 'contact';
    $fallback = kam_url($context);
    $target = wp_validate_redirect(wp_get_referer() ?: '', $fallback);
    $target = remove_query_arg(['kam_status', 'add'], $target);
    $redirect = function ($status) use ($target) {
        wp_safe_redirect(add_query_arg('kam_status', $status, $target) . '#ka-form');
        exit;
    };

    // Logged-in users are protected against cross-site requests with a nonce. Anonymous visitors are not:
    // a cached page may hold an expired nonce, so spam is stopped with the honeypot, timer and rate limit instead.
    if (is_user_logged_in() && (!isset($_POST['kam_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['kam_nonce'])), 'kam_enquiry'))) { $redirect('invalid'); }
    if (!empty($_POST['website'])) { $redirect('received'); }
    $ts = isset($_POST['kam_ts']) ? sanitize_text_field(wp_unslash($_POST['kam_ts'])) : '';
    $parts = explode('.', $ts);
    if (count($parts) !== 2 || !hash_equals(substr(wp_hash($parts[0]), 0, 12), $parts[1]) || time() - (int) $parts[0] < 3) { $redirect('received'); }
    if (empty($_POST['consent'])) { $redirect('invalid'); }

    $name = sanitize_text_field(wp_unslash($_POST['full_name'] ?? ''));
    $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $phone = sanitize_text_field(wp_unslash($_POST['phone'] ?? ''));
    $location = sanitize_text_field(wp_unslash($_POST['location'] ?? ''));
    $interest = sanitize_text_field(wp_unslash($_POST['interest'] ?? ''));
    $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
    if ($email && !is_email($email)) { $email = ''; }
    if ($name === '' || $message === '' || strlen($message) > 5000 || preg_replace('/\D+/', '', $phone) === '') { $redirect('invalid'); }

    $items = [];
    if (!empty($_POST['items']) && is_array($_POST['items'])) {
        foreach (array_slice(wp_unslash($_POST['items']), 0, 60, true) as $pid => $qty) {
            $p = get_post(absint($pid));
            if ($p && $p->post_type === 'kam_product') {
                $items[] = ['id' => (int) $p->ID, 'name' => html_entity_decode($p->post_title, ENT_QUOTES, 'UTF-8'), 'qty' => substr(sanitize_text_field((string) $qty), 0, 60)];
            }
        }
    }

    // Rate limit per visitor. Behind Cloudflare or a proxy many visitors share one REMOTE_ADDR, so the forwarded
    // client address and browser are included too. Nothing here is stored with the enquiry.
    $source = '';
    foreach (['REMOTE_ADDR', 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_USER_AGENT'] as $h) {
        $source .= '|' . (isset($_SERVER[$h]) ? substr(sanitize_text_field(wp_unslash($_SERVER[$h])), 0, 200) : '');
    }
    $limit_key = 'kam_enquiry_' . substr(hash_hmac('sha256', $source, wp_salt('auth')), 0, 32);
    if (get_transient($limit_key)) { $redirect('limited'); }
    set_transient($limit_key, 1, 30);

    $item_lines = '';
    foreach ($items as $i => $it) { $item_lines .= ($i + 1) . '. ' . $it['name'] . ($it['qty'] !== '' ? ' — ' . $it['qty'] : '') . "\n"; }
    $summary = "Name: {$name}\nPhone: {$phone}\nEmail: " . ($email ?: '—') . "\nLocation: " . ($location ?: '—') . "\nInterested in: {$interest}\nForm: " . ($context === 'quote' ? 'Quotation request' : 'Contact') . "\n"
        . ($item_lines ? "\nProducts requested:\n{$item_lines}" : '') . "\nMessage:\n{$message}\n";

    $id = wp_insert_post([
        'post_type' => 'kam_enquiry', 'post_status' => 'private',
        'post_title' => $name . ' — ' . ($context === 'quote' ? 'Quotation' : 'Enquiry') . ' — ' . wp_date('Y-m-d H:i'),
        'post_content' => $summary,
    ]);
    if (is_wp_error($id) || !$id) { $redirect('failed'); }
    foreach (['name' => $name, 'email' => $email, 'phone' => $phone, 'location' => $location, 'interest' => $interest, 'context' => $context, 'status' => 'new'] as $k => $v) {
        update_post_meta($id, '_kam_' . $k, $v);
    }
    if ($items) { update_post_meta($id, '_kam_items', $items); }

    $s = kam_settings();
    $to = is_email($s['notify_email']) ? $s['notify_email'] : $s['email'];
    $headers = $email ? ['Reply-To: ' . $name . ' <' . $email . '>'] : [];
    $subject = '[' . $s['business_name'] . '] ' . ($context === 'quote' ? 'Quotation request' : 'Website enquiry') . ' from ' . $name;
    $body = "A new request was sent from the website.\n\n" . $summary . "\nView all enquiries: " . admin_url('edit.php?post_type=kam_enquiry') . "\n";
    $sent = $to ? wp_mail($to, $subject, $body, $headers) : false;
    update_post_meta($id, '_kam_notification_sent', $sent ? 'yes' : 'no');

    if ($email && $s['auto_reply'] === 'yes') {
        wp_mail($email, 'We received your request — ' . $s['business_name'],
            "Hello {$name},\n\nThank you for contacting {$s['business_name']}. Our team has received your request and will contact you soon.\n\n" . $summary
            . "\nPhone: " . kam_phone_display($s['primary_phone']) . "\nEmail: {$s['email']}\n");
    }
    $redirect($sent ? 'received' : 'saved');
}
add_action('admin_post_kam_enquiry', 'kam_enquiry_handler');
add_action('admin_post_nopriv_kam_enquiry', 'kam_enquiry_handler');

/* ---------- Dashboard screens ---------- */

function kam_new_enquiry_count() {
    $q = new WP_Query(['post_type' => 'kam_enquiry', 'post_status' => 'private', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false,
        'meta_query' => [['key' => '_kam_status', 'value' => 'new']]]);
    return (int) $q->found_posts;
}

add_filter('manage_kam_enquiry_posts_columns', function () {
    return ['cb' => '<input type="checkbox">', 'title' => 'From', 'kam_contact' => 'Contact', 'kam_interest' => 'Request', 'kam_state' => 'Status', 'date' => 'Received'];
});
add_action('manage_kam_enquiry_posts_custom_column', function ($col, $id) {
    if ($col === 'kam_contact') {
        $phone = get_post_meta($id, '_kam_phone', true); $email = get_post_meta($id, '_kam_email', true);
        if ($phone) { echo '<a href="' . esc_attr(kam_phone_href($phone)) . '">' . esc_html($phone) . '</a><br>'; }
        if ($email) { echo '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>'; }
        if (!$phone && !$email) {
            $c = (string) get_post_field('post_content', $id);
            if (preg_match('/Email:\s*(\S+@\S+)/', $c, $m)) { echo '<a href="mailto:' . esc_attr($m[1]) . '">' . esc_html($m[1]) . '</a>'; }
        }
    }
    if ($col === 'kam_interest') {
        $ctx = get_post_meta($id, '_kam_context', true);
        echo '<strong>' . esc_html($ctx === 'quote' ? 'Quotation' : 'Enquiry') . '</strong><br>' . esc_html((string) get_post_meta($id, '_kam_interest', true));
        $items = get_post_meta($id, '_kam_items', true);
        if (is_array($items) && $items) { echo '<br><span style="color:#50575e">' . count($items) . ' product' . (count($items) > 1 ? 's' : '') . '</span>'; }
    }
    if ($col === 'kam_state') {
        $st = get_post_meta($id, '_kam_status', true);
        $mail = get_post_meta($id, '_kam_notification_sent', true);
        echo $st === 'new' ? '<span class="kam-pill kam-pill--new">New</span>' : '<span class="kam-pill">Read</span>';
        if ($mail === 'no') { echo '<br><small style="color:#b32d2e">Email not sent</small>'; }
    }
}, 10, 2);

add_filter('post_row_actions', function ($actions, $post) {
    if ($post->post_type !== 'kam_enquiry') { return $actions; }
    unset($actions['inline hide-if-no-js']);
    $st = get_post_meta($post->ID, '_kam_status', true);
    $url = wp_nonce_url(admin_url('admin-post.php?action=kam_enquiry_status&id=' . $post->ID . '&to=' . ($st === 'new' ? 'handled' : 'new')), 'kam_enquiry_status_' . $post->ID);
    $actions['kam_status'] = '<a href="' . esc_url($url) . '">' . ($st === 'new' ? 'Mark as read' : 'Mark as unread') . '</a>';
    return $actions;
}, 10, 2);

add_action('admin_post_kam_enquiry_status', function () {
    $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
    check_admin_referer('kam_enquiry_status_' . $id);
    if (!$id || !current_user_can('edit_post', $id) || get_post_type($id) !== 'kam_enquiry') { wp_die('Not allowed.'); }
    update_post_meta($id, '_kam_status', isset($_GET['to']) && $_GET['to'] === 'new' ? 'new' : 'handled');
    wp_safe_redirect(wp_get_referer() ?: admin_url('edit.php?post_type=kam_enquiry'));
    exit;
});

add_action('add_meta_boxes_kam_enquiry', function ($post) {
    add_meta_box('kam-enquiry', 'Request details', function ($post) {
        $phone = get_post_meta($post->ID, '_kam_phone', true);
        $email = get_post_meta($post->ID, '_kam_email', true);
        $name = get_post_meta($post->ID, '_kam_name', true);
        echo '<div class="kam-enquiry-actions">';
        if ($phone) {
            echo '<a class="button button-primary" href="' . esc_attr(kam_phone_href($phone)) . '">Call ' . esc_html($phone) . '</a> ';
            $wa = preg_replace('/\D+/', '', $phone);
            if (strlen($wa) === 10 && $wa[0] === '0') { $wa = '256' . substr($wa, 1); }
            echo '<a class="button" target="_blank" rel="noopener" href="' . esc_url('https://wa.me/' . $wa) . '">WhatsApp</a> ';
        }
        if ($email) { echo '<a class="button" href="' . esc_attr('mailto:' . $email . '?subject=' . rawurlencode('Your request to ' . kam_get('business_name'))) . '">Reply by email</a> '; }
        $st = get_post_meta($post->ID, '_kam_status', true);
        $url = wp_nonce_url(admin_url('admin-post.php?action=kam_enquiry_status&id=' . $post->ID . '&to=' . ($st === 'new' ? 'handled' : 'new')), 'kam_enquiry_status_' . $post->ID);
        echo '<a class="button" href="' . esc_url($url) . '">' . ($st === 'new' ? 'Mark as read' : 'Mark as unread') . '</a></div>';
        echo '<pre class="kam-enquiry-body">' . esc_html(html_entity_decode($post->post_content, ENT_QUOTES, 'UTF-8')) . '</pre>';
        if ($name === '' && $phone === '') { echo '<p class="description">Saved by an earlier version of the website.</p>'; }
    }, 'kam_enquiry', 'normal', 'high');
});

/** Opening an enquiry marks it as read. */
add_action('load-post.php', function () {
    $id = isset($_GET['post']) ? absint($_GET['post']) : 0;
    if ($id && get_post_type($id) === 'kam_enquiry' && get_post_meta($id, '_kam_status', true) === 'new' && current_user_can('edit_post', $id)) {
        update_post_meta($id, '_kam_status', 'handled');
    }
});

add_filter('views_edit-kam_enquiry', function ($views) {
    $count = kam_new_enquiry_count();
    $url = add_query_arg(['post_type' => 'kam_enquiry', 'kam_state' => 'new'], admin_url('edit.php'));
    $current = isset($_GET['kam_state']) && $_GET['kam_state'] === 'new';
    $views['kam_new'] = '<a href="' . esc_url($url) . '"' . ($current ? ' class="current"' : '') . '>New <span class="count">(' . $count . ')</span></a>';
    $export = wp_nonce_url(admin_url('admin-post.php?action=kam_export_enquiries'), 'kam_export');
    $views['kam_export'] = '<a href="' . esc_url($export) . '">Download all as CSV</a>';
    return $views;
});

add_action('pre_get_posts', function ($q) {
    if (!is_admin() || !$q->is_main_query() || $q->get('post_type') !== 'kam_enquiry') { return; }
    if (isset($_GET['kam_state']) && $_GET['kam_state'] === 'new') {
        $q->set('meta_query', [['key' => '_kam_status', 'value' => 'new']]);
    }
});

add_action('admin_post_kam_export_enquiries', function () {
    check_admin_referer('kam_export');
    if (!current_user_can('edit_others_posts')) { wp_die('Not allowed.'); }
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=karen-agromaster-enquiries-' . gmdate('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Date', 'Name', 'Phone', 'Email', 'Location', 'Form', 'Interested in', 'Products', 'Status', 'Full request']);
    $safe = function ($v) { $v = (string) $v; return preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v; };
    foreach (get_posts(['post_type' => 'kam_enquiry', 'post_status' => 'any', 'numberposts' => -1, 'orderby' => 'date', 'order' => 'DESC']) as $p) {
        $items = get_post_meta($p->ID, '_kam_items', true);
        $list = is_array($items) ? implode('; ', array_map(function ($i) { return $i['name'] . ($i['qty'] ? ' (' . $i['qty'] . ')' : ''); }, $items)) : '';
        fputcsv($out, array_map($safe, [
            get_the_date('Y-m-d H:i', $p), get_post_meta($p->ID, '_kam_name', true) ?: $p->post_title, get_post_meta($p->ID, '_kam_phone', true),
            get_post_meta($p->ID, '_kam_email', true), get_post_meta($p->ID, '_kam_location', true),
            get_post_meta($p->ID, '_kam_context', true) === 'quote' ? 'Quotation' : 'Enquiry', get_post_meta($p->ID, '_kam_interest', true),
            $list, get_post_meta($p->ID, '_kam_status', true) === 'new' ? 'New' : 'Read', html_entity_decode($p->post_content, ENT_QUOTES, 'UTF-8'),
        ]));
    }
    fclose($out);
    exit;
});

add_action('wp_dashboard_setup', function () {
    if (!current_user_can('edit_others_posts')) { return; }
    wp_add_dashboard_widget('kam_enquiries', 'Latest website enquiries', function () {
        $posts = get_posts(['post_type' => 'kam_enquiry', 'post_status' => 'private', 'numberposts' => 6]);
        if (!$posts) { echo '<p>No enquiries yet. Requests from the contact and quotation forms will appear here.</p>'; return; }
        echo '<ul class="kam-dash-list">';
        foreach ($posts as $p) {
            $new = get_post_meta($p->ID, '_kam_status', true) === 'new';
            echo '<li><a href="' . esc_url(get_edit_post_link($p->ID)) . '"><strong>' . esc_html(get_post_meta($p->ID, '_kam_name', true) ?: $p->post_title) . '</strong></a> ' . ($new ? '<span class="kam-pill kam-pill--new">New</span>' : '')
                . '<br><span>' . esc_html((string) get_post_meta($p->ID, '_kam_interest', true)) . ' · ' . esc_html(human_time_diff(get_post_time('U', true, $p), time())) . ' ago</span></li>';
        }
        echo '</ul><p><a class="button" href="' . esc_url(admin_url('edit.php?post_type=kam_enquiry')) . '">View all enquiries</a></p>';
    });
});
